create PROCEDURE          "P_DELIVER"
                            (
                                    -- 매개변수 선언부
                                    V_CONTRACT_DETAIL_NO IN VARCHAR2
                                  , -- 수주상세일련번호
                                    ERROR_CODE OUT NUMBER
                                  ,                        -- 에러코드
                                    ERROR_MSG OUT VARCHAR2 -- 에러메세지
                            )
IS
        -- 변수,상수 선언부시작
        -- 선택된 수주상세 정보담은 레코드 타입의 변수
        V_CONTRACT_DETAIL_INFO_RECORD CONTRACT_DETAIL%ROWTYPE;
        -- 선택된 수주상세의 CONTRACT와 매핑되는 CONTRACT TABLE의 레코드 타입의 변수
        V_CONTRACT_INFO_RECORD CONTRACT%ROWTYPE;
        -- 납품예정재고량 정보담는 변수
        V_DELIVERY_AMOUNT STOCK.DELIVERY_AMOUNT%TYPE;
        -- 일련번호 담는 변수
        V_DELIVERY_NO VARCHAR2 ( 50 ) ;
        -- 배송도착지 담는 변수
        V_DELIVERY_PLACE_NAME VARCHAR2 ( 20 ) ;
        -- Y와 전체 갯수 비교 - > 수주 납품완료상태 'Y' 찍는용도의 변수
        V_COUNT_OF_COMPLETE NUMBER;
        V_COUNT_OF_ALL      NUMBER;
        -- 결제약속일
        V_PAYMENT_DAY VARCHAR2 ( 30 ) ;
BEGIN
        -- 실행부시작
        -- 변수세팅
        -- 레코드타입 변수에 선택된 수주상세 정보 담기
        SELECT *
        INTO   V_CONTRACT_DETAIL_INFO_RECORD
        FROM   CONTRACT_DETAIL
        WHERE  CONTRACT_DETAIL_NO = V_CONTRACT_DETAIL_NO; --납품하는 수주상세 정보
        -- 레코드타입 변수에 해당 수주상세정보를 가지는 수주정보 담기
        SELECT *
        INTO   V_CONTRACT_INFO_RECORD
        FROM   CONTRACT
        WHERE  CONTRACT_NO = V_CONTRACT_DETAIL_INFO_RECORD.CONTRACT_NO;

        -- 납품예정재고량 정보담기
        SELECT DELIVERY_AMOUNT
        INTO   V_DELIVERY_AMOUNT
        FROM   STOCK
        WHERE  STOCK.ITEM_CODE = V_CONTRACT_DETAIL_INFO_RECORD.ITEM_CODE;

        -- 배송도착지 정보담기
        SELECT DELIVERY_PLACE_NAME
        INTO   V_DELIVERY_PLACE_NAME
        FROM   DELIVERY_PLACE_BY_CUSTOMER
        WHERE  CUSTOMER_CODE = V_CONTRACT_INFO_RECORD.CUSTOMER_CODE;

        -- 납품예정재고량이 충분하다면
        IF TO_NUMBER ( V_DELIVERY_AMOUNT ) >= TO_NUMBER ( V_CONTRACT_DETAIL_INFO_RECORD.ESTIMATE_AMOUNT ) THEN
                -- 재고업데이트
                UPDATE STOCK
                SET
                       -- 수주(견적)수량만큼 재고테이블의 납품예정재고량에서 제거
                       STOCK.DELIVERY_AMOUNT    = STOCK.DELIVERY_AMOUNT    - V_CONTRACT_DETAIL_INFO_RECORD.ESTIMATE_AMOUNT
                     , STOCK.TOTAL_STOCK_AMOUNT = STOCK.TOTAL_STOCK_AMOUNT - V_CONTRACT_DETAIL_INFO_RECORD.ESTIMATE_AMOUNT
                WHERE  STOCK.ITEM_CODE          = V_CONTRACT_DETAIL_INFO_RECORD.ITEM_CODE;

                -- 재고로그 INSERT
                INSERT
                INTO   STOCK_LOG VALUES
                       (
                              '납품예정재고납품'
                            , '납품예정재고감소'
                            , TO_CHAR ( SYSDATE, 'YYYY-MM-DD HH24:MI:SS' )
                            , V_CONTRACT_DETAIL_INFO_RECORD.ITEM_CODE
                            , V_CONTRACT_DETAIL_INFO_RECORD.ITEM_NAME
                            , V_CONTRACT_DETAIL_INFO_RECORD.ESTIMATE_AMOUNT
                            , '납품'
                       ) ;

                -- 수주상세 납품업데이트
                UPDATE CONTRACT_DETAIL
                SET    DELIVERY_COMPLETION_STATUS = 'Y'
                WHERE  CONTRACT_DETAIL_NO         = V_CONTRACT_DETAIL_NO;

                -- 납품일련번호 생성
                CASE
                WHEN LENGTH ( DELIVER_SEQ.NEXTVAL ) < 3 THEN
                        V_DELIVERY_NO              := 'DE'
                        ||TO_CHAR ( SYSDATE, 'yyyymmdd' )
                        ||'-'
                        ||LPAD ( DELIVER_SEQ.CURRVAL, 2, 0 ) ;
                ELSE
                        V_DELIVERY_NO := 'DE'
                        ||TO_CHAR ( SYSDATE, 'yyyymmdd' )
                        ||'-'
                        ||TO_CHAR ( DELIVER_SEQ.CURRVAL ) ;
                END CASE;
                -- 납품현황 테이블에 정보 INSERT
                INSERT
                INTO   DELIVERY_INFO VALUES
                       (
                              -- 납품일련번호
                              V_DELIVERY_NO
                            ,
                              -- 견적번호
                              V_CONTRACT_INFO_RECORD.ESTIMATE_NO
                            ,
                              -- 수주번호
                              V_CONTRACT_DETAIL_INFO_RECORD.CONTRACT_NO
                            ,
                              -- 수주상세번호
                              V_CONTRACT_DETAIL_INFO_RECORD.CONTRACT_DETAIL_NO
                            ,
                              -- 거래처번호
                              V_CONTRACT_INFO_RECORD.CUSTOMER_CODE
                            , V_CONTRACT_INFO_RECORD.PERSON_CODE_IN_CHARGE
                            , -- 처리자
                              V_CONTRACT_DETAIL_INFO_RECORD.ITEM_CODE
                            , -- 물품코드
                              V_CONTRACT_DETAIL_INFO_RECORD.ITEM_NAME
                            , -- 물품이름
                              V_CONTRACT_DETAIL_INFO_RECORD.UNIT_OF_CONTRACT
                            , -- 단위
                              V_CONTRACT_DETAIL_INFO_RECORD.ESTIMATE_AMOUNT
                            , -- 수량
                              V_CONTRACT_DETAIL_INFO_RECORD.UNIT_PRICE_OF_CONTRACT
                            , -- 단가
                              V_CONTRACT_DETAIL_INFO_RECORD.SUM_PRICE_OF_CONTRACT
                            , -- 합계액
                              -- 납품일자
                              TO_CHAR ( SYSDATE, 'YYYY-MM-DD HH24:MI:SS' )
                            ,
                              -- 배송도착예정위치
                              V_DELIVERY_PLACE_NAME
                            , NULL
                            , NULL
                       ) ;

                -- 결제약속일 데이터 담기
                SELECT DUE_DATE_OF_CONTRACT
                INTO   V_PAYMENT_DAY
                FROM   DELIVERY_INFO A
                     , CONTRACT_DETAIL B
                WHERE  A.CONTRACT_DETAIL_NO = B.CONTRACT_DETAIL_NO
                AND    A.CONTRACT_DETAIL_NO = V_CONTRACT_DETAIL_NO;

                -- 매입_매출 테이블에 데이터 INSERT
                INSERT
                INTO   PURCHASE_SALE VALUES
                       (
                              'PS'
                                     ||TO_CHAR ( SYSDATE, 'yyyymmdd' )
                                     ||'-'
                                     ||LPAD ( PURCHASE_SALE_SEQ.NEXTVAL, 4, 0 )
                            , -- 매입_매출일련번호
                              V_DELIVERY_NO
                            , -- 납품일련번호
                              NULL
                            , -- 매입일련번호
                              V_CONTRACT_INFO_RECORD.CUSTOMER_CODE
                            , -- 거래처코드
                              TO_CHAR ( SYSDATE, 'YYYY-MM-DD' )
                            , -- 거래일
                              NULL
                            , -- 매입금액합계
                              V_CONTRACT_DETAIL_INFO_RECORD.SUM_PRICE_OF_CONTRACT
                            , -- 매출금액합계
                              V_PAYMENT_DAY
                            ,      -- 결제약속일
                              NULL -- 비고
                       ) ;

                --거래내역 테이블 데이터 INSERT
                INSERT
                INTO   DEAL VALUES
                       (
                              'DS'
                                     ||TO_CHAR ( SYSDATE, 'yyyymmdd' )
                                     ||'-'
                                     ||LPAD ( DEAL_SEQ.NEXTVAL, 4, 0 )
                            , -- 거래내역번호
                              V_DELIVERY_NO
                            , -- 납품일련번호
                              NULL
                            , -- 매입일련번호
                              V_CONTRACT_INFO_RECORD.CUSTOMER_CODE
                            , -- 거래처코드
                              V_CONTRACT_DETAIL_INFO_RECORD.ITEM_CODE
                            , -- 품목코드
                              TO_CHAR ( SYSDATE, 'YYYY-MM-DD' )
                            , -- 거래일
                              '매출'
                            , -- 구분
                              V_CONTRACT_DETAIL_INFO_RECORD.SUM_PRICE_OF_CONTRACT
                            , -- 수금금액
                              NULL
                            ,      -- 지불금액
                              NULL -- 비고
                       ) ;

                --거래상세 테이블 데이터 INSERT
                INSERT
                INTO   DEAL_DETAIL VALUES
                       (
                              'DS-D'
                                     ||TO_CHAR ( SYSDATE, 'yyyymmdd' )
                                     ||'-'
                                     ||LPAD ( DEAL_DETAIL_SEQ.NEXTVAL, 4, 0 )
                            , -- 거래상세코드
                              'DS'
                                     ||TO_CHAR ( SYSDATE, 'yyyymmdd' )
                                     ||'-'
                                     ||LPAD ( DEAL_SEQ.CURRVAL, 4, 0 )
                            , -- 거래내역코드
                              V_CONTRACT_DETAIL_INFO_RECORD.ITEM_CODE
                            , -- 품목코드
                              V_CONTRACT_DETAIL_INFO_RECORD.ESTIMATE_AMOUNT
                            , -- 수량
                              V_CONTRACT_DETAIL_INFO_RECORD.UNIT_OF_CONTRACT
                            , -- 단위
                              V_CONTRACT_DETAIL_INFO_RECORD.UNIT_PRICE_OF_CONTRACT
                            , -- 단가
                              V_CONTRACT_DETAIL_INFO_RECORD.SUM_PRICE_OF_CONTRACT
                            , -- 합계
                              V_CONTRACT_DETAIL_INFO_RECORD.ITEM_NAME
                            , '미수' -- 비고
                       ) ;

                -- 수주상세가 납품상태가 모두 Y가 되면 수주의 완료상태도 Y로 변경
                -- 같은 수주번호에 종속되는 모든 수주상세의 갯수
                SELECT COUNT(*)
                INTO   V_COUNT_OF_ALL
                FROM   CONTRACT_DETAIL
                WHERE  CONTRACT_NO = V_CONTRACT_DETAIL_INFO_RECORD.CONTRACT_NO;

                -- 같은 수주번호에 종속되는 수주상세 중 납품완료상태가 'Y' 인경우의 갯수
                SELECT COUNT(*)
                INTO   V_COUNT_OF_COMPLETE
                FROM   CONTRACT_DETAIL
                WHERE  CONTRACT_NO                = V_CONTRACT_DETAIL_INFO_RECORD.CONTRACT_NO
                AND    DELIVERY_COMPLETION_STATUS = 'Y';

                -- 모든항목의 납품이 완료되었다면
                IF ( V_COUNT_OF_ALL = V_COUNT_OF_COMPLETE ) THEN
                        UPDATE CONTRACT
                        SET    DELIVERY_COMPLETION_STATUS = 'Y'
                        WHERE  CONTRACT_NO                = V_CONTRACT_DETAIL_INFO_RECORD.CONTRACT_NO;

                END IF;
                ERROR_MSG := 'SUCCESS';
                -- 납품예정재고량이 충분하지 않다면
        ELSIF TO_NUMBER ( V_DELIVERY_AMOUNT ) < TO_NUMBER ( V_CONTRACT_DETAIL_INFO_RECORD.ESTIMATE_AMOUNT ) THEN
                -- VIEW단에 전달할 CHECK MSG
                ERROR_MSG := '납품예정재고가 부족합니다. 확인 바랍니다.';
        END IF;
        -- 성공시 커밋
        COMMIT;
        ERROR_CODE := '0';
        -- 예외 발생시
EXCEPTION
WHEN NO_DATA_FOUND THEN
        DBMS_OUTPUT.PUT_LINE ( 'NO_DATA_FOUND' ) ;
        ERROR_CODE := '-1';
        ERROR_MSG  := '데이터를 찾을 수 없습니다!';
        RETURN;
WHEN DUP_VAL_ON_INDEX THEN
        DBMS_OUTPUT.PUT_LINE ( 'DUP_VAL_ON_INDEX' ) ;
        ERROR_CODE := '-1';
        ERROR_MSG  := '고유값이 중복됩니다!';
        RETURN;
WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE ( '오류가 발생했습니다' ) ;
        DBMS_OUTPUT.PUT_LINE ( 'SQL ERROR CODE: '
        || SQLCODE ) ;
        DBMS_OUTPUT.PUT_LINE ( 'SQL ERROR MESSAGE: '
        || SQLERRM ) ;
        ERROR_CODE := '-1';
        ERROR_MSG  := 'SQL ERROR CODE: '
        || SQLCODE
        || 'SQL ERROR MESSAGE: '
        || SQLERRM;
        RETURN;
        -- PROCEDURE 끝
END;
/

