create PROCEDURE      "P_OPTION_ORDER" --파라미터값으로 품목코드,발주수량 받음
(   V_ITEM_CODE IN VARCHAR2 -- 임의발주 품목코드
    ,V_OPTION_ORDER_AMOUNT IN NUMBER -- 임의발주 수량
    ,ERROR_CODE OUT NUMBER -- 에러코드
    ,ERROR_MSG OUT VARCHAR2 -- 에러메세지
)
IS
-- 변수선언부
V_ORDER_NO order_info.order_no%TYPE;
V_ITEM_NAME STOCK.ITEM_NAME%TYPE; -- 임의발주 품목명
-- 커서시작
-- 커서끝
BEGIN
-- 실행부시작
      --뷰단에서 품목명 못가져와서 프로시저에서 품목명 해결함
    SELECT ITEM_NAME
    INTO V_ITEM_NAME
    FROM STOCK
    WHERE P_OPTION_ORDER.V_ITEM_CODE = STOCK.ITEM_CODE;

    -- 임의발주량을 입고예정재재고량에 추가
    -- STOCK 테이블의 정보 업데이트
    UPDATE
    STOCK
    SET
    STOCK.ORDER_AMOUNT = STOCK.ORDER_AMOUNT + V_OPTION_ORDER_AMOUNT --입고예정재고량+임의발주수량 = 입고예정재고량
    WHERE
    stock.item_code =V_ITEM_CODE;
    -- STOCK테이블 업데이트 끝

    -- 발주번호생성
    case
        when length(ORDER_SEQUENCE.NEXTVAL)<3
        then  V_ORDER_NO := 'ORDO'||TO_CHAR(SYSDATE,'yyyymmdd')||'-'||lpad(ORDER_SEQUENCE.currval,2,0);
        else  V_ORDER_NO := 'ORDO'||TO_CHAR(SYSDATE,'yyyymmdd')||'-'||to_char(ORDER_SEQUENCE.currval);
        end case;


    -- ORDER_INFO에 발주정보등록
    -- 발주현황 tab에서 order_info 사용
    INSERT INTO ORDER_INFO VALUES
    (V_ORDER_NO,SYSDATE,'운송중','임의발주',V_ITEM_CODE,V_ITEM_NAME,V_OPTION_ORDER_AMOUNT,null);

    -- 스톡로그정보만들어서 STOCK_LOG 테이블에 찍기
    -- 발주량만큼 입고예정재고량에 추가됬다고 남기는 로그
    INSERT INTO STOCK_LOG VALUES
    ('임의발주','입고예정재고 증가',TO_CHAR(SYSDATE,'YYYY-MM-DD HH24:MI:SS'),V_ITEM_CODE,V_ITEM_NAME,V_OPTION_ORDER_AMOUNT,'임의발주');


-- 성공시 커밋
COMMIT;

ERROR_CODE := '0';
ERROR_MSG := '임의발주완료 프로시저에서 보낸 메시지임';

-- 예외 발생시
EXCEPTION

WHEN NO_DATA_FOUND THEN
       DBMS_OUTPUT.PUT_LINE('NO_DATA_FOUND');
       ERROR_CODE := '-1';
       ERROR_MSG := 'NO_DATA_FOUND //데이타 없으니깐 데이타 넣으세요';
       RETURN;

WHEN DUP_VAL_ON_INDEX THEN
       DBMS_OUTPUT.PUT_LINE('DUP_VAL_ON_INDEX');
       ERROR_CODE := '-1';
       ERROR_MSG := 'DUP_VAL_ON_INDEX //UNIQUE 제약을 갖는 컬럼에 중복되는 데이터가 INSERT 될 때';
       RETURN;

WHEN OTHERS THEN
       DBMS_OUTPUT.PUT_LINE('OTHERS');
       ERROR_CODE := '-1';
       ERROR_MSG := '관리자에게 문의 하세요 // 01077239513';
       RETURN;

-- PROCEDURE 끝
END;
/

