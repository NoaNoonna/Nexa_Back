create PROCEDURE      "P_MRP_OPEN" --mps로 모의 전개
       (  V_MPS_NO_LIST IN VARCHAR2 -- MRP 진행할 MPS넘버  주생산계획번호 하나만 넘어옴
		-- MPS번호 하나 받는것만 가능함 데이터를 여러개행으로 나눠주는 로직도 없고,
		-- 데이터를 배열형태로 받을수도 없기 때문 [ ibatis 배우면 가능하다고한다. ]
         , ERROR_CODE OUT VARCHAR2 -- 에러코드
         , ERROR_MSG OUT VARCHAR2 -- 에러메세지
         , RESULT OUT SYS_REFCURSOR -- 결과 값 반환 커서
       )
IS

--***************************************************
-- MRP_OPEN_TEMP Table 변수
--***************************************************


V_ITEM_CLASSIFICATION MRP_OPEN_TEMP.ITEM_CLASSIFICATION%TYPE; --품목분류코드
V_ORDER_DATE         DATE; --발주일자
V_REQUIRED_DATE       DATE; --소요일자
V_PLAN_AMOUNT MRP_OPEN_TEMP.PLAN_AMOUNT%TYPE; -- .계획수량 : 제작필요량
V_TOTAL_LOSS_RATE     VARCHAR2(100); --누적손실율
V_CACULATED_AMOUNT    MRP_OPEN_TEMP.CACULATED_AMOUNT%TYPE; -- 계산수량 : 계획수량+ 손실율
V_REQUIRED_AMOUNT     MRP_OPEN_TEMP.REQUIRED_AMOUNT%TYPE; -- 필요수량 : 계산수량 올림

--***************************************************
-- MPS Table 변수
--***************************************************

V_MPS_ITEM_CODE MPS.ITEM_CODE%TYPE; --품목코드
V_MPS_PLAN_AMOUNT         MPS.MPS_PLAN_AMOUNT%TYPE; --mps계획수량
V_MPS_SCHEDULED_END_DATE      MPS.SCHEDULED_END_DATE%TYPE; --예정마감일자(출하예정일)

CURSOR C_BOM_LIST -- 받아온 MPS 아이템의 하위 아이템들의 정보
IS
		(SELECT
			CONNECT_BY_ROOT ITEM_CODE || ' -' || TO_CHAR(ROWNUM, '000') AS BOM_NO
			,ITEM_CODE
			,NET_AMOUNT
			,LPAD('  ',8*(LEVEL-1))||ITEM_NAME AS ITEM_NAME
			,CASE
				WHEN ITEM_CLASSIFICATION='IT-SI' AND CONNECT_BY_ROOT ITEM_CODE LIKE 'DK-0%'
					THEN 'IT-WP'
				ELSE ITEM_CLASSIFICATION
			 END AS ITEM_CLASSIFICATION
			,UNIT_OF_STOCK
			,LOSS_RATE
			,LEAD_TIME
			,PARENT_ITEM_CODE
		FROM (SELECT
											I.ITEM_CODE
											,B.NET_AMOUNT
											,I.ITEM_NAME
											,I.ITEM_CLASSIFICATION
											,I.UNIT_OF_STOCK
											,I.LOSS_RATE
											,I.LEAD_TIME
											,B.PARENT_ITEM_CODE
				FROM BOM B,ITEM I
				WHERE B.ITEM_CODE=I.ITEM_CODE) BI
		START WITH ITEM_CODE=V_MPS_ITEM_CODE -- V_MPS_ITEM_CODE
		CONNECT BY PRIOR item_code=parent_item_code);
        --아이템 이름과 손실율, 리드타임, 단위, 재료구분(원재료|반제품|완제품) 정보를 가져옴
        --ITEM_CODE가 DK-01에 대한 BOM 정전개의 결과가 나옴
        --커서 안에는 총 9줄의 결과가 담겨 있다. 이 결과를 이용할 것임
CURSOR C_MPS_NO_LIST -- 커서선언시작
        IS
                WITH MPS_NO_LIST AS
                ( SELECT
                        --'MG20200506-001 , MG20200506-002,MG20200506-003 '이 넘어 오면 ,을 없애고 3개의 행으로 만듬
                        --하나의 행으로 여러행 나누는 방법: 정규 표현식
                        TRIM( REGEXP_SUBSTR( V_MPS_NO_LIST ,'[^,]+', 1, LEVEL ) ) MPS_NO
                FROM    DUAL
                        CONNECT BY REGEXP_SUBSTR( V_MPS_NO_LIST , '[^,]+', 1, LEVEL ) IS NOT NULL
                )
                --WITH 선언끝
                SELECT *
                FROM   MPS_NO_LIST;
BEGIN


    DELETE mrp_open_temp; --결과 값을 저장하게 될 임시 테이블 내용을 리셋 !!!
                          --최종적으로 임시테이블에 모든 결과를 담을 것임-->그리고 결과값 커서로 뷰단에 반환할것임
    COMMIT;
-- *****************************************************************************
-- 정전개 리스트 개수만큼 반복
-- *****************************************************************************
    --C_BOM_LIST에는 주생산계획 아이템에 대해 정전개한 정보가 들어있다
    --BOM_NO, I_CODE, N_AMOUNT, I_NAME, I_CLASSIFICATION, UNIT, LOSS_RATE, LEAD_TIEM
    --BOM_LIST는 변수명이 마치 자재명세서 리스트를 말하는것 같지만 하나의 행을 말하는 것임
    --디카부터 시작해서 가장 하위품목까지 커서가 바뀌면서 아래의 루푸문이 실행됨
    FOR R_MPS_NO IN C_MPS_NO_LIST
    LOOP
    --변수에 값 할당
        SELECT
              ITEM_CODE         --품목코드
             , MPS_PLAN_AMOUNT      --MPS계획수량 = 제작필요수량
             , SCHEDULED_END_DATE       --예정마감일자
        INTO
              V_MPS_ITEM_CODE     --MPS 테이블 변수 : 즉 MPS에서 가져온 ITEM_CODE를 변수 V_MPS_ITEM_CODE에 담음
             , V_MPS_PLAN_AMOUNT --필요량;계획수량
             , V_MPS_SCHEDULED_END_DATE --예정마감일자
          FROM MPS
         WHERE MPS_NO = R_MPS_NO.MPS_NO;
    FOR BOM_LIST IN C_BOM_LIST

    LOOP

--**********************************************
--품목코드를 품목분류로 변환
--**********************************************
        --ITEM_CLASSIFICATION의 값이 IT-CI(완제품) 또는 IT-SI(반제품) 또는 IT-MA(원재료)로 담겨 있다
        --이 값들을 각각에 해당하는 완제품, 반제품, 원재료로 변환시킴
        --단순히 코드를 문자열로 변경하는 행위
      IF BOM_LIST.ITEM_CLASSIFICATION='IT-CI' THEN V_ITEM_CLASSIFICATION:='완제품';
      ELSIF BOM_LIST.ITEM_CLASSIFICATION='IT-SI' THEN V_ITEM_CLASSIFICATION:='반제품';
      ELSIF BOM_LIST.ITEM_CLASSIFICATION='IT-WP' THEN V_ITEM_CLASSIFICATION:='재공품';
      ELSE V_ITEM_CLASSIFICATION:= '원재료';
      END IF;



--**********************************************
--손실율 계산
--**********************************************
     V_TOTAL_LOSS_RATE := f_total_loss_rate(BOM_LIST.ITEM_CODE, R_MPS_NO.MPS_NO);  --손실률 function
				dbms_output.put_line( V_TOTAL_LOSS_RATE);

--**********************************************
--계획수량,계산수량,필요수량 계산
--**********************************************
        --V_PLAN_AMOUNT MRP_OPEN_TEMP.PLAN_AMOUNT%TYPE; ==> 필요량
        --V_MPS_PLAN_AMOUNT=>위의 MPS계획 수량을 변수에 담음
        --MRP 계획 수량 * 정미수량을 변수 V_PLAN_AMOUNT에 담음
        --모품목 필요수량 (견적등록부터 넘어와서 MPS에 MPS_PLAN_AMOUNT로 등록되있음)과 자품목 정미수량 곱하기
        --손실율을 감안하지 않은 계획수량-정미수량
        --BOM 테이블 정미수량 = 손실률을 감안하지 않고 카메라 1대를 만들때 필요한 수량
        V_PLAN_AMOUNT:=V_MPS_PLAN_AMOUNT * BOM_LIST.NET_AMOUNT; -- 계획수량 : MRP 계획 수량 * 정미수량
        --V_CACULATED_AMOUNT MRP_OPEN_TEMP.CACULATED_AMOUNT%TYPE; =>손실율로 계산한 계산수량
        --1-손실율 나눠서 계산수량 구함
        --계획수량(MPS) == 정미수량(견적서),

        --손실률을 적용한 수량
        V_CACULATED_AMOUNT := ROUND(V_PLAN_AMOUNT *V_TOTAL_LOSS_RATE,3); -- 계산수량
        -- V_CACULATED_AMOUNT := ROUND(V_PLAN_AMOUNT / (1 - V_TOTAL_LOSS_RATE),3);


        --예)ROUND(필요수량200 / (1-손실율0.05),3) = 210.526
        --ROUND(V_PLAN_AMOUNT * (1 + V_TOTAL_LOSS_RATE),3);
        --실제수량 : 계산수량을 올림만
        --필요수량
        --V_REQUIRED_AMOUNT     MRP_OPEN_TEMP.REQUIRED_AMOUNT%TYPE; -- 손실율에 따른 실제 물건필요수량
        V_REQUIRED_AMOUNT := CEIL(V_CACULATED_AMOUNT); -- 필요수량
        --예)CEIL(ROUND(필요수량200 / (1-손실율0.05),3)) = 210.526 --> 211


--**********************************************
--ORDER_Date 계산 //발주/작업지시기한
--**********************************************
        --V_MPS_SCHEDULED_END_DATE      MPS.SCHEDULED_END_DATE%TYPE; --예정마감일자
        --V_ORDER_DATE         DATE; --발주일자
        --리드타임 합산해서 MPS주생산계획 수립할때 설정했던 출하예정일(예정마감일자)에서 빼버리기
        V_ORDER_DATE := TO_DATE(V_MPS_SCHEDULED_END_DATE,'YYYY-MM-DD') - f_sum_lead_time(BOM_LIST.ITEM_CODE); --리드타임 function
				--F_SUM_LEAD_TIME (FUNCTION)에서 역전개로
        --하위품목에서 최상위품목까지 생산에 필요한
        --일수를 계산해서 리드타임을 산출
        --예) 헤더(원재료,2) -> 카메라본체(반제품,2) -> 디카 (완제품,1) = 총5일
        -- 예정마감일자 - 리드타임 = 발주일자 4월30일 - 5일 = 4월 25일
--**********************************************
--REQUIRED_DATE 계산  // 발주/작업지시완료기한
--**********************************************
        --V_REQUIRED_DATE       DATE; --소요일자
        --리트타임 계산해서 나오는 날짜
        --작업지시/발주지시 날짜에서 해당 아이템의 리드타임 더해서 작업완료(완제품, 반제품)/물건도착(원재료) 날짜 계산하기
       V_REQUIRED_DATE := V_ORDER_DATE + BOM_LIST.LEAD_TIME;

--**********************************************
--MRP_OPEN_TEMP 임시테이블에 저장
--**********************************************
            --전체적으로 변수 선언한것은 할당 연산자를 통해서 값을 넣어줘서 마지막에 INSERT에서 사용한다
            --또는 커서 돌리고 필요한것은 커서에서 빼내서 INSERT에서 사용
            --아래 INSERT되는 내용이 MRP_OPEN_TEMP에 들어가서 다이얼로그에서 보여진다
           INSERT INTO MRP_OPEN_TEMP VALUES
                  (
			R_MPS_NO.MPS_NO -- 주생산 계획번호
			, BOM_LIST.BOM_NO -- BOM 번호 ( DK-AP01 - 001)
			, V_ITEM_CLASSIFICATION -- 원재료 반제품 완제품
			, BOM_LIST.ITEM_CODE -- 아이템 코드
			, BOM_LIST.ITEM_NAME -- 아이템 이름
			, BOM_LIST.UNIT_OF_STOCK -- 단위(EA)
			, V_PLAN_AMOUNT -- 필요량 //계획수량인듯
			, V_ORDER_DATE
			-- 발주 / 생산 지시기한 ( 리드타임 계산에 따라 해당 Row의 물건이
			-- 이 V_ORDER_DATE 날짜 이후에 작업/발주가 지시되면 전체적인 작업이 출하예정일보다 늦어져서 조저 버리기~~ )
			, V_REQUIRED_DATE
			-- 발주 / 생산 완료기한
       --필요한 날짜 (이 물건이 필요한 날짜 [리드타임 계산해서 나오는 날짜임])
			, V_TOTAL_LOSS_RATE -- 계산한 손실율
			, V_CACULATED_AMOUNT  -- 계산된 결과  //손실율로 계산한 계산수량
			, V_REQUIRED_AMOUNT -- 계산된 결과를 올림한 실제 필요수량   //손실율에 따른 실제 물건필요수량
                  )
                  ;
       END LOOP;
      END LOOP;
       COMMIT;
       ERROR_CODE := '0';
       ERROR_MSG := '모의전개 성공';

       --결과 값을 변수 RESULT에 담아서 자바단으로 반환시킴
       --뒷단에서 반환 받아서 뷰단으로 뿌릴것임

       OPEN RESULT FOR SELECT * FROM MRP_OPEN_TEMP order by BOM_NO;

   EXCEPTION
   WHEN NO_DATA_FOUND THEN
       DBMS_OUTPUT.PUT_LINE('NO_DATA_FOUND');
       ERROR_CODE := '-1';
       ERROR_MSG := 'NO_DATA_FOUND';
       RETURN;
   WHEN DUP_VAL_ON_INDEX THEN
       DBMS_OUTPUT.PUT_LINE('DUP_VAL_ON_INDEX');
       ERROR_CODE := '-1';
       ERROR_MSG := 'DUP_VAL_ON_INDEX';
       RETURN;
   WHEN OTHERS THEN
       DBMS_OUTPUT.PUT_LINE('OTHERS');
       ERROR_CODE := '-1';
       ERROR_MSG := '관리자에게 문의 하세요 // 01077239513';
       RETURN;
   END P_MRP_OPEN;
/

