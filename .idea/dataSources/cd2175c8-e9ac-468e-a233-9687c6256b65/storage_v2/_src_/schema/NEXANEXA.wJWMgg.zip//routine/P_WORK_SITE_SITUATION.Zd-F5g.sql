create PROCEDURE          "P_WORK_SITE_SITUATION" --작업장
(
    -- 매개변수 선언부
    P_WORK_ORDER_NO IN VARCHAR2, --작업지시일련번호
    P_WORK_SITE_COURSE IN VARCHAR2,  --작업코스(작업장에서 선택한 공정의 이름이 뷰단에서 넘어옴)
    P_ITEM_CLASSIFICATION IN VARCHAR2,  --품목분류(완제품,반제품,재공품)
    ERROR_CODE OUT NUMBER, -- 에러코드
    ERROR_MSG OUT VARCHAR2, -- 에러메세지
    RESULT OUT SYS_REFCURSOR --결과값 반환
)
IS
--변수선언
V_ITEM_CLASSIFICATION MRP.ITEM_CLASSIFICATION%TYPE;

V_ERROR_CODE NUMBER(1);

V_ERROR_MSG VARCHAR2(100);

V_PRODUCTION_MSG VARCHAR2(100); --진행중 메시지를 담기위한 변수

CURSOR C_WORK_ORDER IS  -- 작업중인 품목의 정보
--커서선언 시작
--WITH 선언 시작
select
			WDI.WORK_ORDER_NO--작업지시번호
      ,WDI.WORK_SITE_NAME--작업장명
      ,WDI.ITEM_CLASSIFICATION AS WD_ITEM--제작품목분류
      ,WDI.ITEM_CODE AS PARENT_ITEM_CODE--제작품목코드
      ,WDI.ITEM_NAME AS PARENT_ITEM_NAME--제작품목명
      ,WDI.ITEM_CLASSIFICATION--작업품목분류
      ,WDI.ITEM_CODE--작업품목코드
      ,TRIM(WDI.ITEM_NAME) AS ITEM_NAME--작업품목명
      ,WDI.REQUIRED_AMOUNT--작업량
      ,WDI.PRODUCTION_PROCESS_CODE-- PP002
      ,WDI.PRODUCTION_PROCESS_NAME--   조립생산공정
from WORK_ORDER_INFO  WDI -- 작업장조회 테이블
where
WDI.work_order_no=P_WORK_ORDER_NO;


--커서선언 끝


BEGIN
--실행부 시작
	DELETE FROM WORK_SITE_TEMP ;

V_ERROR_CODE := NULL;
V_ERROR_MSG := NULL;

--자바에서 받아온 값을 비교함

IF P_ITEM_CLASSIFICATION = '재공품' OR P_ITEM_CLASSIFICATION = '반제품' THEN

	V_ITEM_CLASSIFICATION := '반제품';

ELSE

	V_ITEM_CLASSIFICATION := '완제품';

END IF;

IF P_WORK_SITE_COURSE = 'RawMaterials' THEN
		--원재료 검사일 경우
		-- 모든 항목이 다 나와야 하기 때문에 V_ITEM_CLASSIFICATION를 원재료로 다시 재할당함
		--그 외의 경우에는 위의 IF에서 V_ITEM_CLASSIFICATION을 구분을 해야함
    V_ITEM_CLASSIFICATION := '원재료';

    V_PRODUCTION_MSG := '을 만들기 위해서 원재료 검사 진행중입니다.';

    V_ERROR_CODE := 0;

    V_ERROR_MSG := '원재료 검사중';

ELSIF P_WORK_SITE_COURSE = 'Production' THEN  --제품제작일 경우

    V_PRODUCTION_MSG := '제품을 제작중 입니다.';

    V_ERROR_CODE := 0;

    V_ERROR_MSG := '제품제작중';

ELSIF P_WORK_SITE_COURSE = 'SiteExamine' THEN  --제품검사일 경우

    V_PRODUCTION_MSG := '판매제품을 검사중 입니다.';

    V_ERROR_CODE := 0;

    V_ERROR_MSG := '판매제품 검사중';


END IF;

FOR V_WORK_RAWMATERIALS IN C_WORK_ORDER -- 작업중인 품목의 정보.

	LOOP

				INSERT INTO WORK_SITE_LOG VALUES (
            V_WORK_RAWMATERIALS.WORK_ORDER_NO,
            V_WORK_RAWMATERIALS.ITEM_CODE,
            V_WORK_RAWMATERIALS.ITEM_NAME,
            V_WORK_RAWMATERIALS.PARENT_ITEM_NAME||V_PRODUCTION_MSG,
            V_WORK_RAWMATERIALS.WORK_SITE_NAME,
            SYSDATE,
            V_WORK_RAWMATERIALS.PRODUCTION_PROCESS_CODE,
            V_WORK_RAWMATERIALS.PRODUCTION_PROCESS_NAME
            );

        INSERT INTO WORK_SITE_TEMP VALUES (
              V_WORK_RAWMATERIALS.WORK_ORDER_NO,
              V_WORK_RAWMATERIALS.WORK_SITE_NAME, --작업장명; 완제품작업장,반제품작업장
              V_WORK_RAWMATERIALS.WD_ITEM, --제작품목분류
              V_WORK_RAWMATERIALS.PARENT_ITEM_CODE, --제작품목코드
              V_WORK_RAWMATERIALS.PARENT_ITEM_NAME, --제작품목명
              V_ITEM_CLASSIFICATION, --작업품목분류 ; 완제품,반제품,원재료
              V_WORK_RAWMATERIALS.ITEM_CODE,
              V_WORK_RAWMATERIALS.ITEM_NAME,
              V_WORK_RAWMATERIALS.REQUIRED_AMOUNT --작업량
            );
	END LOOP;

COMMIT;

ERROR_CODE := V_ERROR_CODE;
ERROR_MSG := V_ERROR_MSG;

OPEN RESULT FOR SELECT * FROM WORK_SITE_TEMP;

-- 예외 발생시
EXCEPTION

WHEN NO_DATA_FOUND THEN
       DBMS_OUTPUT.PUT_LINE('NO_DATA_FOUND');
       ERROR_CODE := '-1';
       ERROR_MSG := 'NO_DATA_FOUND';
       RETURN;

WHEN DUP_VAL_ON_INDEX THEN
       DBMS_OUTPUT.PUT_LINE('DUP_VAL_ON_INDEX');
       ERROR_CODE := '-1';
       ERROR_MSG := 'DUP_VAL_ON_INDEX';
       RETURN;

WHEN OTHERS THEN
       DBMS_OUTPUT.PUT_LINE('OTHERS');
       ERROR_CODE := '-1' ;
       ERROR_MSG := '관리자에게 문의하세여 //010-1231-1234';
       RETURN;

END;
/

