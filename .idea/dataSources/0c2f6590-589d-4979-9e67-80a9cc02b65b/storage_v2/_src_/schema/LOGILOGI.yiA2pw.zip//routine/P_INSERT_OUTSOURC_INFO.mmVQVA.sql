create PROCEDURE      "P_INSERT_OUTSOURC_INFO" -- 프로시저명
       (   V_MRP_GATHERING_NO_LIST IN VARCHAR2 --소요량취합번호리스트
         , ERROR_CODE OUT NUMBER -- 에러코드
         , ERROR_MSG OUT VARCHAR2 -- 에러메세지
       )
IS -- 변수 상수 선언부 시작


CURSOR C_OUTSOURC_INFO -- 커서선언시작
IS
    			WITH MRP_GATHERING_NO_STR AS 
			( SELECT V_MRP_GATHERING_NO_LIST FROM DUAL ) , 
			
			MRP_GATHERING_NO_LIST AS 
			(
			SELECT TRIM( REGEXP_SUBSTR( (SELECT * FROM MRP_GATHERING_NO_STR ) ,'[^,]+', 1, LEVEL ) ) AS MRP_GATHERING_NO FROM DUAL 
			CONNECT BY REGEXP_SUBSTR( (SELECT * FROM MRP_GATHERING_NO_STR ) , '[^,]+', 1, LEVEL ) IS NOT NULL
			)
select
o.CLAIM_DATE,
o.DUE_DATE,
o.ITEM_CODE,
o.ITEM_NAME,
o.MRP_GATHERING_NO,
o.MRP_GATHERING_SEQ,
o.NECESSARY_AMOUNT,
o.ORDER_OR_PRODUCTION_STATUS,
o.OUTSOURC_AMOUNT,
o.SUM_PRICE_OF_OUTSOURC,
o.UNIT_OF_MRP_GATHERING,
o.UNIT_PRICE_OF_OUTSOURC,
o.OUTSOURC_NO
            from 
            OUTSOURC_INFO o,
            MRP_GATHERING_NO_LIST m
            where 
            o.mrp_gathering_no=m.mrp_gathering_no;
            

CURSOR C_BOM(V_ITEM_CODE VARCHAR2) -- 커서선언시작

IS(    
            SELECT
		BOM_NO,   -- BOM 번호
		b.ITEM_CODE AS ITEM_CODE,  -- 품목코드
		NET_AMOUNT,    --정미수량
		LPAD('  ',8*(lvl-1))||ITEM_NAME AS item_name,  --품목명
		ITEM_CLASSIFICATION,   --품목분류 (완제품,반제품,원재료)
		UNIT_OF_STOCK,   -- 단위
		LOSS_RATE,   -- 손실율
		LEAD_TIME   -- 리드타임
		FROM
			(
            --주생산계획 수립된 물품의 코드를 받아서 해당 아이템의 하위아이템 정전개,
			SELECT
			LEVEL lvl,  --LEVEL
			CONNECT_BY_ROOT ITEM_CODE || ' -' || TO_CHAR(ROWNUM, '000') AS BOM_NO,
            --임의의 BOM_NO 생성(DK-AP01-001, DK-AP01-002,...)
			ITEM_CODE,      --품목코드
			NET_AMOUNT      --정미수량: LOSS율을 감안하지 않는 수량이다
			FROM BOM
			START WITH ITEM_CODE=V_ITEM_CODE -- V_MPS_ITEM_CODE
			CONNECT BY PRIOR item_code=parent_item_code
			) b,
		ITEM i
		WHERE b.item_code=i.item_code);
            
            
BEGIN
            
            for OUTSOURC_INFO IN C_OUTSOURC_INFO
            LOOP
                        DBMS_OUTPUT.PUT_LINE('for OUTSOURC_INFO IN C_OUTSOURC_INFO');
            for BOM in C_BOM(OUTSOURC_INFO.ITEM_CODE)
            loop
        update mrp_gathering
        set
        necessary_amount = necessary_amount-BOM.NET_AMOUNT*OUTSOURC_INFO.OUTSOURC_AMOUNT,
        OUTSOURC_STATUS = 'Y'
        where
        mrp_gathering_seq = OUTSOURC_INFO.mrp_gathering_seq
        and
        item_code = BOM.ITEM_CODE;
        
        end loop;
            
            END LOOP;
            
END;
/

