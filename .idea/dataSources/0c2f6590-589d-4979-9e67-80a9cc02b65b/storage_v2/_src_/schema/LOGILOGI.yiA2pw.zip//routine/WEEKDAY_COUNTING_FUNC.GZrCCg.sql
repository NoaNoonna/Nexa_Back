create FUNCTION         "WEEKDAY_COUNTING_FUNC" 
(
        START_DATE IN VARCHAR2,
        END_DATE   IN VARCHAR2
)
        RETURN VARCHAR2
IS
        WEEKDAY_COUNT  VARCHAR2(100);
BEGIN
        SELECT COUNT(A.DT)
        INTO WEEKDAY_COUNT
        FROM   ( SELECT TO_CHAR (SDT + LEVEL - 1, 'RRRR-MM-DD') DT,
                       TO_CHAR (SDT  + LEVEL - 1, 'D') D
               FROM    (SELECT TO_DATE (START_DATE, 'RRRR-MM-DD') SDT,
                               TO_DATE (END_DATE, 'RRRR-MM-DD') EDT
                       FROM    DUAL
                       )
                       CONNECT BY LEVEL <= EDT - SDT + 1
               )
               A,
               ( SELECT TO_CHAR(APPLY_DAY,'RRRR-MM-DD') DT,
                       HOLIDAY_NAME CMT
               FROM    HOLIDAY -- 공휴일정보 테이블
               )
               B
        WHERE  A.DT = B.DT(+)
        AND    A.D NOT IN ('1',
                           '7') -- 토/일요일 제외
        AND    B.DT IS NULL;

        RETURN WEEKDAY_COUNT;
EXCEPTION
WHEN OTHERS THEN
        RETURN('');
END;
/

