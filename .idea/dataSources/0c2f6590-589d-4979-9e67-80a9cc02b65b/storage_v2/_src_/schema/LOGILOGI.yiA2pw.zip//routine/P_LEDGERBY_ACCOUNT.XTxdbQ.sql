create PROCEDURE          P_LEDGERBY_ACCOUNT
( P_ACCOUNT_CODE IN VARCHAR2,
P_START_DAY IN VARCHAR2,
P_END_DAY IN VARCHAR2,
ERROR_CODE OUT NUMBER,
ERROR_MSG OUT VARCHAR2,
 RESULT OUT SYS_REFCURSOR
)
IS
IS_DAECHA VARCHAR(20);
BEGIN
  OPEN RESULT FOR
   SELECT NULL FROM DUAL WHERE ROWNUM = 0;


DELETE FROM TMP_LEDGERBY_ACCOUNT;
 INSERT INTO TMP_LEDGERBY_ACCOUNT(APPEND_CODE,
 																													DETAIL_APPEND_CODE,
                                                          ACCOUNT_CODE,
                                                          SUBJECT_CODE)
    SELECT                     DISTINCT  /*  참조코드 */ APPEND_CODE,
                                  /*상세참조코드*/ DETAIL_APPEND_CODE,
                                  /*  계정코드 */ ACCOUNT_CODE,

                                  /*차,대변구분코드*/
                                  CASE
                                   ---여기서의 case문들이 마이너스 계정으로 보낼 계정들을 정한다
                                          WHEN PARENT_CODE = '0101-0250' OR DETAIL_APPEND_CODE IN '0451-0470'
                                          THEN															--자산																							매출원가
                                                  CASE
                                                          WHEN ACCOUNT_CHARACTER LIKE '%차감%' THEN '대변'
                                                          ELSE '차변'
                                                  END
                                          WHEN APPEND_CODE IN ('0251-0330','0331-0400')
                                          THEN														--부채         자본
                                                  CASE
                                                          WHEN ACCOUNT_CHARACTER IN ('미처분이익','차기이월','차감','증가','평가손실')
                                                          THEN '차변'
                                                          ELSE '대변'
                                                  END
                                           WHEN DETAIL_APPEND_CODE = '0501-0600'
                                          THEN																			--제조원가

                                                           '차변'

                                          WHEN DETAIL_APPEND_CODE = '0401-0430'
                                          THEN																			--매출
                                                  CASE
                                                          WHEN A3_NAME IN ('매출환입및에누리', '매출할인')
                                                          THEN '차변'
                                                          ELSE '대변'
                                                  END
                                          WHEN DETAIL_APPEND_CODE = '0801-0900'
                                          THEN																				--판관비
                                                  CASE
                                                          WHEN A3_NAME IN ('대손충당금환입','퇴직급여충당부채환입')
                                                          THEN '대변'
                                                          ELSE '차변'
                                                  END
                                          WHEN DETAIL_APPEND_CODE = '0331-0340'
                                          THEN																			--자본금

                                                           '대변'
                                          WHEN DETAIL_APPEND_CODE IN '0901-0950'
                                          THEN '대변'															--영업외수익
                                          WHEN DETAIL_APPEND_CODE IN ('0951-0997','0998-0999')
                                          THEN '차변'																--영업외비용		법인세
                                  END AS SUBJECT_CODE

                          FROM(
                          	       SELECT
                             /*  부모코드 */ A1.PARENT_ACCOUNT_INNER_CODE AS PARENT_CODE,
                             /*  참조코드 */ A1.ACCOUNT_INNER_CODE        AS APPEND_CODE,
                             /*상세참조코드*/ A2.ACCOUNT_INNER_CODE        AS DETAIL_APPEND_CODE,
                             /*  계정코드 */ A3.ACCOUNT_INNER_CODE        AS ACCOUNT_CODE,
                             /*   구분  */ A3.ACCOUNT_CHARACTER         AS ACCOUNT_CHARACTER,
                             /*  계정과목 */ A3.ACCOUNT_NAME              AS A3_NAME

                                  FROM   ACCOUNT A1,
                                         ACCOUNT A2,
                                         ACCOUNT A3,
                                         JOURNAL J
                                  WHERE
                                    A3.ACCOUNT_INNER_CODE       = J.ACCOUNT_INNER_CODE
                                  AND    A3.PARENT_ACCOUNT_INNER_CODE= A2.ACCOUNT_INNER_CODE(+)
                                  AND    A2.PARENT_ACCOUNT_INNER_CODE= A1.ACCOUNT_INNER_CODE(+)
	                              AND     J.ACCOUNT_INNER_CODE=P_ACCOUNT_CODE
	                              );





     SELECT SUBJECT_CODE INTO IS_DAECHA FROM TMP_LEDGERBY_ACCOUNT;






  IF IS_DAECHA='차변' THEN
  OPEN RESULT FOR
    SELECT
    T.A AS CARRY_FORWARD,
	S.REPORTING_DATE,
	J.CUSTOMER_CODE ,
      B.ACCOUNT_NAME,
	 NVL(J.LEFT_DEBTOR_PRICE,0) AS LEFT_DEBTOR_PRICE,
	 NVL(J.RIGHT_CREDITS_PRICE,0) AS RIGHT_CREDITS_PRICE,
	 T.A+SUM((NVL(J.LEFT_DEBTOR_PRICE,0)-NVL(J.RIGHT_CREDITS_PRICE,0))) OVER(ORDER BY S.REPORTING_DATE ASC ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW)  AS TOTAL_PRICE
	FROM JOURNAL J, SLIP S ,(SELECT (NVL(SUM(J.LEFT_DEBTOR_PRICE),0)-NVL(SUM(J.RIGHT_CREDITS_PRICE),0)) AS A
		FROM JOURNAL J, SLIP S
		WHERE J.SLIP_NO=S.SLIP_NO
        AND J.ACCOUNT_INNER_CODE= P_ACCOUNT_CODE
	AND S.REPORTING_DATE BETWEEN TRUNC(ADD_MONTHS(LAST_DAY(P_START_DAY)+1,-2))  AND  TRUNC(ADD_MONTHS(LAST_DAY(P_START_DAY),-1))) T ,     ACCOUNT B
	WHERE
	S.SLIP_STATUS='승인'
	AND J.SLIP_NO=S.SLIP_NO
     AND J.ACCOUNT_INNER_CODE=B.ACCOUNT_INNER_CODE
	AND J.ACCOUNT_INNER_CODE=  P_ACCOUNT_CODE
	AND S.REPORTING_DATE BETWEEN P_START_DAY   AND  P_END_DAY
    group by S.REPORTING_DATE
    , J.CUSTOMER_CODE,A
    ,B.ACCOUNT_NAME
    , NVL(J.LEFT_DEBTOR_PRICE,0),
     NVL(J.RIGHT_CREDITS_PRICE,0)
     ORDER BY S.REPORTING_DATE ASC ;


ELSIF IS_DAECHA ='대변' THEN
  OPEN RESULT FOR

    SELECT
     T.A   AS CARRY_FORWARD,
	S.REPORTING_DATE,
	J.CUSTOMER_CODE ,
    B.ACCOUNT_NAME,
	 NVL(J.LEFT_DEBTOR_PRICE,0) AS LEFT_DEBTOR_PRICE,
	 NVL(J.RIGHT_CREDITS_PRICE,0) AS RIGHT_CREDITS_PRICE,
	 T.A+SUM(NVL(J.RIGHT_CREDITS_PRICE,0)-NVL( J.LEFT_DEBTOR_PRICE,0)) OVER(ORDER BY S.REPORTING_DATE ASC ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW)  AS TOTAL_PRICE
	FROM JOURNAL J, SLIP S ,(SELECT (NVL(SUM(J.RIGHT_CREDITS_PRICE),0)-NVL(SUM(J.LEFT_DEBTOR_PRICE),0)) AS A
		FROM JOURNAL J, SLIP S
		WHERE J.SLIP_NO=S.SLIP_NO
        AND J.ACCOUNT_INNER_CODE= P_ACCOUNT_CODE
	     AND S.REPORTING_DATE
         BETWEEN TRUNC(ADD_MONTHS(LAST_DAY(P_START_DAY)+1,-2))  AND  TRUNC(ADD_MONTHS(LAST_DAY(P_START_DAY),-1))) T,     ACCOUNT B
	WHERE
	S.SLIP_STATUS='승인'
	AND J.SLIP_NO=S.SLIP_NO
	AND J.ACCOUNT_INNER_CODE=  P_ACCOUNT_CODE
    AND J.ACCOUNT_INNER_CODE=B.ACCOUNT_INNER_CODE
	AND S.REPORTING_DATE BETWEEN P_START_DAY   AND  P_END_DAY
    group by S.REPORTING_DATE,A,B.ACCOUNT_NAME, J.CUSTOMER_CODE,A, NVL(J.LEFT_DEBTOR_PRICE,0),
     NVL(J.RIGHT_CREDITS_PRICE,0) ORDER BY S.REPORTING_DATE ASC ;
END IF;

 ERROR_CODE := 0;
 ERROR_MSG := '계정별원장 성공';

EXCEPTION
  WHEN
    NO_DATA_FOUND
    THEN
      ERROR_CODE := -1;
      ERROR_MSG := '조회할 데이터가 없습니다.';
  WHEN
    OTHERS
    THEN
      ERROR_CODE := -2;
      ERROR_MSG := SQLERRM;
END P_LEDGERBY_ACCOUNT;
/

