create PACKAGE BODY          P_HR_VACATION
AS

PROCEDURE P_CREATE_ANNUAL_VACATION
(
    P_APPLY_YEAR_MONTH    IN       ANNUAL_VACATION_MANAGE.APPLY_YEAR_MONTH%TYPE,
    P_RESULT                        OUT    REF_CURSOR,
    P_ERROR_CODE               OUT     VARCHAR2,
    P_ERROR_MSG                 OUT     VARCHAR2
)
IS
    -- V : 값 //  VS : Y or N
    VS_FINALIZE                   VARCHAR2(1);   -- 마감여부
    V_HIREDATE                   WORK_INFO.HIREDATE%TYPE;  -- 입사날짜
    V_APPLY_MONTH           NUMBER(4);     -- 조회기준달
    V_PREVIOUS_MONTH      NUMBER(10);    -- 조회기준전달
    V_YEARS_OF_SERVICE      NUMBER(4);     -- 근속연수
    V_TOTAL_USING             NUMBER(4,2);     -- 휴가총사용개수(반차 + 연차)
    V_REMAIN_VACATION     NUMBER;  -- 잔여연차개수
    V_AFTERNOON_OFF        ANNUAL_VACATION_MANAGE.AFTERNOON_OFF%TYPE;  -- 반차사용개수
    V_MONTHLY_LEAVE        ANNUAL_VACATION_MANAGE.MONTHLY_LEAVE%TYPE;  -- 연차사용개수

BEGIN

    SAVEPOINT SAVEPOINT1;    -- SAVEPOINT 생성

    BEGIN
        SELECT DISTINCT(FINALIZE_STATUS) INTO VS_FINALIZE
        FROM ANNUAL_VACATION_MANAGE A, EMPLOYEE_BASIC B
        WHERE A.APPLY_YEAR_MONTH = P_APPLY_YEAR_MONTH
        AND B.EMP_CODE=A.EMP_CODE;

        EXCEPTION
            WHEN OTHERS THEN
                P_ERROR_CODE := '0';
                P_ERROR_MSG  := 'CONTINUE PROCEDURE';
    END;

    IF VS_FINALIZE = 'Y' THEN
        P_ERROR_CODE := '0';
        P_ERROR_MSG  := 'SUCCESS';

        BEGIN
            OPEN P_RESULT FOR
               SELECT A.EMP_CODE,
                          A.AFTERNOON_OFF,
                          A.APPLY_YEAR_MONTH,
                          A.MONTHLY_LEAVE,
                          A.REMAINING_HOLIDAY,
                          A.FINALIZE_STATUS,
                          B.EMP_NAME
               FROM ANNUAL_VACATION_MANAGE A, EMPLOYEE_BASIC B
               WHERE A.APPLY_YEAR_MONTH = P_APPLY_YEAR_MONTH
               AND A.EMP_CODE = B.EMP_CODE;
        END;
        RETURN;

    ELSE
        BEGIN
            DELETE FROM ANNUAL_VACATION_MANAGE A
            WHERE A.APPLY_YEAR_MONTH = P_APPLY_YEAR_MONTH;

            EXCEPTION
                WHEN OTHERS THEN
                    P_ERROR_CODE := '-1';
                    P_ERROR_MSG  := '마감되지 않은 적용일 데이터 삭제 실패';
                ROLLBACK TO SAVEPOINT1;
                RETURN;
        END;
    END IF;

-- ************************************************************************************************
-- 1월달(월초)라면 근속년수에 맞춰 연차를 생성, 아니라면 조회기준 전달 잔여연차개수를 가져옴
-- ************************************************************************************************
   FOR CUR_EMP IN ( SELECT emp_code FROM ANNUAL_VACATION WHERE YEAR = substr(P_APPLY_YEAR_MONTH,0,4))
   LOOP
          V_AFTERNOON_OFF := 0;
          V_MONTHLY_LEAVE := 0;
          V_TOTAL_USING := 0;
          V_YEARS_OF_SERVICE := 0;
          V_REMAIN_VACATION :=0;


            BEGIN
                SELECT COUNT(*) INTO V_MONTHLY_LEAVE  -- 연차사용개수
                FROM DAY_ATTD_MANAGE
                WHERE EMP_CODE= CUR_EMP.emp_code
                AND DAY_ATTD_CODE ='ASC005'
                AND APPLY_DAYS BETWEEN to_date(substr(P_APPLY_YEAR_MONTH,0,4)||'0101','yyyymmdd') AND LAST_DAY(to_date(P_APPLY_YEAR_MONTH,'yyyymm'));

                EXCEPTION
                WHEN NO_DATA_FOUND THEN
                        P_ERROR_CODE:='-1';
                        P_ERROR_MSG :='연차 데이터가 없습니다';
            END;

            BEGIN
                SELECT COUNT(*) INTO V_AFTERNOON_OFF -- 반차 사용 개수
                FROM DAY_ATTD_MANAGE
                WHERE EMP_CODE=  CUR_EMP.emp_code
                AND DAY_ATTD_CODE IN ('ASC006' ,'ASC007')
                AND APPLY_DAYS BETWEEN to_date(substr(P_APPLY_YEAR_MONTH,0,4)||'0101','yyyymmdd') AND  LAST_DAY(to_date(P_APPLY_YEAR_MONTH,'yyyymm'));

                EXCEPTION
                WHEN NO_DATA_FOUND THEN
                        P_ERROR_CODE:='-1';
                        P_ERROR_MSG :='반차 데이터가 없습니다';
            END;

            V_TOTAL_USING := V_MONTHLY_LEAVE + (V_AFTERNOON_OFF*0.5);


      -- 연차 업데이트는 마감처리 버튼을 클릭하면 할것


                  BEGIN
                SELECT   REMAIN_VACATION
                INTO V_REMAIN_VACATION
                FROM ANNUAL_VACATION
                WHERE EMP_CODE=  CUR_EMP.emp_code
                AND YEAR =  TO_NUMBER(SUBSTR(P_APPLY_YEAR_MONTH,0,4));
            END;


            BEGIN
                      INSERT
                      INTO ANNUAL_VACATION_MANAGE VALUES
                      (
                         CUR_EMP.emp_code, -- 사원코드
                          P_APPLY_YEAR_MONTH,
                          V_AFTERNOON_OFF,
                          V_MONTHLY_LEAVE,
                          V_REMAIN_VACATION,
                          'N',
                          V_TOTAL_USING
                      );

                EXCEPTION
                    WHEN DUP_VAL_ON_INDEX THEN
                        P_ERROR_CODE:='-1';
                        P_ERROR_MSG :='데이터가 이미 존재합니다';
                    RETURN;
                    WHEN OTHERS THEN
                         P_ERROR_CODE:='-1';
                         P_ERROR_MSG :='적용일 데이터 생성에 실패했습니다';
                    RETURN;
            END;

            -- emp 전부 돌릴거라서  loop 종료문 따로 만들어줄 필요없음
    END LOOP;
      COMMIT;
    BEGIN
        OPEN P_RESULT FOR
            SELECT A.EMP_CODE,
                       A.APPLY_YEAR_MONTH,
                       A.AFTERNOON_OFF,
                       A.MONTHLY_LEAVE,
                       A.REMAINING_HOLIDAY-A.TOTAL_USING REMAINING_HOLIDAY,
                       A.FINALIZE_STATUS,
                       B.EMP_NAME
            FROM ANNUAL_VACATION_MANAGE A, EMPLOYEE_BASIC B
            WHERE A.APPLY_YEAR_MONTH=P_APPLY_YEAR_MONTH
            AND A.EMP_CODE=B.EMP_CODE;
    END;
    P_ERROR_CODE:='0';
    P_ERROR_MSG :='SUCCESS';
END P_CREATE_ANNUAL_VACATION;

END P_HR_VACATION;
/

