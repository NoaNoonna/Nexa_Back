create PROCEDURE          "P_COST_STATEMENT"
       (
           V_REPORT_DATE IN SLIP.REPORTING_DATE%TYPE
         , --날짜
           ERROR_CODE OUT NUMBER
         , ERROR_MSG OUT VARCHAR2
         , RESULT OUT SYS_REFCURSOR
       )
   IS
       SEARCH_PERIOD_NO NUMBER;
IS_EARLY_PERIOD NUMBER;
BEGIN
    SEARCH_PERIOD_NO := 0;

    SELECT ACCOUNT_PERIOD_NO INTO SEARCH_PERIOD_NO --  1이냐 2냐 조회해서 SEARCH_PERIOD_NO담음
      FROM PERIOD -- 기수번호
     WHERE V_REPORT_DATE BETWEEN PERIOD_START_DATE AND PERIOD_END_DATE;
    -- 내가보려는날짜       시작날짜    테이블안에값    종료날짜
    IS_EARLY_PERIOD := SEARCH_PERIOD_NO-1;
    P_COMPUTE_COST_STATEMENT(SEARCH_PERIOD_NO, IS_EARLY_PERIOD); -- 당기
    P_COMPUTE_COST_STATEMENT(SEARCH_PERIOD_NO - 1, IS_EARLY_PERIOD-1); --전기
    OPEN RESULT FOR

    WITH E_COST_STATEMENT AS
           (SELECT *
             FROM TMP_COST_STATEMENT
            WHERE PERIOD_NO = (SEARCH_PERIOD_NO - 1)
           )
         , --전기 데이터를 담기
           COST_STATEMENT AS
           (SELECT *
             FROM TMP_COST_STATEMENT
            WHERE PERIOD_NO = SEARCH_PERIOD_NO
           ) --당기 데이터를 담기
    SELECT L.ACCOUNT_INNER_CODE
         , --계정코드
           L.ACCOUNT_NAME
         , --계정과목
           L.PARENT_ACCOUNT_CODE
         , --부모코드
           I.COST
         , --당기 세부금액
           I.COST_SUMMARY
         , --당기 합계금액
           E.COST AS EARLY_COST
         , --전기 세부금액
           E.COST_SUMMARY AS EARLY_COST_SUMMARY --전기 합계금액
      FROM
           (SELECT *
             FROM
                  (SELECT DISTINCT ACCOUNT_INNER_CODE
                       , ACCOUNT_NAME
                       , PARENT_ACCOUNT_CODE --DISTINCT = 중복데이터도 포함하겠다는 의미
                         --계정내부코드      ,      계정명         ,     상위계정내부코드
                    FROM
                         (SELECT *
                           FROM COST_STATEMENT I --당기원가계산
                             UNION ALL --두 테이블을 합쳐줌
                         SELECT *
                           FROM E_COST_STATEMENT
                         ) --전기원가계산
                  )
           ) L
         , COST_STATEMENT I
         , E_COST_STATEMENT E
     WHERE L.ACCOUNT_INNER_CODE = I.ACCOUNT_INNER_CODE(+)
           AND L.ACCOUNT_INNER_CODE = E.ACCOUNT_INNER_CODE(+)
           AND LENGTH(L.ACCOUNT_INNER_CODE)<3;
    --      START WITH L.PARENT_ACCOUNT_CODE IS NULL
    --      CONNECT BY PRIOR L.ACCOUNT_INNER_CODE = L.PARENT_ACCOUNT_CODE;
    ERROR_CODE := 0;
    ERROR_MSG := '원가명세서 성공';
EXCEPTION
WHEN NO_DATA_FOUND THEN
    ERROR_CODE := -1;
    ERROR_MSG := '조회할 데이터가 없습니다.';
WHEN OTHERS THEN
    ERROR_CODE := -2;
    ERROR_MSG := SQLERRM;
END P_COST_STATEMENT;
/

