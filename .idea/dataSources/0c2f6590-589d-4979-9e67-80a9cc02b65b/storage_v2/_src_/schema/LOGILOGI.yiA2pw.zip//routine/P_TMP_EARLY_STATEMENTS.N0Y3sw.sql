create PROCEDURE          "P_TMP_EARLY_STATEMENTS"(
	period_num IN VARCHAR2 -- 기수(6)
)
IS

CURSOR GET_EARLY_STATEMENT --커서 선언
IS

WITH TRIAL_BALANCE AS(
SELECT
	period_num AS ACCOUNT_PERIOD_NO,
	/*  레벨링   ↓*/
	LEV lev,
	/*  조인코드 ↓*/
	CODE,
	/*  차변잔액 ↓*/
	DEBITS_SUM_BALANCE,
	/*  차변합계 ↓*/
	DEBITS_SUM,
	/*  계정과목 ↓*/
	ACCOUNT_NAME,
	/*  대변합계 ↓*/
	CREDITS_SUM,
	/*  대변잔액 ↓*/
	CREDITS_SUM_BALANCE
	--값이 있는것만 조회하면서 내림차순 정렬
FROM
	(
	SELECT
		-- TABLE5
    /*  레벨링   */
		LEV,
		/*  조인코드 */
		CODE,
		/*  차변잔액 */
		DEBITS_SUM_BALANCE,
		/*  차변합계 */
		DEBITS_SUM,
		DECODE(CONTRA_ACCOUNT, 'Y', '└') || A1.ACCOUNT_NAME AS ACCOUNT_NAME,
		--차감인 계정 ㄴ달아주는거
    /*  대변합계 */
		CREDITS_SUM,
		/*  대변잔액 */
		CREDITS_SUM_BALANCE
	FROM
		ACCOUNT A1,
		(
		SELECT
			-- TABLE4
	    /*레벨링*/
			--ex)자본이면 레벨1  유동자산 무형자산은 레밸2 나머지 자본목에 속하는 최하위 계정과목은 3이 된다.
	    CASE
				WHEN ACCOUNT_CODE IS NOT NULL THEN 3
				WHEN DETAIL_APPEND_CODE IS NOT NULL THEN 2
				WHEN APPEND_CODE IS NOT NULL THEN 1
			END AS LEV,
			/*조인코드*/
			CASE
				--순서대로 값이 있는것부터 코드를 지정, 레벨별로 나눠서 계정코드를 할당
	        WHEN ACCOUNT_CODE IS NOT NULL THEN ACCOUNT_CODE
				WHEN DETAIL_APPEND_CODE IS NOT NULL THEN DETAIL_APPEND_CODE
				WHEN APPEND_CODE IS NOT NULL THEN APPEND_CODE
			END AS CODE,
			/*  참조코드 ↓*/
			APPEND_CODE,
			/*상세참조코드↓*/
			DETAIL_APPEND_CODE,
			/*  ACCOUNT_CODE ↓*/
			ACCOUNT_CODE,
			/*  차변잔액 ↓*/
			DECODE( SIGN(SUM(DEBITS)-SUM(CREDITS) ), 1 , SUM(DEBITS)-SUM(CREDITS) , 0 )
			--SIGN 양수면1 , 음수면 -1
	                AS DEBITS_SUM_BALANCE,
			/*  차변합계 ↓*/
			SUM(DEBITS) AS DEBITS_SUM,
			/*  대변합계 ↓*/
			SUM(CREDITS)AS CREDITS_SUM,
			/*  대변잔액 ↓*/
			DECODE(SIGN(SUM(CREDITS)-SUM(DEBITS) ), 1, SUM(CREDITS)-SUM(DEBITS), 0 )
	                AS CREDITS_SUM_BALANCE,
			/*  차감계정 ↓*/
			CASE
				WHEN ACCOUNT_CODE IS NOT NULL
				AND MAX(ACCOUNT_CHARACTER) LIKE '%차감%' THEN 'Y'
				ELSE 'N'
			END AS CONTRA_ACCOUNT
		FROM
			(
			--ROLLUP해줌
			SELECT
				-- TABLE2
		    /*  참조코드 ↓*/
				APPEND_CODE,
				/*상세참조코드↓*/
				DETAIL_APPEND_CODE,
				/*  계정코드 ↓*/
				ACCOUNT_CODE,
				/*  차변금액 ↓*/
				DEBITS,
				/*  대변금액 ↓*/
				CREDITS,
				/*   구분   ↓*/
				ACCOUNT_CHARACTER
			FROM
				(
				--**********************************************************************************************************************************
				--전기 당기 이익잉여금 합
				--**********************************************************************************************************************************
				--당기-------------------------------------------
				SELECT
					/*  부모코드 ↓*/
					A1.PARENT_ACCOUNT_INNER_CODE AS PARENT_CODE,
					--예시(0101-0250자산) 상위계정 내부코드
			    /*  참조코드 ↓*/
					A1.ACCOUNT_INNER_CODE AS APPEND_CODE,
					--예시(0176-0250비유동자산) 계정내부코드
			    /*상세참조코드↓*/
					A2.ACCOUNT_INNER_CODE AS DETAIL_APPEND_CODE,
					--예시(0195-0217유형자산) 계정내부코드
			    /*  계정코드 ↓*/
					A3.ACCOUNT_INNER_CODE AS ACCOUNT_CODE,
					--예시(0201토지) 계정내부코드
			    /*   구분   ↓*/
					A3.ACCOUNT_CHARACTER AS ACCOUNT_CHARACTER,
					--예시(비상) 계정그룹명
			    /*  계정과목 ↓*/
					A3.ACCOUNT_NAME AS A3_NAME,
					--예시(토지)	계정명
			    /*당기차변금액↓*/
					NVL(j.LEFT_DEBTOR_PRICE, 0) AS DEBITS,
					--예시(1000)	null이면 0이되는 차변
			    /*당기대변금액↓*/
					NVL(j.RIGHT_CREDITS_PRICE, 0) AS CREDITS
					--예시(0,커플로 차변,대변 항목 있음) null이면 0이되는 대변
				FROM
					ACCOUNT A1,
					ACCOUNT A2,
					ACCOUNT A3,
					--부모와 자식코드 매칭을 위해 3개 선언함
					SLIP S,
					--전표
					JOURNAL J
					--분개
				WHERE
					S.SLIP_NO = J.SLIP_NO
					--전표와 분개의 기수가 같을 시(예를 들어6)
					AND S.ACCOUNT_PERIOD_NO = period_num
					----기수(6)
					AND S.SLIP_STATUS = '승인완료'
					--승인완료인것
					AND A3.ACCOUNT_INNER_CODE = J.ACCOUNT_INNER_CODE
					AND A3.PARENT_ACCOUNT_INNER_CODE = A2.ACCOUNT_INNER_CODE(+)
					--자식(토지)와 부모(유형)매칭
					AND A2.PARENT_ACCOUNT_INNER_CODE = A1.ACCOUNT_INNER_CODE(+)
					--자식(유형)와 부모(비유동)매칭
				/*
					선택된 period_num에 있는 '승인완료'된 전표에 적혀 있는 분개에서 계정코드가 같은 것들의
					부모코드, 참조코드, 상세참조코드, 계정코드, 구분(그룹명), 계정과목, 차변금액, 대변금액을 조회한다.

				*/
					)
				-- 롤업하기 전 필요한 컬럼만 선택을 한다.
	)
		GROUP BY
			ROLLUP( APPEND_CODE,
			DETAIL_APPEND_CODE,
			ACCOUNT_CODE )
			--롤업으로 부모계정별 차,대변 합계가 계산 된다.
    ) A2
	WHERE
		A1.ACCOUNT_INNER_CODE(+)= A2.CODE
		-- 일반 계정과목을 아우터 조인으로 연결하여 code에 맞는 계정명을 붙여 준다.
		-- 차감 금액에는 ㄴ을 붙여준다.
)
WHERE
	DEBITS_SUM>0
	OR CREDITS_SUM>0
ORDER BY
	SUBSTR(CODE, 1, 4),
	SUBSTR(CODE, 6) DESC NULLS LAST
)

-- ============================================================with절 끝


SELECT * FROM TRIAL_BALANCE WHERE ACCOUNT_NAME IS NOT NULL
--TRIAL_BALANCE에 with절 출력값이 들어가있음

UNION ALL

SELECT
    period_num                    AS ACCOUNT_PERIOD_NO,
    NULL,
    NULL,
    SUM(DEBITS_SUM_BALANCE),
    SUM(DEBITS_SUM),
    UNISTR('합계') AS ACCOUNT_NAME,
    SUM(CREDITS_SUM),
    SUM(CREDITS_SUM_BALANCE)
FROM TRIAL_BALANCE
WHERE LEV=3;



TYPE EARLY_STATEMENT_TYPE IS RECORD (--타입선언 EARLY_STATEMENT_TYPE을 RECORD TYPE으로 선언한다.
                    ACCOUNT_PERIOD_NO VARCHAR2(2),
                    LEV NUMBER(38),
                    CODE VARCHAR2(20),
                    DEBITS_SUM_BALANCE NUMBER(38),
                    DEBITS_SUM NUMBER(38),
                    ACCOUNT_NAME NVARCHAR2(20),
                    CREDITS_SUM NUMBER(38),
                    CREDITS_SUM_BALANCE NUMBER(38)
);

EARLY_STATEMENTS2 EARLY_STATEMENT_TYPE;

BEGIN

    DELETE FROM TMP_EARLY_STATEMENTS2;

    OPEN GET_EARLY_STATEMENT ;--커서열기

    LOOP
    FETCH GET_EARLY_STATEMENT INTO EARLY_STATEMENTS2;
    EXIT WHEN GET_EARLY_STATEMENT%NOTFOUND;

    INSERT INTO TMP_EARLY_STATEMENTS2 VALUES(--레코드에 값을 넣어줌
        EARLY_STATEMENTS2.ACCOUNT_PERIOD_NO ,
        EARLY_STATEMENTS2.LEV,
        EARLY_STATEMENTS2.CODE,
        EARLY_STATEMENTS2.DEBITS_SUM_BALANCE,
        EARLY_STATEMENTS2.DEBITS_SUM,
        EARLY_STATEMENTS2.ACCOUNT_NAME,
        EARLY_STATEMENTS2.CREDITS_SUM,
        EARLY_STATEMENTS2.CREDITS_SUM_BALANCE
    );

END LOOP;

END P_TMP_EARLY_STATEMENTS;
/

