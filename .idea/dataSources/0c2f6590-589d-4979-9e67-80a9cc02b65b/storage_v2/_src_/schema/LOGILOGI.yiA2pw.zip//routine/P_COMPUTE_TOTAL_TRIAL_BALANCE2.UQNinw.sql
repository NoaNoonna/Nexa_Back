create PROCEDURE          "P_COMPUTE_TOTAL_TRIAL_BALANCE2" (
    SEARCH_PERIOD_NO IN NUMBER
)
IS

BEGIN
      DELETE FROM TOTAL_TRIAL_BALANCE1 A WHERE A.ACCOUNT_PERIOD_NO = SEARCH_PERIOD_NO;
--          IF SEARCH_PERIOD_NO = LAST_PERIOD_NO THEN
                  INSERT INTO TOTAL_TRIAL_BALANCE1(ACCOUNT_PERIOD_NO, LEV, CODE, DEBITS_SUM_BALANCE, DEBITS_SUM, ACCOUNT_NAME, CREDITS_SUM, CREDITS_SUM_BALANCE)
                SELECT SEARCH_PERIOD_NO AS ACCOUNT_PERIOD_NO,
                         /*레벨링*/  LEV,
                         /*조인코드*/ CODE,
                         /*차변잔액*/ SUM(DEBITS_SUM_BALANCE) AS DEBITS_SUM_BALANCE,  --별칭 부여
                         /*차변합계*/ SUM(DEBITS_SUM) AS DEBITS_SUM,		--별칭 부여
                         /*계정과목*/ ACCOUNT_NAME,
                         /*대변합계*/ SUM(CREDITS_SUM) AS CREDITS_SUM,		--별칭 부여
                         /*대변잔액*/ SUM(CREDITS_SUM_BALANCE) AS CREDITS_SUM_BALANCE		--별칭 부여
                FROM(

                SELECT               -- TABLE5
                         /*레벨링*/  LEV,
                         /*조인코드*/ CODE,
                         /*차변잔액*/ DEBITS_SUM_BALANCE,
                         /*차변합계*/ DEBITS_SUM,
                         /*계정과목*/ LPAD(' ',(LEV-1)*4) || NVL(A1.ACCOUNT_NAME,'합계') AS ACCOUNT_NAME,
                         /*대변합계*/ CREDITS_SUM,
                         /*대변잔액*/ CREDITS_SUM_BALANCE
                FROM     ACCOUNT A1,
                         (SELECT               -- TABLE4

                                  /*레벨링*/ --ex)자본이면 레벨1  유동자산 무형자산은 레밸2 나머지 자본목에 속하는 최하위 계정과목은 3이 된다.
                                  CASE
                                           WHEN ACCOUNT_CODE IS NOT NULL THEN 3
                                           WHEN DETAIL_APPEND_CODE IS NOT NULL THEN 2
                                           WHEN APPEND_CODE IS NOT NULL THEN 1
                                  END AS LEV,

                                  /*조인코드*/
                                  CASE
                                           WHEN ACCOUNT_CODE IS NOT NULL THEN ACCOUNT_CODE
                                           WHEN DETAIL_APPEND_CODE IS NOT NULL THEN DETAIL_APPEND_CODE
                                           WHEN APPEND_CODE IS NOT NULL THEN APPEND_CODE
                                  END AS CODE,

                                  /*  참조코드 */ APPEND_CODE,
                                  /*상세참조코드*/ DETAIL_APPEND_CODE,
                                  /*  계정코드 */ ACCOUNT_CODE,
                                  /*  차변잔액 */
                                  DECODE(SUBJECT_CODE, '차변', SUM(DEBITS - CREDITS),0) AS DEBITS_SUM_BALANCE,
                                  /*  차변합계 */ SUM(DEBITS) AS DEBITS_SUM,
                                  /*  대변합계 */ SUM(CREDITS) AS CREDITS_SUM,
                                  /*  대변잔액 */
                                  DECODE(SUBJECT_CODE, '대변', SUM(CREDITS - DEBITS),0) AS CREDITS_SUM_BALANCE

                         FROM     (SELECT               -- TABLE2
                                                  /*  참조코드 */ APPEND_CODE,
                                                  /*상세참조코드*/ DETAIL_APPEND_CODE,
                                                  /*  계정코드 */ ACCOUNT_CODE,

                                                  /*차,대변구분코드*/
                                                  CASE
                                                   ---여기서의 case문들이 마이너스 계정으로 보낼 계정들을 정한다
                                                          WHEN PARENT_CODE = '0101-0250' OR DETAIL_APPEND_CODE IN '0451-0470'
                                                          THEN
                                                                  CASE
                                                                          WHEN ACCOUNT_CHARACTER LIKE '%차감%' THEN '대변'
                                                                          ELSE '차변'
                                                                  END
                                                          WHEN APPEND_CODE IN ('0251-0330','0331-0400')
                                                          THEN
                                                                  CASE
                                                                          WHEN ACCOUNT_CHARACTER IN ('미처분이익','차기이월','차감','증가','평가손실')
                                                                          THEN '차변'
                                                                          ELSE '대변'
                                                                  END
                                                          WHEN DETAIL_APPEND_CODE = '0401-0430'
                                                          THEN
                                                                  CASE
                                                                          WHEN A3_NAME IN ('매출환입및에누리', '매출할인')
                                                                          THEN '차변'
                                                                          ELSE '대변'
                                                                  END
                                                          WHEN DETAIL_APPEND_CODE = '0801-0900'
                                                          THEN
                                                                  CASE
                                                                          WHEN A3_NAME IN ('대손충당금환입','퇴직급여충당부채환입')
                                                                          THEN '대변'
                                                                          ELSE '차변'
                                                                  END
                                                          WHEN DETAIL_APPEND_CODE IN '0901-0950'
                                                          THEN '대변'
                                                          WHEN DETAIL_APPEND_CODE IN ('0951-0997','0998-0999')
                                                          THEN '차변'
                                                  END AS SUBJECT_CODE,

                                                  /*차변금액*/ DEBITS,
                                                  /*대변금액*/ CREDITS

                                          FROM    (                  -- TABLE1
                                                      --전기
  --                                                     SELECT
  --                                            /*  부모코드 */ A1.PARENT_ACCOUNT_INNER_CODE AS PARENT_CODE,
  --                                            /*  참조코드 */ A1.ACCOUNT_INNER_CODE        AS APPEND_CODE,
  --                                            /*상세참조코드*/ A2.ACCOUNT_INNER_CODE        AS DETAIL_APPEND_CODE,
  --                                            /*  계정코드 */ A3.ACCOUNT_INNER_CODE        AS ACCOUNT_CODE,
  --                                            /*   구분  */ A3.ACCOUNT_CHARACTER         AS ACCOUNT_CHARACTER,
  --                                            /*  계정과목 */ A3.ACCOUNT_NAME              AS A3_NAME,
  --                                            /*전기차변금액*/ NVL(E.LEFT_DEBTOR_PRICE,0)   AS DEBITS,
  --                                            /*전기대변금액*/ NVL(E.RIGHT_CREDITS_PRICE,0) AS CREDITS
  --                                                FROM    ACCOUNT A1,
  --                                                        ACCOUNT A2,
  --                                                        ACCOUNT A3,
  --                                                        EARLY_STATEMENTS E,
  --                                                        PERIOD P
  --                                                WHERE   P.ACCOUNT_PERIOD_NO         = SEARCH_PERIOD_NO-1
  --                                                AND     E.ACCOUNT_PERIOD_NO         = P.ACCOUNT_PERIOD_NO
  --                                                AND     E.ACCOUNT_INNER_CODE        = A3.ACCOUNT_INNER_CODE
  --                                                AND     A3.PARENT_ACCOUNT_INNER_CODE= A2.ACCOUNT_INNER_CODE(+)
  --                                                AND     A2.PARENT_ACCOUNT_INNER_CODE= A1.ACCOUNT_INNER_CODE(+)
  --                                                AND     E.ACCOUNT_INNER_CODE NOT LIKE '%-%'

  --                                                UNION ALL

                                                  --당기

                                                  SELECT
                                             /*  부모코드 */ A1.PARENT_ACCOUNT_INNER_CODE AS PARENT_CODE,
                                             /*  참조코드 */ A1.ACCOUNT_INNER_CODE        AS APPEND_CODE,
                                             /*상세참조코드*/ A2.ACCOUNT_INNER_CODE        AS DETAIL_APPEND_CODE,
                                             /*  계정코드 */ A3.ACCOUNT_INNER_CODE        AS ACCOUNT_CODE,
                                             /*   구분  */ A3.ACCOUNT_CHARACTER         AS ACCOUNT_CHARACTER,
                                             /*  계정과목 */ A3.ACCOUNT_NAME              AS A3_NAME,
                                             /*당기차변금액*/ NVL(j.LEFT_DEBTOR_PRICE,0)   AS DEBITS,
                                             /*당기대변금액*/ NVL(j.RIGHT_CREDITS_PRICE,0) AS CREDITS
                                                  FROM   ACCOUNT A1,
                                                         ACCOUNT A2,
                                                         ACCOUNT A3,
                                                         SLIP S,
                                                         JOURNAL J,
                                                         PERIOD P
                                                  WHERE  S.SLIP_NO                   = J.SLIP_NO
                                                  AND    S.ACCOUNT_PERIOD_NO         = P.ACCOUNT_PERIOD_NO
                                                  AND    P.ACCOUNT_PERIOD_NO         = SEARCH_PERIOD_NO
                                                  AND    S.SLIP_STATUS               = '승인완료'
                                                  AND    A3.ACCOUNT_INNER_CODE       = J.ACCOUNT_INNER_CODE
                                                  AND    A3.PARENT_ACCOUNT_INNER_CODE= A2.ACCOUNT_INNER_CODE(+)
                                                  AND    A2.PARENT_ACCOUNT_INNER_CODE= A1.ACCOUNT_INNER_CODE(+)
                                          )
                         )
                             GROUP BY ROLLUP(SUBJECT_CODE,APPEND_CODE, DETAIL_APPEND_CODE, ACCOUNT_CODE)
                         )
                         A2
                WHERE    A1.ACCOUNT_INNER_CODE(+)=A2.CODE
                )
                GROUP BY  LEV,  CODE, ACCOUNT_NAME
                ORDER BY SUBSTR(CODE, 1, 4), SUBSTR(CODE, 6) DESC NULLS LAST;
--            ELSIF (SEARCH_PERIOD_NO = 1) AND (SEARCH_PERIOD_NO <> LAST_PERIOD_NO) THEN --이부분은 오로지 1기를 위한 맞춤이다. early에 1기의 합계가 없기에 어쩔 수 없다.
--              INSERT INTO TOTAL_TRIAL_BALANCE1(ACCOUNT_PERIOD_NO, LEV, CODE, DEBITS_SUM_BALANCE, DEBITS_SUM, ACCOUNT_NAME, CREDITS_SUM, CREDITS_SUM_BALANCE)
--                SELECT SEARCH_PERIOD_NO AS ACCOUNT_PERIOD_NO,
--                           LEV, /*레벨링*/
--                           ACCOUNT_INNER_CODE AS  CODE, /*조인코드*/
--                           LEFT_DEBTOR_PRICE as DEBITS_SUM_BALANCE, /*차변잔액*/
--                           LEFT_DEBTOR_PRICE AS DEBITS_SUM, /*차변합계*/
--                           LPAD(' ',(LEV-1)*4) || NVL(ACCOUNT_NAME,'합계') AS ACCOUNT_NAME, /*계정과목*/
--                           RIGHT_CREDITS_PRICE AS CREDITS_SUM, /*대변합계*/
--                           RIGHT_CREDITS_PRICE as CREDITS_SUM_BALANCE /*대변잔액*/
--                FROM ( SELECT e.lev,
--                                      e.ACCOUNT_INNER_CODE,
--                                      e.DEBITS_SUM,
--                                      e.LEFT_DEBTOR_PRICE,
--                                      a.ACCOUNT_NAME,
--                                      e.RIGHT_CREDITS_PRICE,
--                                      e.CREDITS_SUM
--                            FROM EARLY_STATEMENTS e, ACCOUNT a
--                            WHERE e.ACCOUNT_PERIOD_NO=1
--                            AND e.ACCOUNT_INNER_CODE=a.ACCOUNT_INNER_CODE(+))
--                ORDER BY SUBSTR(CODE, 1, 4), SUBSTR(CODE, 6) DESC NULLS LAST;
--        ELSE
--                  INSERT INTO TOTAL_TRIAL_BALANCE1(ACCOUNT_PERIOD_NO, LEV, CODE, DEBITS_SUM_BALANCE, DEBITS_SUM, ACCOUNT_NAME, CREDITS_SUM, CREDITS_SUM_BALANCE)
--                SELECT SEARCH_PERIOD_NO AS ACCOUNT_PERIOD_NO,
--                           LEV, /*레벨링*/
--                           ACCOUNT_INNER_CODE AS  CODE, /*조인코드*/
--                           LEFT_DEBTOR_PRICE as DEBITS_SUM_BALANCE, /*차변잔액*/
--                           DEBITS_SUM, /*차변합계*/
--                           LPAD(' ',(LEV-1)*4) || NVL(ACCOUNT_NAME,'합계') AS ACCOUNT_NAME, /*계정과목*/
--                           CREDITS_SUM,  /*대변합계*/
--                           RIGHT_CREDITS_PRICE as CREDITS_SUM_BALANCE  /*대변잔액*/
--                FROM(SELECT e.lev,
--                                    e.ACCOUNT_INNER_CODE,
--                                    e.DEBITS_SUM,
--                                    e.LEFT_DEBTOR_PRICE,
--                                    a.ACCOUNT_NAME,
--                                    e.RIGHT_CREDITS_PRICE,
--                                    e.CREDITS_SUM
--                          FROM EARLY_STATEMENTS e,ACCOUNT a
--                          WHERE e.ACCOUNT_PERIOD_NO=SEARCH_PERIOD_NO
--                          AND e.ACCOUNT_INNER_CODE=a.ACCOUNT_INNER_CODE(+))
--                ORDER BY SUBSTR(CODE, 1, 4), SUBSTR(CODE, 6) DESC NULLS LAST;
--        END IF;
    COMMIT;
END P_COMPUTE_TOTAL_TRIAL_BALANCE2;
/

