create PROCEDURE          P_BUDGET_STATUS(
v_account_period_no in budget.account_period_no%type,
v_workplace_code in budget.workplace_code%type,
v_dept_code in budget.dept_code%type,
RESULT OUT SYS_REFCURSOR)
is
BEGIN

open result for
--예산실적현황

select
a.account_inner_code,
a.account_name,
a.ABR,
a.annualbudget,
a.remaining_budget,
a.budget_exec_rate,
b.ambr,
b.budget,
b.remaining_month_budget,
b.month_budget_exec_rate
from
(--누계 예산 실적

select
b.account_inner_code,
b.account_name,
nvl(ABR,0) ABR,
annualbudget,
annualbudget-nvl(ABR,0) remaining_budget,                  --잔액
nvl(round((ABR/annualbudget)*100,1),0) budget_exec_rate    --집행률(%)
from
(--특정 회계기간 동안 특정 부서의 사용 예산, 전표(slip)와 분개장(journal) 테이블에 사업장(workplace_code) 정보는 들어가지 않음

select
a.account_inner_code,
a.account_name,
sum(j.left_debtor_price) ABR--accumulatedbudgetrecord
from
journal j,
slip s,
account a
where
j.slip_no=s.slip_no and
a.account_inner_code=j.account_inner_code and
a.budget='T' and                 --예산
j.balance_division='차변' and     --자산의 증가, 자본의 감소, 부채의 감소, 비용의 발생 ex)재료비
s.slip_status='승인' and          --승인 받은 전표
account_period_no=v_account_period_no and         --회계연도, in 매개변수
dept_code=v_dept_code                --부서, in 매개변수
group by a.account_inner_code,
a.account_name
) a,
(
--특정 연도의 특정 사업장의 특정 부서의 회계 기간 동안 편성된 예산의 합계

select
a.account_inner_code,
a.account_name,
b.account_period_no,
dept_code,
workplace_code,
m1_Budget+m2_Budget+m3_Budget+m4_Budget+m5_Budget+m6_Budget+
m7_Budget+m8_Budget+m9_Budget+m10_Budget+m11_Budget+m12_Budget as annualbudget
from budget b,account a
where
b.account_inner_code=a.account_inner_code and
dept_code=v_dept_code and          --부서, in 매개변수
account_period_no=v_account_period_no and       --회계연도, in 매개변수
workplace_code=v_workplace_code and     --사업장, in 매개변수
budgeting_code=2                --budgeting_code=2는 예산 편성
) b
where a.account_inner_code(+)=b.account_inner_code) a,
(--당월 예산 실적

select
b.account_inner_code,
b.account_name,
nvl(ambr,0) ambr,
month,
budget,
budget-nvl(ambr,0) remaining_month_budget,
nvl(round((ambr/budget)*100),0) month_budget_exec_rate
from
(--당월에 사용한 예산의 합계
select
a.account_inner_code,
a.account_name,
sum(j.left_debtor_price) AMBR--accumulatedmonthbudgetrecord
from
journal j,
slip s,
account a
where

--당월에 사용한 예산 가져오기
to_date(reporting_date) between trunc(sysdate,'MM') and last_day(sysdate) and
j.slip_no=s.slip_no and
a.account_inner_code=j.account_inner_code and
a.budget='T' and                --예산
j.balance_division='차변' and     --자산의 증가, 자본의 감소, 부채의 감소, 비용의 발생 ex)재료비
s.slip_status='승인' and          --승인 받은 전표
account_period_no=v_account_period_no and       --회계연도, in 매개변수
dept_code=v_dept_code              --부서, in 매개변수
group by a.account_inner_code,
a.account_name
) a,
(--당월 예산 구하기
--3단계: 당월 예산 구하기

select
account_inner_code,
account_name,
r_cnt month,
decode(r_cnt, --decode 함수로 월별 예산 구하기
1,m1_budget,
2,m2_budget,
3,m3_budget,
4,m4_budget,
5,m5_budget,
6,m6_budget,
7,m7_budget,
8,m8_budget,
9,m9_budget,
10,m10_budget,
11,m11_budget,
12,m12_budget) budget
from
(select rownum r_cnt from user_tables where rownum<13) a, --테이블을 12개로 복제하기
(select
a.account_inner_code,
a.account_name,
m1_budget,
m2_budget,
m3_budget,
m4_budget,
m5_budget,
m6_budget,
m7_budget,
m8_budget,
m9_budget,
m10_budget,
m11_budget,
m12_budget
from budget b,account a
where
b.account_inner_code=a.account_inner_code and
dept_code=v_dept_code and      --부서, in 매개변수
account_period_no=v_account_period_no and   --회계연도, in 매개변수
workplace_code=v_workplace_code and  --사업장, in 매개변수
budgeting_code=2            --budgeting_code=2, 예산편성
) b
where r_cnt=to_char(sysdate,'MM') --당월 예산 구하기
) b
where a.account_inner_code(+)=b.account_inner_code) b
where a.account_inner_code=b.account_inner_code;


END P_BUDGET_STATUS;
/

