create PROCEDURE          P_COMPUTE_CASHFLOW_STATEMENT (
SEARCH_PERIOD_NO IN NUMBER,  --3
IS_EARLY_PERIOD IN NUMBER)   --2
IS

BEGIN

--현금흐름표 설계
--영업활도 현금흐름(01)=당기순이익(02)+현금의 유입이 없는 수익 등의 가산(03)-현금의 유입이 없는 수익 등의 차감(04)+영업활동으로 인한 자산부채의 변동(05)
--투자활동 현금흐름(06)=투자활동으로 인한 현금유입액(07)+투자활동으로 인한 현금유출액(08)
--재무활동 현금흐름(09)=재무활동으로 인한 현금 유입액(10)-재무활동으로 인한 현금유출액(11)
--현금의 증가(12) = (01)+(06)+(09)
--기초의 현금(13) = 전기에서 넘어온 현금
--기말의 현금(14) = 현금의 증가(12) + 기초의 현금(13) 기말의 현금은 다음해로 넘어간다.

  IF IS_EARLY_PERIOD <> 0 THEN /*당기*/
    INSERT INTO TMP_CASHFLOW_STATEMENT(ACCOUNT_INNER_CODE, ACCOUNT_NAME, PARENT_ACCOUNT_CODE, CASHFLOW, CASHFLOW_SUMMARY,
                                     PERIOD_NO) -- ACCOUNT 계정,PARENT_ACCOUNT_CODE 임시테이블손익계산서

    WITH

    --당기순이익
           INCOME AS (
      SELECT '02' AS ACCOUNT_INNER_CODE
            , UNISTR('당기순이익') AS ACCOUNT_NAME
            , INCOME_SUMMARY  AS CASHFLOW
            , NULL AS CASHFLOW_SUMMARY
         FROM (SELECT F_NET_INCOME(SEARCH_PERIOD_NO, IS_EARLY_PERIOD) INCOME_SUMMARY
            FROM DUAL)
      )

      ,INCOME_DETAIL AS (
        SELECT '02' ACCOUNT_INNER_CODE,
               UNISTR('(1)당기순이익') AS ACCOUNT_NAME,
               '02'           AS PARENT_ACCOUNT_CODE,
               CASHFLOW AS CASHFLOW,
               NULL           AS CASHFLOW_SUMMARY
        FROM INCOME ),

--현금의 유출이 없는 비용 등의 가산
--퇴직급여,감가상각비,대손상각비,외화환산손실,유형자산처분손실,재고자산폐기손실, 무형자산상각비
--파생상품평가손실
      SALES_DETAIL AS (
        SELECT ACCOUNT_INNER_CODE,--계정내부코드
               ACCOUNT_NAME,      --계정명
               '03'                     AS PARENT_ACCOUNT_CODE,--상위계정내부코드(임시테이블 손익계산서)
               DEBITS_SUM AS CASHFLOW,             --세부금액(")
               --차변(합계)
               NULL                     AS CASHFLOW_SUMMARY      --합계금액(")
        FROM (
               SELECT J.ACCOUNT_INNER_CODE, --계정내부코드(계정과목)
                      A.ACCOUNT_NAME,       --계정명(계정과목)
                      SUM(NVL(J.LEFT_DEBTOR_PRICE, 0))   AS DEBITS_SUM, ---차변금액(분개) AS  차변(합계)임시시산표테이블
                      SUM(NVL(J.RIGHT_CREDITS_PRICE, 0)) AS CREDITS_SUM  --대변금액(분개) AS  대변(합계)임시시산표테이블
               FROM SLIP S, --전표
                    JOURNAL J, -- 분개
                    JOURNAL Y,
                    PERIOD P, -- 기수
                    ACCOUNT A -- 계정과목
               WHERE S.SLIP_NO = J.SLIP_NO --일련번호 전표번호,분개번호조인
                 AND J.ACCOUNT_INNER_CODE = A.ACCOUNT_INNER_CODE --계정,분개 내부계정코드
                 AND S.SLIP_STATUS LIKE '승인' --전표상태
                 AND J.SLIP_NO = Y.SLIP_NO
                 AND Y.ACCOUNT_INNER_CODE='0101'
                 AND S.ACCOUNT_PERIOD_NO = P.ACCOUNT_PERIOD_NO --회계기수일련번호
                 AND P.ACCOUNT_PERIOD_NO = SEARCH_PERIOD_NO
                 AND (
                                A.ACCOUNT_NAME = '퇴직급여'
                          OR A.ACCOUNT_NAME LIKE '%감가상각%'
                          OR A.ACCOUNT_NAME ='외화환산손실'
                          OR A.ACCOUNT_NAME = '유형자산처분손실'
                          OR A.ACCOUNT_NAME LIKE '재고자산%'
                          OR A.ACCOUNT_NAME = '무형자산상각비'
                          OR A.ACCOUNT_NAME = '파생상품평가손실'
                          OR A.ACCOUNT_NAME = '무형자산상각비')     --상위계정내부코드  매출
               GROUP BY J.ACCOUNT_INNER_CODE, A.ACCOUNT_NAME)
      ),
--현금의 유출이 없는 비용 등의 가산 총계
      SALES_SUMMARY AS (
                                     SELECT '03'         AS ACCOUNT_INNER_CODE,
                               UNISTR('(2)현금의 유출이 없는 비용 등의 가산') AS ACCOUNT_NAME,
                               '03'          AS PARENT_ACCOUNT_CODE,
                               SUM(CASHFLOW)          AS CASHFLOW,
                               NULL   AS CASHFLOW_SUMMARY
                        FROM SALES_DETAIL),

--현금의 유입이 없는 수익 등의 차감(04)
--유가증권평가이익,외환차익,외화환산이익,지분법이익,유형자산처분이익,사채상환이익
      DEDUCTION_DETAIL AS (
        SELECT ACCOUNT_INNER_CODE,--계정내부코드
               ACCOUNT_NAME,      --계정명
               '04'                     AS PARENT_ACCOUNT_CODE,--상위계정내부코드(임시테이블 손익계산서)
               DEBITS_SUM AS CASHFLOW,             --세부금액(")
               --대변(합계)
               NULL                     AS CASHFLOW_SUMMARY      --합계금액(")
        FROM (
               SELECT J.ACCOUNT_INNER_CODE, --계정내부코드(계정과목)
                      A.ACCOUNT_NAME,       --계정명(계정과목)
                      SUM(NVL(J.LEFT_DEBTOR_PRICE, 0))   AS DEBITS_SUM, ---차변금액(분개) AS  차변(합계)임시시산표테이블
                      SUM(NVL(J.RIGHT_CREDITS_PRICE, 0)) AS CREDITS_SUM  --대변금액(분개) AS  대변(합계)임시시산표테이블
               FROM SLIP S, --전표
                    JOURNAL J, -- 분개
                    JOURNAL Y,
                    PERIOD P, -- 기수
                    ACCOUNT A -- 계정과목
               WHERE S.SLIP_NO = J.SLIP_NO --일련번호 전표번호,분개번호조인
                 AND J.ACCOUNT_INNER_CODE = A.ACCOUNT_INNER_CODE --계정,분개 내부계정코드
                 AND S.SLIP_STATUS LIKE '승인' --전표상태
                 AND J.SLIP_NO = Y.SLIP_NO
                 AND Y.ACCOUNT_INNER_CODE='0101'
                 AND S.ACCOUNT_PERIOD_NO = P.ACCOUNT_PERIOD_NO --회계기수일련번호
                 AND P.ACCOUNT_PERIOD_NO = SEARCH_PERIOD_NO
                 AND (
                                A.ACCOUNT_CHARACTER = '유가증권'
                          OR A.ACCOUNT_NAME LIKE '%증권평가이익%'
                          OR A.ACCOUNT_NAME ='외환차익'
                          OR A.ACCOUNT_NAME = '외화환산이익'
                          OR A.ACCOUNT_NAME = '지분법이익'
                          OR A.ACCOUNT_NAME = '유형자산처분이익'
                          OR A.ACCOUNT_NAME = '사채상환이익')     --상위계정내부코드  매출
               GROUP BY J.ACCOUNT_INNER_CODE, A.ACCOUNT_NAME)
      ),
--현금의 유입이 없는 수익 등의 차감 총계
      DEDUCTION_SUMMARY AS (
                                     SELECT '04'         AS ACCOUNT_INNER_CODE,
                               UNISTR('(3)현금의 유입이 없는 수익 등의 차감') AS ACCOUNT_NAME,
                               '04'          AS PARENT_ACCOUNT_CODE,
                               SUM(CASHFLOW)         AS CASHFLOW,
                               NULL   AS CASHFLOW_SUMMARY
                        FROM DEDUCTION_DETAIL)

--영업활동으로 인한 자산부채의 변동(05)
--매출채권 및 재고자산 감소, 매입채무 및 미지급법인세 증가, 퇴직금지급,배당금수령
--매출채권 및 재고자산 증가, 매입채무 및 미지급법인세 감소 등 차감
      ,DEBT_FLUCTUATIONS AS (
        SELECT ACCOUNT_INNER_CODE,--계정내부코드
               ACCOUNT_NAME,      --계정명
               '05'                     AS PARENT_ACCOUNT_CODE,--상위계정내부코드(임시테이블 손익계산서)
               DEBITS_SUM-CREDITS_SUM AS CASHFLOW,             --세부금액(")
               --대변(합계)-차변(합계)
               NULL                     AS CASHFLOW_SUMMARY      --합계금액(")
        FROM (
               SELECT J.ACCOUNT_INNER_CODE, --계정내부코드(계정과목)
                      A.ACCOUNT_NAME,       --계정명(계정과목)
                      SUM(NVL(J.LEFT_DEBTOR_PRICE, 0))   AS DEBITS_SUM, ---차변금액(분개) AS  차변(합계)임시시산표테이블
                      SUM(NVL(J.RIGHT_CREDITS_PRICE, 0)) AS CREDITS_SUM  --대변금액(분개) AS  대변(합계)임시시산표테이블
               FROM SLIP S, --전표
                    JOURNAL J, -- 분개
                    JOURNAL Y,
                    PERIOD P, -- 기수
                    ACCOUNT A -- 계정과목
               WHERE S.SLIP_NO = J.SLIP_NO --일련번호 전표번호,분개번호조인
                 AND J.ACCOUNT_INNER_CODE = A.ACCOUNT_INNER_CODE --계정,분개 내부계정코드
                 AND S.SLIP_STATUS LIKE '승인' --전표상태
                 AND J.SLIP_NO = Y.SLIP_NO
                 AND Y.ACCOUNT_INNER_CODE='0101'
                 AND S.ACCOUNT_PERIOD_NO = P.ACCOUNT_PERIOD_NO --회계기수일련번호
                 AND P.ACCOUNT_PERIOD_NO = SEARCH_PERIOD_NO
                 AND (
                          A.PARENT_ACCOUNT_INNER_CODE='0146-0175'
                          OR A.ACCOUNT_NAME LIKE '%채무%'
                          OR A.ACCOUNT_NAME = '배당금수익'
                          OR A.ACCOUNT_NAME = '매출채권처분손실'
                          )
               GROUP BY J.ACCOUNT_INNER_CODE, A.ACCOUNT_NAME
               )
      ),
--영업활동으로 인한 자산부채의 변동(05)
      DEBT_FLUCTUATIONS_S AS (
                                     SELECT '05'         AS ACCOUNT_INNER_CODE,
                               UNISTR('(4)영업활동으로 인한 자산부채의 변동') AS ACCOUNT_NAME,
                               '05'          AS PARENT_ACCOUNT_CODE,
                               SUM(CASHFLOW)          AS CASHFLOW,
                               NULL   AS CASHFLOW_SUMMARY
                        FROM DEBT_FLUCTUATIONS)

  --영업활동 현금흐름(01)=당기순이익(02)+현금의 유입이 없는 수익 등의 가산(03)-현금의 유입이 없는 수익 등의 차감(04)+영업활동으로 인한 자산부채의 변동(05)
       ,SALES_CASHFLOW AS
       (SELECT '01' AS ACCOUNT_INNER_CODE
            , UNISTR('1.영업활동 현금흐름') AS ACCOUNT_NAME
            , '01' AS PARENT_ACCOUNT_CODE
            , NULL AS CASHFLOW
            , A.CASHFLOW +E.CASHFLOW -B.CASHFLOW +M.CASHFLOW    AS CASHFLOW_SUMMARY
         FROM
                  INCOME_DETAIL A
              --당기순이익
              ,  SALES_SUMMARY E
             --현금의 유입이 없는 수익 등의 가산 총계
            , DEDUCTION_SUMMARY B
             --현금의 유입이 없는 수익 등의 차감 총계
            , DEBT_FLUCTUATIONS_S M --영업활동으로 인한 자산부채의 변동 총계
       )

--투자활동으로 인한 현금유입액
      ,INVESTMENT_INFLOW AS (
        SELECT ACCOUNT_INNER_CODE,--계정내부코드
               ACCOUNT_NAME,      --계정명
               '07'                     AS PARENT_ACCOUNT_CODE,--상위계정내부코드(임시테이블 손익계산서)
               DEBITS_SUM AS CASHFLOW,             --세부금액(")
               --차변(합계)
               NULL                     AS CASHFLOW_SUMMARY      --합계금액(")
        FROM (
               SELECT J.ACCOUNT_INNER_CODE, --계정내부코드(계정과목)
                      A.ACCOUNT_NAME,       --계정명(계정과목)
                      SUM(NVL(J.LEFT_DEBTOR_PRICE, 0))   AS DEBITS_SUM, ---차변금액(분개) AS  차변(합계)임시시산표테이블
                      SUM(NVL(J.RIGHT_CREDITS_PRICE, 0)) AS CREDITS_SUM  --대변금액(분개) AS  대변(합계)임시시산표테이블
               FROM SLIP S, --전표
                    JOURNAL J, -- 분개
                    JOURNAL Y,
                    PERIOD P, -- 기수
                    ACCOUNT A -- 계정과목
               WHERE S.SLIP_NO = J.SLIP_NO --일련번호 전표번호,분개번호조인
                 AND J.ACCOUNT_INNER_CODE = A.ACCOUNT_INNER_CODE --계정,분개 내부계정코드
                 AND S.SLIP_STATUS LIKE '승인' --전표상태
                 AND J.SLIP_NO = Y.SLIP_NO
                 AND Y.ACCOUNT_INNER_CODE='0101'
                 AND S.ACCOUNT_PERIOD_NO = P.ACCOUNT_PERIOD_NO --회계기수일련번호
                 AND P.ACCOUNT_PERIOD_NO = SEARCH_PERIOD_NO
                 AND (
                          A.PARENT_ACCOUNT_INNER_CODE='0195-0217' --유형자산 처분
                          OR A.PARENT_ACCOUNT_INNER_CODE='0218-0230' --무형자산 처분
                           )
               GROUP BY J.ACCOUNT_INNER_CODE, A.ACCOUNT_NAME
               )
      )

      --투자활동으로 인한 현금유입액(05)
      ,INVESTMENT_INFLOW_S AS (
                                     SELECT '07'         AS ACCOUNT_INNER_CODE,
                               UNISTR(' (1)투자활동으로 인한 현금유입액') AS ACCOUNT_NAME,
                               '07'          AS PARENT_ACCOUNT_CODE,
                               SUM(CASHFLOW)          AS CASHFLOW,
                               NULL   AS CASHFLOW_SUMMARY
                        FROM INVESTMENT_INFLOW)

--투자활동으로 인한 현금유입액
      ,INVESTMENT_OUTFLOW AS (
        SELECT ACCOUNT_INNER_CODE,--계정내부코드
               ACCOUNT_NAME,      --계정명
               '08'                     AS PARENT_ACCOUNT_CODE,--상위계정내부코드(임시테이블 손익계산서)
               CREDITS_SUM AS CASHFLOW,             --세부금액(")
               --대변(합계)
               NULL                     AS CASHFLOW_SUMMARY      --합계금액(")
        FROM (
               SELECT J.ACCOUNT_INNER_CODE, --계정내부코드(계정과목)
                      A.ACCOUNT_NAME,       --계정명(계정과목)
                      SUM(NVL(J.LEFT_DEBTOR_PRICE, 0))   AS DEBITS_SUM, ---차변금액(분개) AS  차변(합계)임시시산표테이블
                      SUM(NVL(J.RIGHT_CREDITS_PRICE, 0)) AS CREDITS_SUM  --대변금액(분개) AS  대변(합계)임시시산표테이블
               FROM SLIP S, --전표
                    JOURNAL J, -- 분개
                    JOURNAL Y,
                    PERIOD P, -- 기수
                    ACCOUNT A -- 계정과목
               WHERE S.SLIP_NO = J.SLIP_NO --일련번호 전표번호,분개번호조인
                 AND J.ACCOUNT_INNER_CODE = A.ACCOUNT_INNER_CODE --계정,분개 내부계정코드
                 AND S.SLIP_STATUS LIKE '승인' --전표상태
                 AND J.SLIP_NO = Y.SLIP_NO
                 AND Y.ACCOUNT_INNER_CODE='0101'
                 AND S.ACCOUNT_PERIOD_NO = P.ACCOUNT_PERIOD_NO --회계기수일련번호
                 AND P.ACCOUNT_PERIOD_NO = SEARCH_PERIOD_NO
                 AND (
                          A.PARENT_ACCOUNT_INNER_CODE='0195-0217' --유형자산 처분
                          OR A.PARENT_ACCOUNT_INNER_CODE='0218-0230' --무형자산 처분
                           )
               GROUP BY J.ACCOUNT_INNER_CODE, A.ACCOUNT_NAME
               )
      )

      --투자활동으로 인한 현금유출액(05)
      ,INVESTMENT_OUTFLOW_S AS (
                                     SELECT '08'         AS ACCOUNT_INNER_CODE,
                               UNISTR('(2)투자활동으로 인한 현금유출액') AS ACCOUNT_NAME,
                               '08'          AS PARENT_ACCOUNT_CODE,
                               SUM(CASHFLOW)          AS CASHFLOW,
                               NULL   AS CASHFLOW_SUMMARY
                        FROM INVESTMENT_OUTFLOW)


  --투자활동 현금흐름(01)=투자활동으로 인한 현금유입액-투자활동으로 인한 현금유출액
       ,INVEST_CASHFLOW AS
       (SELECT '06' AS ACCOUNT_INNER_CODE
            , UNISTR('2.투자활동 현금흐름') AS ACCOUNT_NAME
            , '06' AS PARENT_ACCOUNT_CODE
            , NULL AS CASHFLOW
            , A.CASHFLOW -E.CASHFLOW   AS CASHFLOW_SUMMARY
         FROM
                  INVESTMENT_INFLOW_S A
              --투자활동으로 인한 현금유입액
              ,  INVESTMENT_OUTFLOW_S E
             --투자활동으로 인한 현금유출액

       )

  --재무활동 현금흐름(09)=재무활동으로 인한 현금 유입액(10)-재무활동으로 인한 현금유출액(11)
--재무활동으로 인한 현금 유입액(10)
      ,FINANCIAL_INFLOW AS (
        SELECT ACCOUNT_INNER_CODE,--계정내부코드
               ACCOUNT_NAME,      --계정명
               '10'                     AS PARENT_ACCOUNT_CODE,--상위계정내부코드(임시테이블 손익계산서)
               DEBITS_SUM AS CASHFLOW,             --세부금액(")
               --차변(합계)
               NULL                     AS CASHFLOW_SUMMARY      --합계금액(")
        FROM (
               SELECT J.ACCOUNT_INNER_CODE, --계정내부코드(계정과목)
                      A.ACCOUNT_NAME,       --계정명(계정과목)
                      SUM(NVL(J.LEFT_DEBTOR_PRICE, 0))   AS DEBITS_SUM, ---차변금액(분개) AS  차변(합계)임시시산표테이블
                      SUM(NVL(J.RIGHT_CREDITS_PRICE, 0)) AS CREDITS_SUM  --대변금액(분개) AS  대변(합계)임시시산표테이블
               FROM SLIP S, --전표
                    JOURNAL J, -- 분개
                    JOURNAL Y,
                    PERIOD P, -- 기수
                    ACCOUNT A -- 계정과목
               WHERE S.SLIP_NO = J.SLIP_NO --일련번호 전표번호,분개번호조인
                 AND J.ACCOUNT_INNER_CODE = A.ACCOUNT_INNER_CODE --계정,분개 내부계정코드
                 AND S.SLIP_STATUS LIKE '승인' --전표상태
                 AND J.SLIP_NO = Y.SLIP_NO
                 AND Y.ACCOUNT_INNER_CODE='0101'
                 AND S.ACCOUNT_PERIOD_NO = P.ACCOUNT_PERIOD_NO --회계기수일련번호
                 AND P.ACCOUNT_PERIOD_NO = SEARCH_PERIOD_NO
                 AND (
                          A.PARENT_ACCOUNT_INNER_CODE='0176-0194' --재무 처분

                           )
               GROUP BY J.ACCOUNT_INNER_CODE, A.ACCOUNT_NAME
               )
      )

      --재무활동으로 인한 현금 유입액 합계(10)
      ,FINANCIAL_INFLOW_S AS (
                                     SELECT '10'         AS ACCOUNT_INNER_CODE,
                               UNISTR('(1)재무활동으로 인한 현금 유입액') AS ACCOUNT_NAME,
                               '10'          AS PARENT_ACCOUNT_CODE,
                               SUM(CASHFLOW)          AS CASHFLOW,
                               NULL   AS CASHFLOW_SUMMARY
                        FROM FINANCIAL_INFLOW)

   --재무활동으로 인한 현금 유출액(11)
      ,FINANCIAL_OUTFLOW AS (
        SELECT ACCOUNT_INNER_CODE,--계정내부코드
               ACCOUNT_NAME,      --계정명
               '11'                     AS PARENT_ACCOUNT_CODE,--상위계정내부코드(임시테이블 손익계산서)
               CREDITS_SUM AS CASHFLOW,             --세부금액(")
               --대변(합계)
               NULL                     AS CASHFLOW_SUMMARY      --합계금액(")
        FROM (
               SELECT J.ACCOUNT_INNER_CODE, --계정내부코드(계정과목)
                      A.ACCOUNT_NAME,       --계정명(계정과목)
                      SUM(NVL(J.LEFT_DEBTOR_PRICE, 0))   AS DEBITS_SUM, ---차변금액(분개) AS  차변(합계)임시시산표테이블
                      SUM(NVL(J.RIGHT_CREDITS_PRICE, 0)) AS CREDITS_SUM  --대변금액(분개) AS  대변(합계)임시시산표테이블
               FROM SLIP S, --전표
                    JOURNAL J, -- 분개
                    JOURNAL Y,
                    PERIOD P, -- 기수
                    ACCOUNT A -- 계정과목
               WHERE S.SLIP_NO = J.SLIP_NO --일련번호 전표번호,분개번호조인
                 AND J.ACCOUNT_INNER_CODE = A.ACCOUNT_INNER_CODE --계정,분개 내부계정코드
                 AND S.SLIP_STATUS LIKE '승인' --전표상태
                 AND J.SLIP_NO = Y.SLIP_NO
                 AND Y.ACCOUNT_INNER_CODE='0101'
                 AND S.ACCOUNT_PERIOD_NO = P.ACCOUNT_PERIOD_NO --회계기수일련번호
                 AND P.ACCOUNT_PERIOD_NO = SEARCH_PERIOD_NO
                 AND (
                          A.PARENT_ACCOUNT_INNER_CODE='0176-0194' --재무 구입

                           )
               GROUP BY J.ACCOUNT_INNER_CODE, A.ACCOUNT_NAME
               )
      )

      --재무활동으로 인한 현금 유출액 합계(11)
      ,FINANCIAL_OUTFLOW_S AS (
                                     SELECT '11'         AS ACCOUNT_INNER_CODE,
                               UNISTR('(2)재무활동으로 인한 현금 유출액') AS ACCOUNT_NAME,
                               '11'          AS PARENT_ACCOUNT_CODE,
                               SUM(CASHFLOW)          AS CASHFLOW,
                               NULL   AS CASHFLOW_SUMMARY
                        FROM FINANCIAL_OUTFLOW)

  --재무활동 현금흐름(09)=재무활동으로 인한 현금 유입액(10)-재무활동으로 인한 현금유출액(11)
         ,FINANCIAL_CASHFLOW AS
       (SELECT '09' AS ACCOUNT_INNER_CODE
            , UNISTR('3.재무활동 현금흐름') AS ACCOUNT_NAME
            , '09' AS PARENT_ACCOUNT_CODE
            , NULL AS CASHFLOW
            , A.CASHFLOW -E.CASHFLOW   AS CASHFLOW_SUMMARY
         FROM
                  FINANCIAL_INFLOW_S A
              --투자활동으로 인한 현금유입액
              ,  FINANCIAL_OUTFLOW_S E
             --투자활동으로 인한 현금유출액
         )

  --현금의 증가(12) = (01)+(06)+(09)
      ,CASH_ADDITAION AS
       (SELECT '12' AS ACCOUNT_INNER_CODE
            , UNISTR('4.현금의 증가') AS ACCOUNT_NAME
            , '12' AS PARENT_ACCOUNT_CODE
            , NULL AS CASHFLOW
            , A.CASHFLOW_SUMMARY +B.CASHFLOW_SUMMARY + C.CASHFLOW_SUMMARY   AS CASHFLOW_SUMMARY
         FROM
                  SALES_CASHFLOW A
              --영업활동으로 인한 현금흐름
                 ,   INVEST_CASHFLOW B
              --투자활동으로 인한  현금흐름
              ,  FINANCIAL_CASHFLOW C
             --재무활동으로 인한  현금흐름
         )



    SELECT A.*, SEARCH_PERIOD_NO
    FROM (
              SELECT *
           FROM SALES_CASHFLOW
           UNION ALL
           SELECT *
           FROM INCOME_DETAIL
           UNION ALL
           SELECT *
           FROM SALES_SUMMARY
           UNION ALL
           SELECT *
           FROM DEDUCTION_SUMMARY
           UNION ALL
           SELECT *
           FROM  DEBT_FLUCTUATIONS_S
           UNION ALL
           SELECT *
           FROM   INVEST_CASHFLOW
           UNION ALL
           SELECT *
           FROM    INVESTMENT_INFLOW_S
           UNION ALL
           SELECT *
           FROM  INVESTMENT_OUTFLOW_S
            UNION ALL
           SELECT *
           FROM   FINANCIAL_CASHFLOW
           UNION ALL
           SELECT *
           FROM    FINANCIAL_INFLOW_S
           UNION ALL
           SELECT *
           FROM FINANCIAL_OUTFLOW_S
           UNION ALL
           SELECT *
           FROM  CASH_ADDITAION

           )A;

 ELSE

    INSERT INTO TMP_CASHFLOW_STATEMENT(ACCOUNT_INNER_CODE, ACCOUNT_NAME, PARENT_ACCOUNT_CODE, CASHFLOW, CASHFLOW_SUMMARY,
                                     PERIOD_NO)
    WITH
   E_INCOME AS (
      SELECT '02' AS ACCOUNT_INNER_CODE
            , UNISTR('당기순이익') AS ACCOUNT_NAME
            , INCOME_SUMMARY  AS CASHFLOW
            , NULL AS CASHFLOW_SUMMARY
         FROM (SELECT F_NET_INCOME(SEARCH_PERIOD_NO-1, IS_EARLY_PERIOD-1) INCOME_SUMMARY
            FROM DUAL)
      ),

      E_INCOME_DETAIL AS (
        SELECT '02' ACCOUNT_INNER_CODE,
               UNISTR('(1)당기순이익') AS ACCOUNT_NAME,
               '02'            AS PARENT_ACCOUNT_CODE,
               CASHFLOW AS CASHFLOW,
               NULL           AS CASHFLOW_SUMMARY
        FROM E_INCOME )

--현금의 유출이 없는 비용 등의 가산
--퇴직급여,감가상각비,대손상각비,외화환산손실,유형자산처분손실,재고자산폐기손실, 무형자산상각비
--무형자산손상차손,파생상품평가손실,파생상품거래손실,토지재평가손실
       ,E_SALES_DETAIL AS (
        SELECT ACCOUNT_INNER_CODE,--계정내부코드
               ACCOUNT_NAME,      --계정명
               '03'              AS PARENT_ACCOUNT_CODE,--상위계정내부코드(임시테이블 손익계산서)
               DEBITS_SUM AS CASHFLOW,             --세부금액(")
               NULL           AS CASHFLOW_SUMMARY      --합계금액(")
        FROM (
               SELECT J.ACCOUNT_INNER_CODE, --계정내부코드(계정과목)
                      A.ACCOUNT_NAME,       --계정명(계정과목)
                      SUM(NVL(J.LEFT_DEBTOR_PRICE, 0))   AS DEBITS_SUM, ---차변금액(분개) AS  차변(합계)임시시산표테이블
                      SUM(NVL(J.RIGHT_CREDITS_PRICE, 0)) AS CREDITS_SUM  --대변금액(분개) AS  대변(합계)임시시산표테이블
               FROM SLIP S, --전표
                    JOURNAL J, -- 분개
                    JOURNAL Y,
                    PERIOD P, -- 기수
                    ACCOUNT A -- 계정과목
               WHERE S.SLIP_NO = J.SLIP_NO --일련번호 전표번호,분개번호조인
                 AND J.ACCOUNT_INNER_CODE = A.ACCOUNT_INNER_CODE --계정,분개 내부계정코드
                 AND S.SLIP_STATUS LIKE '승인' --전표상태
                 AND J.SLIP_NO = Y.SLIP_NO
                 AND Y.ACCOUNT_INNER_CODE='0101'
                 AND S.ACCOUNT_PERIOD_NO = P.ACCOUNT_PERIOD_NO --회계기수일련번호
                 AND P.ACCOUNT_PERIOD_NO = SEARCH_PERIOD_NO-1
                 AND (
                                A.ACCOUNT_NAME = '퇴직급여'
                          OR A.ACCOUNT_NAME LIKE '%감가상각%'
                          OR A.ACCOUNT_NAME ='외화환산손실'
                          OR A.ACCOUNT_NAME = '유형자산처분손실'
                          OR A.ACCOUNT_NAME LIKE '재고자산%'
                          OR A.ACCOUNT_NAME = '무형자산상각비'
                          OR A.ACCOUNT_NAME = '파생상품평가손실'
                          OR A.ACCOUNT_NAME = '무형자산상각비')     --상위계정내부코드  매출
               GROUP BY J.ACCOUNT_INNER_CODE, A.ACCOUNT_NAME)

      ),
--현금의 유출이 없는 비용 등의 가산 총계
      E_SALES_SUMMARY AS (SELECT '03'          AS ACCOUNT_INNER_CODE,
                               UNISTR('(2)현금의 유출이 없는 비용 등의 가산') AS ACCOUNT_NAME,
                               '03'          AS PARENT_ACCOUNT_CODE,
                               SUM(CASHFLOW)          AS CASHFLOW,
                               NULL   AS CASHFLOW_SUMMARY
                        FROM E_SALES_DETAIL),

--현금의 유입이 없는 수익 등의 차감(04)
--유가증권평가이익,외환차익,외화환산이익,지분법이익,유형자산처분이익,사채상환이익
      E_DEDUCTION_DETAIL AS (
        SELECT ACCOUNT_INNER_CODE,--계정내부코드
               ACCOUNT_NAME,      --계정명
               '04'                     AS PARENT_ACCOUNT_CODE,--상위계정내부코드(임시테이블 손익계산서)
               DEBITS_SUM AS CASHFLOW,             --세부금액(")
               --대변(합계)
               NULL                     AS CASHFLOW_SUMMARY      --합계금액(")
        FROM (
               SELECT J.ACCOUNT_INNER_CODE, --계정내부코드(계정과목)
                      A.ACCOUNT_NAME,       --계정명(계정과목)
                      SUM(NVL(J.LEFT_DEBTOR_PRICE, 0))   AS DEBITS_SUM, ---차변금액(분개) AS  차변(합계)임시시산표테이블
                      SUM(NVL(J.RIGHT_CREDITS_PRICE, 0)) AS CREDITS_SUM  --대변금액(분개) AS  대변(합계)임시시산표테이블
               FROM SLIP S, --전표
                    JOURNAL J, -- 분개
                    JOURNAL Y,
                    PERIOD P, -- 기수
                    ACCOUNT A -- 계정과목
               WHERE S.SLIP_NO = J.SLIP_NO --일련번호 전표번호,분개번호조인
                 AND J.ACCOUNT_INNER_CODE = A.ACCOUNT_INNER_CODE --계정,분개 내부계정코드
                 AND S.SLIP_STATUS LIKE '승인' --전표상태
                 AND J.SLIP_NO = Y.SLIP_NO
                 AND Y.ACCOUNT_INNER_CODE='0101'
                 AND S.ACCOUNT_PERIOD_NO = P.ACCOUNT_PERIOD_NO --회계기수일련번호
                 AND P.ACCOUNT_PERIOD_NO = SEARCH_PERIOD_NO-1
                 AND (
                                A.ACCOUNT_CHARACTER = '유가증권'
                          OR A.ACCOUNT_NAME LIKE '%증권평가이익%'
                          OR A.ACCOUNT_NAME ='외환차익'
                          OR A.ACCOUNT_NAME = '외화환산이익'
                          OR A.ACCOUNT_NAME = '지분법이익'
                          OR A.ACCOUNT_NAME = '유형자산처분이익'
                          OR A.ACCOUNT_NAME = '사채상환이익')     --상위계정내부코드  매출
               GROUP BY J.ACCOUNT_INNER_CODE, A.ACCOUNT_NAME)
      ),
--현금의 유출이 없는 비용 등의 가산 총계
      E_DEDUCTION_SUMMARY AS (
                                     SELECT '04'         AS ACCOUNT_INNER_CODE,
                               UNISTR('(3)현금의 유입이 없는 수익 등의 차감') AS ACCOUNT_NAME,
                               '04'          AS PARENT_ACCOUNT_CODE,
                               SUM(CASHFLOW)        AS CASHFLOW,
                               NULL   AS CASHFLOW_SUMMARY
                        FROM E_DEDUCTION_DETAIL)

--영업활동으로 인한 자산부채의 변동(05)
--매출채권 및 재고자산 감소, 매입채무 및 미지급법인세 증가, 퇴직금지급,배당금수령
--매출채권 및 재고자산 증가, 매입채무 및 미지급법인세 감소 등 차감
      ,E_DEBT_FLUCTUATIONS AS (
        SELECT ACCOUNT_INNER_CODE,--계정내부코드
               ACCOUNT_NAME,      --계정명
               '05'                     AS PARENT_ACCOUNT_CODE,--상위계정내부코드(임시테이블 손익계산서)
               DEBITS_SUM-CREDITS_SUM AS CASHFLOW,             --세부금액(")
               --대변(합계)-차변(합계)
               NULL                     AS CASHFLOW_SUMMARY      --합계금액(")
        FROM (
               SELECT J.ACCOUNT_INNER_CODE, --계정내부코드(계정과목)
                      A.ACCOUNT_NAME,       --계정명(계정과목)
                      SUM(NVL(J.LEFT_DEBTOR_PRICE, 0))   AS DEBITS_SUM, ---차변금액(분개) AS  차변(합계)임시시산표테이블
                      SUM(NVL(J.RIGHT_CREDITS_PRICE, 0)) AS CREDITS_SUM  --대변금액(분개) AS  대변(합계)임시시산표테이블
               FROM SLIP S, --전표
                    JOURNAL J, -- 분개
                    JOURNAL Y,
                    PERIOD P, -- 기수
                    ACCOUNT A -- 계정과목
               WHERE S.SLIP_NO = J.SLIP_NO --일련번호 전표번호,분개번호조인
                 AND J.ACCOUNT_INNER_CODE = A.ACCOUNT_INNER_CODE --계정,분개 내부계정코드
                 AND S.SLIP_STATUS LIKE '승인' --전표상태
                 AND J.SLIP_NO = Y.SLIP_NO
                 AND Y.ACCOUNT_INNER_CODE='0101'
                 AND S.ACCOUNT_PERIOD_NO = P.ACCOUNT_PERIOD_NO --회계기수일련번호
                 AND P.ACCOUNT_PERIOD_NO = SEARCH_PERIOD_NO
                 AND (
                          A.PARENT_ACCOUNT_INNER_CODE='0146-0175'
                          OR A.ACCOUNT_NAME LIKE '%채무%'
                          OR A.ACCOUNT_NAME = '배당금수익'
                          OR A.ACCOUNT_NAME = '매출채권처분손실'
                          )
               GROUP BY J.ACCOUNT_INNER_CODE, A.ACCOUNT_NAME)
      ),
--영업활동으로 인한 자산부채의 변동(05)
      E_DEBT_FLUCTUATIONS_S AS (
                                     SELECT '05'         AS ACCOUNT_INNER_CODE,
                               UNISTR('(4)영업활동으로 인한 자산부채의 변동') AS ACCOUNT_NAME,
                               '05'          AS PARENT_ACCOUNT_CODE,
                               SUM(CASHFLOW)          AS CASHFLOW,
                               NULL   AS CASHFLOW_SUMMARY
                        FROM E_DEBT_FLUCTUATIONS)

 --영업활동 현금흐름(01)=당기순이익(02)+현금의 유입이 없는 수익 등의 가산(03)-현금의 유입이 없는 수익 등의 차감(04)+영업활동으로 인한 자산부채의 변동(05)
       ,E_SALES_CASHFLOW AS
       (SELECT '01' AS ACCOUNT_INNER_CODE
            , UNISTR('1.영업활동 현금흐름') AS ACCOUNT_NAME
            , '01'  AS PARENT_ACCOUNT_CODE
            , NULL AS CASHFLOW
            , A.CASHFLOW +E.CASHFLOW -B.CASHFLOW +M.CASHFLOW  AS CASHFLOW_SUMMARY
         FROM
                  E_INCOME_DETAIL A
              -- 당기순이익
            ,   E_SALES_SUMMARY E
            , --현금의 유입이 없는 수익 등의 가산 총계
              E_DEDUCTION_SUMMARY B
            , --현금의 유입이 없는 수익 등의 차감 총계
              E_DEBT_FLUCTUATIONS_S M --영업활동으로 인한 자산부채의 변동
       )

       --투자활동으로 인한 현금유입액
      ,E_INVESTMENT_INFLOW AS (
        SELECT ACCOUNT_INNER_CODE,--계정내부코드
               ACCOUNT_NAME,      --계정명
               '07'                     AS PARENT_ACCOUNT_CODE,--상위계정내부코드(임시테이블 손익계산서)
               DEBITS_SUM AS CASHFLOW,             --세부금액(")
               --차변(합계)
               NULL                     AS CASHFLOW_SUMMARY      --합계금액(")
        FROM (
               SELECT J.ACCOUNT_INNER_CODE, --계정내부코드(계정과목)
                      A.ACCOUNT_NAME,       --계정명(계정과목)
                      SUM(NVL(J.LEFT_DEBTOR_PRICE, 0))   AS DEBITS_SUM, ---차변금액(분개) AS  차변(합계)임시시산표테이블
                      SUM(NVL(J.RIGHT_CREDITS_PRICE, 0)) AS CREDITS_SUM  --대변금액(분개) AS  대변(합계)임시시산표테이블
               FROM SLIP S, --전표
                    JOURNAL J, -- 분개
                    JOURNAL Y,
                    PERIOD P, -- 기수
                    ACCOUNT A -- 계정과목
               WHERE S.SLIP_NO = J.SLIP_NO --일련번호 전표번호,분개번호조인
                 AND J.ACCOUNT_INNER_CODE = A.ACCOUNT_INNER_CODE --계정,분개 내부계정코드
                 AND S.SLIP_STATUS LIKE '승인' --전표상태
                 AND J.SLIP_NO = Y.SLIP_NO
                 AND Y.ACCOUNT_INNER_CODE='0101'
                 AND S.ACCOUNT_PERIOD_NO = P.ACCOUNT_PERIOD_NO --회계기수일련번호
                 AND P.ACCOUNT_PERIOD_NO = SEARCH_PERIOD_NO-1
                 AND (
                          A.PARENT_ACCOUNT_INNER_CODE='0195-0217' --유형자산 처분
                          OR A.PARENT_ACCOUNT_INNER_CODE='0218-0230' --무형자산 처분
                           )
               GROUP BY J.ACCOUNT_INNER_CODE, A.ACCOUNT_NAME
               )
      )

      --투자활동으로 인한 현금유입액(05)
      ,E_INVESTMENT_INFLOW_S AS (
                                     SELECT '07'         AS ACCOUNT_INNER_CODE,
                               UNISTR('(1)투자활동으로 인한 현금유입액') AS ACCOUNT_NAME,
                               '07'          AS PARENT_ACCOUNT_CODE,
                               SUM(CASHFLOW)          AS CASHFLOW,
                               NULL   AS CASHFLOW_SUMMARY
                        FROM E_INVESTMENT_INFLOW)

--투자활동으로 인한 현금유출액
      ,E_INVESTMENT_OUTFLOW AS (
        SELECT ACCOUNT_INNER_CODE,--계정내부코드
               ACCOUNT_NAME,      --계정명
               '08'                     AS PARENT_ACCOUNT_CODE,--상위계정내부코드(임시테이블 손익계산서)
               CREDITS_SUM AS CASHFLOW,             --세부금액(")
               --대변(합계)
               NULL                     AS CASHFLOW_SUMMARY      --합계금액(")
        FROM (
               SELECT J.ACCOUNT_INNER_CODE, --계정내부코드(계정과목)
                      A.ACCOUNT_NAME,       --계정명(계정과목)
                      SUM(NVL(J.LEFT_DEBTOR_PRICE, 0))   AS DEBITS_SUM, ---차변금액(분개) AS  차변(합계)임시시산표테이블
                      SUM(NVL(J.RIGHT_CREDITS_PRICE, 0)) AS CREDITS_SUM  --대변금액(분개) AS  대변(합계)임시시산표테이블
               FROM SLIP S, --전표
                    JOURNAL J, -- 분개
                    JOURNAL Y,
                    PERIOD P, -- 기수
                    ACCOUNT A -- 계정과목
               WHERE S.SLIP_NO = J.SLIP_NO --일련번호 전표번호,분개번호조인
                 AND J.ACCOUNT_INNER_CODE = A.ACCOUNT_INNER_CODE --계정,분개 내부계정코드
                 AND S.SLIP_STATUS LIKE '승인' --전표상태
                 AND J.SLIP_NO = Y.SLIP_NO
                 AND Y.ACCOUNT_INNER_CODE='0101'
                 AND S.ACCOUNT_PERIOD_NO = P.ACCOUNT_PERIOD_NO --회계기수일련번호
                 AND P.ACCOUNT_PERIOD_NO = SEARCH_PERIOD_NO-1
                 AND (
                          A.PARENT_ACCOUNT_INNER_CODE='0195-0217' --유형자산 처분
                          OR A.PARENT_ACCOUNT_INNER_CODE='0218-0230' --무형자산 처분
                           )
               GROUP BY J.ACCOUNT_INNER_CODE, A.ACCOUNT_NAME
               )
      )

      --투자활동으로 인한 현금유출액(05)
      ,E_INVESTMENT_OUTFLOW_S AS (
                                     SELECT '08'         AS ACCOUNT_INNER_CODE,
                               UNISTR('(2)투자활동으로 인한 현금유출액') AS ACCOUNT_NAME,
                               '08'          AS PARENT_ACCOUNT_CODE,
                               SUM(CASHFLOW)          AS CASHFLOW,
                               NULL   AS CASHFLOW_SUMMARY
                        FROM E_INVESTMENT_OUTFLOW)


  --투자활동 현금흐름(01)=투자활동으로 인한 현금유입액-투자활동으로 인한 현금유출액
       ,E_INVEST_CASHFLOW AS
       (SELECT '06' AS ACCOUNT_INNER_CODE
            , UNISTR('2.투자활동 현금흐름') AS ACCOUNT_NAME
            , '06' AS PARENT_ACCOUNT_CODE
            , NULL AS CASHFLOW
            , A.CASHFLOW -E.CASHFLOW   AS CASHFLOW_SUMMARY
         FROM
                  E_INVESTMENT_INFLOW_S A
              --투자활동으로 인한 현금유입액
              ,  E_INVESTMENT_OUTFLOW_S E
             --투자활동으로 인한 현금유출액
       )
--재무활동 현금흐름(09)=재무활동으로 인한 현금 유입액(10)-재무활동으로 인한 현금유출액(11)
--재무활동으로 인한 현금 유입액(10)
      ,E_FINANCIAL_INFLOW AS (
        SELECT ACCOUNT_INNER_CODE,--계정내부코드
               ACCOUNT_NAME,      --계정명
               '10'                     AS PARENT_ACCOUNT_CODE,--상위계정내부코드(임시테이블 손익계산서)
               DEBITS_SUM AS CASHFLOW,             --세부금액(")
               --차변(합계)
               NULL                     AS CASHFLOW_SUMMARY      --합계금액(")
        FROM (
               SELECT J.ACCOUNT_INNER_CODE, --계정내부코드(계정과목)
                      A.ACCOUNT_NAME,       --계정명(계정과목)
                      SUM(NVL(J.LEFT_DEBTOR_PRICE, 0))   AS DEBITS_SUM, ---차변금액(분개) AS  차변(합계)임시시산표테이블
                      SUM(NVL(J.RIGHT_CREDITS_PRICE, 0)) AS CREDITS_SUM  --대변금액(분개) AS  대변(합계)임시시산표테이블
               FROM SLIP S, --전표
                    JOURNAL J, -- 분개
                    JOURNAL Y,
                    PERIOD P, -- 기수
                    ACCOUNT A -- 계정과목
               WHERE S.SLIP_NO = J.SLIP_NO --일련번호 전표번호,분개번호조인
                 AND J.ACCOUNT_INNER_CODE = A.ACCOUNT_INNER_CODE --계정,분개 내부계정코드
                 AND S.SLIP_STATUS LIKE '승인' --전표상태
                 AND J.SLIP_NO = Y.SLIP_NO
                 AND Y.ACCOUNT_INNER_CODE='0101'
                 AND S.ACCOUNT_PERIOD_NO = P.ACCOUNT_PERIOD_NO --회계기수일련번호
                 AND P.ACCOUNT_PERIOD_NO = SEARCH_PERIOD_NO
                 AND (
                          A.PARENT_ACCOUNT_INNER_CODE='0176-0194' --투자자산 처분

                           )
               GROUP BY J.ACCOUNT_INNER_CODE, A.ACCOUNT_NAME
               )
      )

      --재무활동으로 인한 현금 유입액 합계(10)
      ,E_FINANCIAL_INFLOW_S AS (
                                     SELECT '10'         AS ACCOUNT_INNER_CODE,
                               UNISTR('(1)재무활동으로 인한 현금 유입액') AS ACCOUNT_NAME,
                               '10'          AS PARENT_ACCOUNT_CODE,
                               SUM(CASHFLOW)          AS CASHFLOW,
                               NULL   AS CASHFLOW_SUMMARY
                        FROM E_FINANCIAL_INFLOW)

   --재무활동으로 인한 현금 유출액(11)
      ,E_FINANCIAL_OUTFLOW AS (
        SELECT ACCOUNT_INNER_CODE,--계정내부코드
               ACCOUNT_NAME,      --계정명
               '11'                     AS PARENT_ACCOUNT_CODE,--상위계정내부코드(임시테이블 손익계산서)
               CREDITS_SUM AS CASHFLOW,             --세부금액(")
               --대변(합계)
               NULL                     AS CASHFLOW_SUMMARY      --합계금액(")
        FROM (
               SELECT J.ACCOUNT_INNER_CODE, --계정내부코드(계정과목)
                      A.ACCOUNT_NAME,       --계정명(계정과목)
                      SUM(NVL(J.LEFT_DEBTOR_PRICE, 0))   AS DEBITS_SUM, ---차변금액(분개) AS  차변(합계)임시시산표테이블
                      SUM(NVL(J.RIGHT_CREDITS_PRICE, 0)) AS CREDITS_SUM  --대변금액(분개) AS  대변(합계)임시시산표테이블
               FROM SLIP S, --전표
                    JOURNAL J, -- 분개
                    JOURNAL Y,
                    PERIOD P, -- 기수
                    ACCOUNT A -- 계정과목
               WHERE S.SLIP_NO = J.SLIP_NO --일련번호 전표번호,분개번호조인
                 AND J.ACCOUNT_INNER_CODE = A.ACCOUNT_INNER_CODE --계정,분개 내부계정코드
                 AND S.SLIP_STATUS LIKE '승인' --전표상태
                 AND J.SLIP_NO = Y.SLIP_NO
                 AND Y.ACCOUNT_INNER_CODE='0101'
                 AND S.ACCOUNT_PERIOD_NO = P.ACCOUNT_PERIOD_NO --회계기수일련번호
                 AND P.ACCOUNT_PERIOD_NO = SEARCH_PERIOD_NO
                 AND (
                          A.PARENT_ACCOUNT_INNER_CODE='0176-0194' --투자자산 구입

                           )
               GROUP BY J.ACCOUNT_INNER_CODE, A.ACCOUNT_NAME
               )
      )

      --재무활동으로 인한 현금 유출액 합계(11)
      ,E_FINANCIAL_OUTFLOW_S AS (
                                     SELECT '11'         AS ACCOUNT_INNER_CODE,
                               UNISTR('(2)재무활동으로 인한 현금 유출액') AS ACCOUNT_NAME,
                               '11'          AS PARENT_ACCOUNT_CODE,
                               SUM(CASHFLOW)          AS CASHFLOW,
                               NULL   AS CASHFLOW_SUMMARY
                        FROM E_FINANCIAL_OUTFLOW)

  --재무활동 현금흐름(09)=재무활동으로 인한 현금 유입액(10)-재무활동으로 인한 현금유출액(11)
         ,E_FINANCIAL_CASHFLOW AS
       (SELECT '09' AS ACCOUNT_INNER_CODE
            , UNISTR('3.재무활동 현금흐름') AS ACCOUNT_NAME
            , '09' AS PARENT_ACCOUNT_CODE
            , NULL AS CASHFLOW
            , A.CASHFLOW -E.CASHFLOW   AS CASHFLOW_SUMMARY
         FROM
                  E_FINANCIAL_INFLOW_S A
              --재무활동으로 인한 현금 유입액
              ,  E_FINANCIAL_OUTFLOW_S E
             --재무활동으로 인한 현금유출액
         )

  --현금의 증가(12) = (01)+(06)+(09)
      ,E_CASH_ADDITAION AS
       (SELECT '12' AS ACCOUNT_INNER_CODE
            , UNISTR('4.현금의 증가') AS ACCOUNT_NAME
            , '12' AS PARENT_ACCOUNT_CODE
            , NULL AS CASHFLOW
            , A.CASHFLOW_SUMMARY +B.CASHFLOW_SUMMARY + C.CASHFLOW_SUMMARY   AS CASHFLOW_SUMMARY
         FROM
                  E_SALES_CASHFLOW A
              --영업활동으로 인한 현금흐름
                 ,   E_INVEST_CASHFLOW B
              --투자활동으로 인한  현금흐름
              ,  E_FINANCIAL_CASHFLOW C
             --재무활동으로 인한  현금흐름
         )






    SELECT A.*, SEARCH_PERIOD_NO
    FROM (
           SELECT *
           FROM E_SALES_CASHFLOW
           UNION ALL
           SELECT *
           FROM E_INCOME_DETAIL
           UNION ALL
           SELECT *
           FROM E_SALES_SUMMARY
                UNION ALL
           SELECT *
           FROM E_DEDUCTION_SUMMARY
           UNION ALL
           SELECT *
           FROM E_DEBT_FLUCTUATIONS_S
           UNION ALL
           SELECT *
           FROM   E_INVEST_CASHFLOW
           UNION ALL
           SELECT *
           FROM    E_INVESTMENT_INFLOW_S
           UNION ALL
           SELECT *
           FROM  E_INVESTMENT_OUTFLOW_S
           UNION ALL
           SELECT *
           FROM   E_FINANCIAL_CASHFLOW
           UNION ALL
           SELECT *
           FROM    E_FINANCIAL_INFLOW_S
           UNION ALL
           SELECT *
           FROM  E_FINANCIAL_OUTFLOW_S
           UNION ALL
           SELECT *
           FROM  E_CASH_ADDITAION


           )A;

  END IF;
END P_COMPUTE_CASHFLOW_STATEMENT;
/

