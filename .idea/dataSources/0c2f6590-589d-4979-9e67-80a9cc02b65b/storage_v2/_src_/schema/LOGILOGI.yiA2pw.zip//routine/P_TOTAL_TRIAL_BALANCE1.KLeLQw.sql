create PROCEDURE          P_TOTAL_TRIAL_BALANCE1
(
    SEARCH_PERIOD_NO IN VARCHAR2,
    ACCOUNTING_SETTLEMENT_STATUS IN VARCHAR2,
    ERROR_CODE OUT NUMBER,
    ERROR_MSG OUT VARCHAR2,
    RESULT OUT SYS_REFCURSOR, --커서변수 조회값이 담김
    RESULT2 OUT SYS_REFCURSOR --커서변수 결산값이 담김
)
IS --현재 나의 기수와 같은 기수번호가 담긴다.
    V_LAST_PERIOD_NO VARCHAR2(30); --내부 변수 선언
BEGIN

    SELECT MAX(ACCOUNT_PERIOD_NO) INTO V_LAST_PERIOD_NO FROM PERIOD; -- 마지막 기수



-- 합계잔액시산표 값이 레벨별로 정렬되어 나타남
OPEN RESULT FOR
        SELECT
            LEV
            , CODE
            , DEBITS_SUM_BALANCE
            , DEBITS_SUM
            ,
             LPAD(' ',LEV*4) ||
            CASE
                WHEN LEV != 0 AND T.ACCOUNT_NAME NOT LIKE '%└%'
                    THEN RANK () OVER (PARTITION BY A.PARENT_ACCOUNT_INNER_CODE ORDER BY CODE) ||  '. '
                WHEN  T.ACCOUNT_NAME LIKE '%└%'
                      THEN '  '
            END  || T.ACCOUNT_NAME AS ACCOUNT_NAME


                , CREDITS_SUM
                , CREDITS_SUM_BALANCE
        FROM  (


                        SELECT *
                       FROM (
                                SELECT
                                LEV
                                , CODE
                           , DEBITS_SUM_BALANCE
                           , DEBITS_SUM
                           , ACCOUNT_NAME
                           , CREDITS_SUM
                           , CREDITS_SUM_BALANCE
                                FROM EARLY_STATEMENTS2  --합계잔액시산표
                                WHERE ACCOUNT_PERIOD_NO=SEARCH_PERIOD_NO)

                ) T,
                  ACCOUNT A
        WHERE T.CODE = A.ACCOUNT_INNER_CODE(+)
        ORDER BY SUBSTR(CODE, 1, 4), SUBSTR(CODE, 6) DESC NULLS LAST;

    --  P_ACCOUNTING_SETTLEMENT_STATUS(SEARCH_PERIOD_NO, ACCOUNTING_SETTLEMENT_STATUS, ERROR_CODE, ERROR_MSG, RESULT2);
      -- 회계결산현황에 기수번호와 상태값을 넣어 search를 해서 값을 result2에 담아서 가져온다.
      -- 회계년도에 값을 줌

      IF ERROR_CODE != 0 THEN
         RETURN;   -- P_ACCOUNTING_SETTLEMENT_CHANGE의 에러 발생시 프로시저 종료한다
      END IF;

    ERROR_CODE := 0;
     ERROR_MSG := '합계잔액시산표 성공';

    EXCEPTION
      WHEN NO_DATA_FOUND
        THEN
          ERROR_CODE := -1;
          ERROR_MSG := '조회할 데이터가 없습니다.';
      WHEN OTHERS
        THEN
          ERROR_CODE := -2;
          ERROR_MSG := SQLERRM;
END P_TOTAL_TRIAL_BALANCE1;
/

