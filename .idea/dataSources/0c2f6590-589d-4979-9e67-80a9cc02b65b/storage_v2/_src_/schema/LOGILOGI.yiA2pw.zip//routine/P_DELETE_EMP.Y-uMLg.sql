create PROCEDURE          "P_DELETE_EMP" (
  P_EMP_CODE IN VARCHAR2
  ,P_ERROR_CODE OUT VARCHAR2
  ,P_ERROR_MSG OUT VARCHAR2
)
IS

BEGIN
    SAVEPOINT SAVEOINT1;

    BEGIN
                        DELETE
                        FROM   EMPLOYEE_BASIC
                        WHERE  EMP_CODE = P_EMP_CODE;

                EXCEPTION
                WHEN OTHERS THEN
                        P_ERROR_CODE := '-1';
                        P_ERROR_MSG  := 'EMP TABLE에서 삭제 실패';
                        ROLLBACK TO SAVEPOINT1;
                        RETURN;
    END;

        BEGIN
                        DELETE
                        FROM   CAREER_INFO
                        WHERE  EMP_CODE = P_EMP_CODE;

                EXCEPTION
                WHEN OTHERS THEN
                        P_ERROR_CODE := '-1';
                        P_ERROR_MSG  := 'CAREER_INFO TABLE에서 삭제 실패';
                        ROLLBACK TO SAVEPOINT1;
                        RETURN;
                END;
    BEGIN
                        DELETE
                        FROM   EDUCATION_INFO
                        WHERE  EMP_CODE = P_EMP_CODE;

                EXCEPTION
                WHEN OTHERS THEN
                        P_ERROR_CODE := '-1';
                        P_ERROR_MSG  := 'EDUCATION_INFO TABLE에서 삭제 실패';
                        ROLLBACK TO SAVEPOINT1;
                        RETURN;
    END;

    BEGIN
                        DELETE
                        FROM   FAMILY_INFO
                        WHERE  EMP_CODE = P_EMP_CODE;

                EXCEPTION
                WHEN OTHERS THEN
                        P_ERROR_CODE := '-1';
                        P_ERROR_MSG  := 'FAMILY_INFO TABLE에서 삭제 실패';
                        ROLLBACK TO SAVEPOINT1;
                        RETURN;
    END;

    BEGIN
                        DELETE
                        FROM   LICENSE_INFO
                        WHERE  EMP_CODE = P_EMP_CODE;

                EXCEPTION
                WHEN OTHERS THEN
                        P_ERROR_CODE := '-1';
                        P_ERROR_MSG  := 'LICENSE_INFO TABLE에서 삭제 실패';
                        ROLLBACK TO SAVEPOINT1;
                        RETURN;
    END;

    BEGIN
                        DELETE
                        FROM   WORK_INFO
                        WHERE  EMP_CODE = P_EMP_CODE;

                EXCEPTION
                WHEN OTHERS THEN
                        P_ERROR_CODE := '-1';
                        P_ERROR_MSG  := 'WORK_INFO TABLE에서 삭제 실패';
                        ROLLBACK TO SAVEPOINT1;
                        RETURN;
    END;

    BEGIN
                        DELETE
                        FROM   MONTH_EXT_SAL
                        WHERE  EMP_CODE = P_EMP_CODE;

                EXCEPTION
                WHEN OTHERS THEN
                        P_ERROR_CODE := '-1';
                        P_ERROR_MSG  := 'MONTH_EXT_SAL TABLE에서 삭제 실패';
                        ROLLBACK TO SAVEPOINT1;
                        RETURN;
    END;

        BEGIN
                        DELETE
                        FROM   MONTH_DEDUCTION
                        WHERE  EMP_CODE = P_EMP_CODE;

                EXCEPTION
                WHEN OTHERS THEN
                        P_ERROR_CODE := '-1';
                        P_ERROR_MSG  := 'MONTH_DEDUCTION TABLE에서 삭제 실패';
                        ROLLBACK TO SAVEPOINT1;
                        RETURN;
    END;

        BEGIN
                        DELETE
                        FROM   MONTH_SALARY
                        WHERE  EMP_CODE = P_EMP_CODE;

                EXCEPTION
                WHEN OTHERS THEN
                        P_ERROR_CODE := '-1';
                        P_ERROR_MSG  := 'MONTH_SALARY TABLE에서 삭제 실패';
                        ROLLBACK TO SAVEPOINT1;
                        RETURN;
    END;

        BEGIN
                        DELETE
                        FROM   DAY_ATTD
                        WHERE  EMP_CODE = P_EMP_CODE;

                EXCEPTION
                WHEN OTHERS THEN
                        P_ERROR_CODE := '-1';
                        P_ERROR_MSG  := 'DAY_ATTD TABLE에서 삭제 실패';
                        ROLLBACK TO SAVEPOINT1;
                        RETURN;
    END;

    BEGIN
                        DELETE
                        FROM   DAY_ATTD_MANAGE
                        WHERE  EMP_CODE = P_EMP_CODE;

                EXCEPTION
                WHEN OTHERS THEN
                        P_ERROR_CODE := '-1';
                        P_ERROR_MSG  := 'DAY_ATTD_MANAGE TABLE에서 삭제 실패';
                        ROLLBACK TO SAVEPOINT1;
                        RETURN;
    END;

    BEGIN
                        DELETE
                        FROM   MONTH_ATTD_MANAGE
                        WHERE  EMP_CODE = P_EMP_CODE;

                EXCEPTION
                WHEN OTHERS THEN
                        P_ERROR_CODE := '-1';
                        P_ERROR_MSG  := 'MONTH_ATTD_MANAGE TABLE에서 삭제 실패';
                        ROLLBACK TO SAVEPOINT1;
                        RETURN;
    END;

    BEGIN
                        DELETE
                        FROM   REST_ATTD
                        WHERE  EMP_CODE = P_EMP_CODE;

                EXCEPTION
                WHEN OTHERS THEN
                        P_ERROR_CODE := '-1';
                        P_ERROR_MSG  := 'REST_ATTD TABLE에서 삭제 실패';
                        ROLLBACK TO SAVEPOINT1;
                        RETURN;
    END;


    BEGIN
                        DELETE
                        FROM   CERTIFICATE
                        WHERE  EMP_CODE = P_EMP_CODE;

                EXCEPTION
                WHEN OTHERS THEN
                        P_ERROR_CODE := '-1';
                        P_ERROR_MSG  := 'CERTIFICATE TABLE에서 삭제 실패';
                        ROLLBACK TO SAVEPOINT1;
                        RETURN;
    END;

     BEGIN
                        DELETE
                        FROM   DETAIL_CODE
                        WHERE  DETAIL_CODE_NUMBER = P_EMP_CODE;

                EXCEPTION
                WHEN OTHERS THEN
                        P_ERROR_CODE := '-1';
                        P_ERROR_MSG  := 'DETAIL_CODE TABLE에서 삭제 실패';
                        ROLLBACK TO SAVEPOINT1;
                        RETURN;
    END;

END P_DELETE_EMP;
/

