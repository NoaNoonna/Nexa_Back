create PROCEDURE     "P_FINANCIAL_POSITION" -- 재무상태표  -- 38번째줄부터
       (
           SEARCH_PERIOD_NO IN VARCHAR2
         , ACCOUNTING_SETTLEMENT_STATUS IN VARCHAR2
         , ERROR_CODE OUT NUMBER
         , ERROR_MSG OUT VARCHAR2
         , RESULT OUT SYS_REFCURSOR
         , RESULT2 OUT SYS_REFCURSOR
       )
IS

BEGIN

    OPEN RESULT FOR

    WITH GET_E_FINANCIAL_POSITION AS (SELECT * FROM FINANCIAL_POSITION WHERE PERIOD_NO = SEARCH_PERIOD_NO - 1),  --조회 기수의 전기
         GET_FINANCIAL_POSITION AS (SELECT * FROM FINANCIAL_POSITION WHERE PERIOD_NO = SEARCH_PERIOD_NO) -- 조회기수의 당기

    SELECT LEV
         , CATEGORY
         , LPAD(' ', LEV * 4) ||
                   CASE
                        WHEN LEV != 0 AND T.ACCOUNT_NAME NOT LIKE '%└%'
                            THEN RANK() OVER(PARTITION BY CATEGORY, A.PARENT_ACCOUNT_INNER_CODE ORDER BY T.ACCOUNT_CODE) || '. '
                        WHEN T.ACCOUNT_NAME LIKE '%└%' THEN '  '
                   END || T.ACCOUNT_NAME AS ACCOUNT_NAME
         , BALANCE_DETAIL
         , BALANCE_DETAIL_SUMMARY
         , PRE_BALANCE_DETAIL
         , PRE_BALANCE_SUMMARY
         , T.ACCOUNT_CODE AS ACCOUNT_CODE

      FROM
           (SELECT F.LEV
                , /*레벨링*/
                  F.CATEGORY
                , /*계정과목최상위제목*/
                  F.ACCOUNT_NAME
                , /*계정과목*/
                  F.BALANCE_DETAIL
                , /*당기세부금액*/
                  F.BALANCE_DETAIL_SUMMARY
                , /*당기합계금액*/
                  E.BALANCE_DETAIL AS PRE_BALANCE_DETAIL
                , /*전기세부금액*/
                  E.BALANCE_DETAIL_SUMMARY AS PRE_BALANCE_SUMMARY
                , /*전기합계금액*/
                  F.ACCOUNT_CODE
                , /*계정코드*/
                  SUBSTR(F.ACCOUNT_CODE, 1, 4) AS MIN
                , /*계정코드내부최소*/
                  SUBSTR(F.ACCOUNT_CODE, 6) AS MAX /*계정코드내부최대*/
             FROM GET_FINANCIAL_POSITION F /*당기*/
                , GET_E_FINANCIAL_POSITION E --전기
            WHERE F.ACCOUNT_CODE = E.ACCOUNT_CODE (+)
           ) T
         , ACCOUNT A

    WHERE T.ACCOUNT_CODE = A.ACCOUNT_INNER_CODE (+)
  	ORDER BY MIN, MAX DESC NULLS LAST;


      P_ACCOUNTING_SETTLEMENT_STATUS(SEARCH_PERIOD_NO, ACCOUNTING_SETTLEMENT_STATUS, ERROR_CODE, ERROR_MSG, RESULT2);
      -- 회계결산현황 업데이트 여기에 대해서 수정 부탁 드립니다.
    IF ERROR_CODE != 0 THEN
        RETURN;   -- P_ACCOUNTING_SETTLEMENT_CHANGE의 에러 발생시 프로시저 종료한다
    END IF;


    ERROR_CODE := 0;
    ERROR_MSG := '재무상태표 성공';

EXCEPTION
WHEN NO_DATA_FOUND THEN
    ERROR_CODE := -1;
    ERROR_MSG := '조회할 데이터가 없습니다.';

WHEN OTHERS THEN
    ERROR_CODE := -2;
    ERROR_MSG := SQLERRM;

END P_FINANCIAL_POSITION;
/

