create PROCEDURE          "P_TMP_INCOME_STATEMENT"( SEARCH_PERIOD_NO IN VARCHAR2 ) --21번째줄
IS
    CURSOR GET_INCOME_STATEMENT IS
    SELECT * FROM(

-- =========================================================당기매출액 상세내용 --> 순매출액 = 총매출액 - 매출에누리및환인 - 매출할인
WITH SALES_DETAIL AS(  --당기 매출
    SELECT ACCOUNT_INNER_CODE,
           --계정내부코드
        ACCOUNT_NAME,
           --계정명
        '01' AS PARENT_ACCOUNT_CODE,
           --상위계정내부코드(임시테이블 손익계산서)
        CREDITS_SUM - DEBITS_SUM AS INCOME,
           --세부금액(")
           --대변(합계) - 차변(합계)
        NULL AS INCOME_SUMMARY, --합계금액(")
           -- 레벨
        2 AS LEV
    FROM(
        SELECT J.ACCOUNT_INNER_CODE,                          --계정내부코드(계정과목)
            A.ACCOUNT_NAME,                                   --계정명(계정과목)
            SUM(NVL(J.LEFT_DEBTOR_PRICE, 0)) AS DEBITS_SUM,   --차변금액(분개) AS  차변(합계)임시시산표테이블(매출에누리및환인,할인)
            SUM(NVL(J.RIGHT_CREDITS_PRICE, 0)) AS CREDITS_SUM --대변금액(분개) AS  대변(합계)임시시산표테이블(총매출액)
        FROM SLIP S,                        --전표
            JOURNAL J,                      -- 분개
            PERIOD P,                       -- 기수
            ACCOUNT A                       -- 계정과목
        WHERE S.SLIP_NO = J.SLIP_NO                         --일련번호 전표번호,분개번호조인
          AND J.ACCOUNT_INNER_CODE = A.ACCOUNT_INNER_CODE   --계정,분개 내부계정코드
          AND S.SLIP_STATUS LIKE '승인완료'                   --전표상태
          AND S.ACCOUNT_PERIOD_NO = P.ACCOUNT_PERIOD_NO     --회계기수일련번호
          AND P.ACCOUNT_PERIOD_NO = SEARCH_PERIOD_NO
          AND A.PARENT_ACCOUNT_INNER_CODE = '0401-0430'     --상위계정내부코드  매출
        GROUP BY J.ACCOUNT_INNER_CODE,
                 A.ACCOUNT_NAME
    )
),

-- =========================================================당기매출액총계(순매출액 총계)
SALES_SUMMARY AS(
    SELECT '01'         AS ACCOUNT_INNER_CODE,
        UNISTR('매출액') AS ACCOUNT_NAME,
        NULL            AS PARENT_ACCOUNT_CODE,
        NULL            AS INCOME,
        SUM(INCOME)     AS INCOME_SUMMARY,
        1             AS LEV
    FROM SALES_DETAIL
),

     --매출액 상세내용에서 INCOME SUM해줌
       /*
       1. 매출원가 = 상품매출원가 + 제품매출원가
       - 상품매출원가 = 기초상품재고액 + 당기상품순매입액 - 기말상품재고액
       - 제품매출원가 = 기초제품재고액 + 당기제품재고액 - 기말제품재고액
       - 제품매출원가는 재료비 + 노무비(인건비) + 제조경비로 구성
       2. 매출원가 및 기말상품재고액을 기존 데이터로는 계산으로 구할수 없어서 마진율을 30%을 적용
       - 매출원가 = 상품매출 * (1-0.7)
       */

--=========================================================당기매출원가총계
SALES_COST_SUMMARY AS(
    SELECT '02'                 AS ACCOUNT_INNER_CODE,
           UNISTR('매출원가')     AS ACCOUNT_NAME,
           NULL                 AS PARENT_ACCOUNT_CODE,
           NULL                 AS INCOME,
           INCOME_SUMMARY * (1-0.7) AS INCOME_SUMMARY,
           1                  AS LEV
    FROM SALES_SUMMARY
),

--=========================================================당기기초상품재고액
PREYEAR_FINAL_STOCK AS(
    SELECT E.PRICE              AS INCOME_SUMMARY
    FROM EARLY_CLOSING E, --기말상품재고액
         PERIOD P
    WHERE E.ACCOUNT_PERIOD_NO = P.ACCOUNT_PERIOD_NO
      AND E.CODE = '1001'
      AND P.ACCOUNT_PERIOD_NO = SEARCH_PERIOD_NO - 1
),

--=========================================================당기상품순매입액 = 총매입액 - 에누리및환입 - 매입할인
PURCHASE_RESULT AS(
    SELECT SUM(NVL(J.LEFT_DEBTOR_PRICE, 0))-SUM(NVL(J.RIGHT_CREDITS_PRICE, 0)) AS INCOME_SUMMARY
                --차변금액(분개) AS  차변(합계) 재료(상품) 총매입액
                --대변금액(분개) AS  대변(합계) 에누리및환인, 할인, 세금
    FROM SLIP S,    --전표
         JOURNAL J, -- 분개
         PERIOD P,  -- 기수
         ACCOUNT A  -- 계정과목
    WHERE S.SLIP_NO = J.SLIP_NO                         --일련번호 전표번호,분개번호조인
      AND J.ACCOUNT_INNER_CODE = A.ACCOUNT_INNER_CODE   --계정,분개 내부계정코드
      AND S.SLIP_STATUS LIKE '승인완료'                   --전표상태
      AND S.ACCOUNT_PERIOD_NO = P.ACCOUNT_PERIOD_NO     --회계기수일련번호
      AND P.ACCOUNT_PERIOD_NO = SEARCH_PERIOD_NO
      AND A.PARENT_ACCOUNT_INNER_CODE='0146-0175'       --상위계정내부코드  재고자산(자산매입)
                                                -- 수정전 AND A.ACCOUNT_INNER_CODE BETWEEN '0146' AND '0148'
),

--=========================================================당기 기말상품재고액
CURRENT_FINAL_STOCK AS(
    SELECT SUM(PRICE) AS PRICE
    FROM(
        SELECT INCOME_SUMMARY       AS PRICE
        FROM PREYEAR_FINAL_STOCK -- 전기기초상품재고액

            UNION ALL

        SELECT INCOME_SUMMARY       AS PRICE
        FROM PURCHASE_RESULT --당기상품순매입액

            UNION ALL

        SELECT (INCOME_SUMMARY * -1)   AS PRICE
        FROM SALES_COST_SUMMARY -- 당기매출원가
    )
),

--상품매출원가 = 전기 기초상품재고액 + 당기상품순매입액 - 당기 기말상품재고액

-- =========================================================상품매출원가 상세내용 = 기초상품재고액 + 당기상품순매입액 - 기말상품재고액
SALES_COST_DETAIL AS(  --매출원가 LV1 밑으로 들어가는 항목들  , 상품매출원가 관련 상세 내역들 집합!
    SELECT
           '0451'                   AS ACCOUNT_INNER_CODE,
           UNISTR('상품매출원가')     AS ACCOUNT_NAME,
           '02'                     AS PARENT_ACCOUNT_CODE,
           NULL                     AS INCOME,
           income_summary           AS INCOME_SUMMARY,
           2                      AS LEV
    FROM SALES_COST_SUMMARY  --당기 상품매출원가총계

        UNION ALL

    SELECT
           '021'                    AS ACCOUNT_INNER_CODE,
           UNISTR('기초상품재고액')    AS ACCOUNT_NAME,
           '02'                     AS PARENT_ACCOUNT_CODE,
           INCOME_SUMMARY           AS INCOME,
           NULL                     AS INCOME_SUMMARY,
           3                      AS LEV
    FROM PREYEAR_FINAL_STOCK  --전기 기말상품재고액

        UNION ALL

    SELECT
           '022'                    AS ACCOUNT_INNER_CODE,
           UNISTR('당기상품순매입액')  AS ACCOUNT_NAME,
           '02'                     AS PARENT_ACCOUNT_CODE,
           INCOME_SUMMARY AS INCOME,   -- INCOME_SUMMARY 에서  INCOME_SUMMARY AS INCOME로 수정
           NULL                     AS INCOME_SUMMARY,
           3                      AS LEV
    FROM PURCHASE_RESULT  --당기 상품순매입액

        UNION ALL
    SELECT
           '023'                    AS ACCOUNT_INNER_CODE,
           UNISTR('기말상품재고액')    AS ACCOUNT_NAME,
           '02'                     AS PARENT_ACCOUNT_CODE,
           PRICE                    AS INCOME,
           NULL                     AS INCOME_SUMMARY,
           3                      AS LEV
    FROM CURRENT_FINAL_STOCK  -- 당기 기말상품재고액
),

-- =========================================================매출 총이익 = 매출액총계(SALES_SUMMARY) - 매출원가총계(SALES_COST_SUMMARY)
GROSS_MARGIN AS(
    SELECT '03'                     AS ACCOUNT_INNER_CODE,
           UNISTR('매출총이익')       AS ACCOUNT_NAME,
           NULL                     AS PARENT_ACCOUNT_CODE,
           NULL                     AS INCOME,
           H.INCOME_SUMMARY - C.INCOME_SUMMARY
                                    AS INCOME_SUMMARY,
           1                      AS LEV
    FROM SALES_SUMMARY H,       --매출액총계
         SALES_COST_SUMMARY C   --매출원가총계
),

-- =========================================================판매 및 관리비 상세내용
SALES_MANAGE_COST_DETAIL AS(  --비용 합계 계산
    SELECT
           ACCOUNT_INNER_CODE,
           ACCOUNT_NAME,
           '04'                     AS PARENT_ACCOUNT_CODE,
           DEBITS_SUM - CREDITS_SUM AS INCOME,
           NULL                     AS INCOME_SUMMARY,
           2                      AS LEV
    FROM(
        SELECT
               J.ACCOUNT_INNER_CODE,
               A.ACCOUNT_NAME,
               SUM(J.LEFT_DEBTOR_PRICE)   AS DEBITS_SUM,
               SUM(J.RIGHT_CREDITS_PRICE) AS CREDITS_SUM
        FROM SLIP S,
             JOURNAL J,
             ACCOUNT A,
             PERIOD P
        WHERE S.SLIP_NO = J.SLIP_NO
          AND J.ACCOUNT_INNER_CODE = A.ACCOUNT_INNER_CODE
          AND S.SLIP_STATUS LIKE '승인완료'
          AND S.ACCOUNT_PERIOD_NO = P.ACCOUNT_PERIOD_NO
          AND P.ACCOUNT_PERIOD_NO = SEARCH_PERIOD_NO
          AND A.PARENT_ACCOUNT_INNER_CODE  in ('0801-0900', '0751-0800','0701-0750','0651-0700','0601-0650','0501-0600','0451-0470')
        GROUP BY J.ACCOUNT_INNER_CODE,
                 A.ACCOUNT_NAME
        )
),

-- =========================================================판매 및 관리비 총계
SALES_MANAGE_COST_SUMMARY AS(
    SELECT
           '04'                     AS ACCOUNT_INNER_CODE,
           UNISTR('판매 및 관리비')   AS ACCOUNT_NAME,
           NULL                     AS PARENT_ACCOUNT_CODE,
           NULL                     AS INCOME,
           NVL(SUM(INCOME), 0)      AS INCOME_SUMMARY,
           1                      AS LEV
    FROM SALES_MANAGE_COST_DETAIL  --판매 및 관리비 상세내용
),

-- =========================================================영업 이익(OPERATING_PROFIT) = 매출총이익(GROSS_MARGIN) - 판관비총계(SALES_MANAGE_COST_SUMMARY)
OPERATING_PROFIT AS(
    SELECT
           '05'                         AS ACCOUNT_INNER_CODE,
           UNISTR('영업이익')             AS ACCOUNT_NAME,
           NULL AS PARENT_ACCOUNT_CODE,
           NULL AS INCOME,
           G.INCOME_SUMMARY - S.INCOME_SUMMARY
                                        AS INCOME_SUMMARY,
           1                          AS LEV
    FROM GROSS_MARGIN G,                --매출총이익
         SALES_MANAGE_COST_SUMMARY S    --판관비총계
),

-- =========================================================영업외 수익 상세내용
NON_OPERATING_PROFIT_DETAIL AS(
    SELECT
           ACCOUNT_INNER_CODE,
           ACCOUNT_NAME,
           '06'                     AS PARENT_ACCOUNT_CODE,
           CREDITS_SUM - DEBITS_SUM AS INCOME,
           NULL                     AS INCOME_SUMMARY,
           2                      AS LEV
    FROM(
        SELECT
               J.ACCOUNT_INNER_CODE,
               A.ACCOUNT_NAME,
               SUM(J.LEFT_DEBTOR_PRICE)     AS DEBITS_SUM,
               SUM(J.RIGHT_CREDITS_PRICE)   AS CREDITS_SUM
        FROM SLIP S,
             JOURNAL J,
             ACCOUNT A,
             PERIOD P
        WHERE S.SLIP_NO = J.SLIP_NO
          AND J.ACCOUNT_INNER_CODE = A.ACCOUNT_INNER_CODE
          AND S.SLIP_STATUS LIKE '승인완료'
          AND J.ACCOUNT_INNER_CODE BETWEEN '0901' AND '0950'
          AND S.ACCOUNT_PERIOD_NO = P.ACCOUNT_PERIOD_NO
          AND P.ACCOUNT_PERIOD_NO = SEARCH_PERIOD_NO
        GROUP BY J.ACCOUNT_INNER_CODE
                   , A.ACCOUNT_NAME
    )
),

-- =========================================================영업외 수익 총계
NON_OPERATING_PROFIT_SUMMARY AS(
    SELECT
           '06'                         AS ACCOUNT_INNER_CODE,
           UNISTR('영업외 수익')          AS ACCOUNT_NAME,
           NULL                         AS PARENT_ACCOUNT_CODE,
           NULL                         AS INCOME,
           NVL(SUM(INCOME), 0)          AS INCOME_SUMMARY,
           1                          AS LEV
    FROM NON_OPERATING_PROFIT_DETAIL --영업외 수익 상세내용
),

-- =========================================================영업외 비용 상세내용
NON_OPERATING_COST_DETAIL AS(
    SELECT ACCOUNT_INNER_CODE,
           ACCOUNT_NAME,
           '07'                         AS PARENT_ACCOUNT_CODE,
           DEBITS_SUM - CREDITS_SUM     AS INCOME,
           NULL                         AS INCOME_SUMMARY,
           2                          AS LEV
    FROM(
        SELECT
               J.ACCOUNT_INNER_CODE,
               A.ACCOUNT_NAME,
               SUM(J.LEFT_DEBTOR_PRICE)   AS DEBITS_SUM,
               SUM(J.RIGHT_CREDITS_PRICE) AS CREDITS_SUM
        FROM SLIP S,
             JOURNAL J,
             ACCOUNT A,
             PERIOD P
        WHERE S.SLIP_NO = J.SLIP_NO
          AND J.ACCOUNT_INNER_CODE = A.ACCOUNT_INNER_CODE
          AND S.SLIP_STATUS LIKE '승인완료'
          AND A.PARENT_ACCOUNT_INNER_CODE = '0951-0997'
          AND S.ACCOUNT_PERIOD_NO = P.ACCOUNT_PERIOD_NO
          AND P.ACCOUNT_PERIOD_NO = SEARCH_PERIOD_NO
        GROUP BY J.ACCOUNT_INNER_CODE,
                 A.ACCOUNT_NAME
    )
),

-- =========================================================영업외 비용 총계
NON_OPERATING_COST_SUMMARY AS(
    SELECT
           '07'                         AS ACCOUNT_INNER_CODE,
           UNISTR('영업외 비용')          AS ACCOUNT_NAME,
           NULL                         AS PARENT_ACCOUNT_CODE,
           NULL                         AS INCOME,
           NVL(SUM(INCOME), 0)          AS INCOME_SUMMARY,
           1                          AS LEV
    FROM NON_OPERATING_COST_DETAIL --영업외 비용 상세내용
),

-- =========================================================법인세 차감전 이익 = 영업이익(OPERATING_PROFIT) + 영업 외 수익(NON_OPERATING_PROFIT_SUMMARY) - 영업 외 비용 총계(NON_OPERATING_COST_SUMMARY)
ORDINARY_PROFIT AS(
    SELECT
           '08'                             AS ACCOUNT_INNER_CODE,
           UNISTR('법인세 차감전 이익')        AS ACCOUNT_NAME,
           NULL                             AS PARENT_ACCOUNT_CODE,
           NULL                             AS INCOME,
           O.INCOME_SUMMARY + P.INCOME_SUMMARY - C.INCOME_SUMMARY
                                            AS INCOME_SUMMARY,
           1                              AS LEV
    FROM OPERATING_PROFIT O,  --영업이익
         NON_OPERATING_PROFIT_SUMMARY P,  --영업 외 수익
         NON_OPERATING_COST_SUMMARY C  --영업 외 비용
),

-- =========================================================법인세 상세내용
CORPORATE_TAX_DETAIL AS(
    SELECT
           ACCOUNT_INNER_CODE,
           ACCOUNT_NAME,
           '09'                         AS PARENT_ACCOUNT_CODE,
           CREDITS_SUM - DEBITS_SUM     AS INCOME,
           NULL                         AS INCOME_SUMMARY,
           2                          AS LEV
    FROM(
        SELECT
               J.ACCOUNT_INNER_CODE,
               A.ACCOUNT_NAME,
               SUM(J.LEFT_DEBTOR_PRICE)   AS DEBITS_SUM,
               SUM(J.RIGHT_CREDITS_PRICE) AS CREDITS_SUM
        FROM SLIP S,
             JOURNAL J,
             ACCOUNT A,
             PERIOD P
        WHERE S.SLIP_NO = J.SLIP_NO
          AND J.ACCOUNT_INNER_CODE = A.ACCOUNT_INNER_CODE
          AND S.SLIP_STATUS LIKE '승인완료'
          AND A.PARENT_ACCOUNT_INNER_CODE = '0998-0999'
          AND S.ACCOUNT_PERIOD_NO  = P.ACCOUNT_PERIOD_NO
          AND P.ACCOUNT_PERIOD_NO = SEARCH_PERIOD_NO
        GROUP BY J.ACCOUNT_INNER_CODE,
                 A.ACCOUNT_NAME
    )
),

-- =========================================================법인세 총계
CORPORATE_TAX_SUMMARY AS(
    SELECT
           '09'                 AS ACCOUNT_INNER_CODE,
           UNISTR('법인세')      AS ACCOUNT_NAME,
           NULL                 AS PARENT_ACCOUNT_CODE,
           NULL                 AS INCOME,
           NVL(SUM(INCOME), 0)  AS INCOME_SUMMARY,
           1                  AS LEV
    FROM CORPORATE_TAX_DETAIL  --법인세 상세내용
),

-- =========================================================당기 순이익 =법인세차감전이익(ORDINARY_PROFIT) - 법인세 총계(CORPORATE_TAX_SUMMARY)
NET_INCOME AS(
    SELECT
           '10'                                 AS ACCOUNT_INNER_CODE,
           UNISTR('당기 순이익')                  AS ACCOUNT_NAME,
           NULL                                 AS PARENT_ACCOUNT_CODE,
           NULL                                 AS INCOME ,
           O.INCOME_SUMMARY - C.INCOME_SUMMARY  AS INCOME_SUMMARY,
           1                                  AS LEV
    FROM ORDINARY_PROFIT O,  -- 법인세차감전이익
         CORPORATE_TAX_SUMMARY C  -- 법인세
)

------------------------------- WITH절 끝 ---------------------------------------
SELECT
       ACCOUNT_INNER_CODE,
       ACCOUNT_NAME,
       PARENT_ACCOUNT_CODE,
       NVL(INCOME,0),
       NVL(INCOME_SUMMARY,0),
       SEARCH_PERIOD_NO,
       LEV
FROM(
    SELECT * FROM SALES_SUMMARY  --당기매출액총계
       UNION ALL
    SELECT * FROM SALES_DETAIL
       UNION ALL
    SELECT * FROM SALES_COST_SUMMARY  --당기매출원가총계
       UNION ALL
    SELECT * FROM SALES_COST_DETAIL
       UNION ALL
    SELECT * FROM GROSS_MARGIN  --매출 총이익
       UNION ALL
    SELECT * FROM SALES_MANAGE_COST_SUMMARY  --판매 및 관리비 총계
       UNION ALL
    SELECT * FROM SALES_MANAGE_COST_DETAIL
       UNION ALL
    SELECT * FROM OPERATING_PROFIT  --영업 이익
       UNION ALL
    SELECT * FROM NON_OPERATING_PROFIT_SUMMARY  --영업외 수익 총계
       UNION ALL
    SELECT * FROM NON_OPERATING_PROFIT_DETAIL
       UNION ALL
    SELECT * FROM NON_OPERATING_COST_SUMMARY  --영업외 비용 총계
       UNION ALL
    SELECT * FROM NON_OPERATING_COST_DETAIL
       UNION ALL
    SELECT * FROM ORDINARY_PROFIT  --법인세 차감전 이익
       UNION ALL
    SELECT * FROM CORPORATE_TAX_SUMMARY  --법인세
       UNION ALL
    SELECT * FROM CORPORATE_TAX_DETAIL
       UNION ALL
    SELECT * FROM NET_INCOME  --순수익
) A
);



TYPE INCOME_STATEMENT_TYPE IS RECORD(
            ACCOUNT_INNER_CODE      VARCHAR2(20),
            ACCOUNT_NAME            NVARCHAR2(20),
            PARENT_ACCOUNT_CODE     VARCHAR2(20),
            INCOME                  NUMBER(38) ,
            INCOME_SUMMARY          NUMBER(38) ,
            PERIOD_NO               VARCHAR2(2) ,
            LEV                     NUMBER(38)
);

INCOME_STATEMENT INCOME_STATEMENT_TYPE;

BEGIN

    DELETE FROM TMP_INCOME_STATEMENTS2;

    OPEN GET_INCOME_STATEMENT ;
    LOOP
        FETCH GET_INCOME_STATEMENT INTO INCOME_STATEMENT;
        EXIT
    WHEN GET_INCOME_STATEMENT%NOTFOUND;

    INSERT INTO TMP_INCOME_STATEMENTS2 VALUES(
        INCOME_STATEMENT.ACCOUNT_INNER_CODE,
        INCOME_STATEMENT.ACCOUNT_NAME,
        INCOME_STATEMENT.PARENT_ACCOUNT_CODE,
        INCOME_STATEMENT.INCOME,
        INCOME_STATEMENT.INCOME_SUMMARY,
        INCOME_STATEMENT.PERIOD_NO,
        INCOME_STATEMENT.LEV
    );

    END LOOP;

END P_TMP_INCOME_STATEMENT;
/

