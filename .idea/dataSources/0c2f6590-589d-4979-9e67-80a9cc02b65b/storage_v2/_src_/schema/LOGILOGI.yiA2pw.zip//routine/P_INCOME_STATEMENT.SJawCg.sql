create PROCEDURE          P_INCOME_STATEMENT(  --39번째줄부터 시쟉
                                                SEARCH_PERIOD_NO IN VARCHAR2
                                               , ACCOUNTING_SETTLEMENT_STATUS IN VARCHAR2
                                               , ERROR_CODE OUT NUMBER
                                               , ERROR_MSG OUT VARCHAR2
                                               , RESULT OUT SYS_REFCURSOR
                                               , RESULT2 OUT SYS_REFCURSOR
                                               )
IS
BEGIN


  OPEN RESULT FOR
    WITH
      GET_E_INCOME_STATEMENT AS (SELECT * FROM INCOME_STATEMENT WHERE PERIOD_NO = (SEARCH_PERIOD_NO - 1) ),       --전기 데이터를 담기
      GET_INCOME_STATEMENT AS (SELECT * FROM INCOME_STATEMENT WHERE PERIOD_NO = SEARCH_PERIOD_NO)                --당기 데이터를 담기

      SELECT ACCOUNT_INNER_CODE,                      --계정코드
             LPAD(' ', Lev*4) || ACCOUNT_NAME AS ACCOUNT_NAME, --계정과목
             PARENT_ACCOUNT_CODE,                     --부모코드
             INCOME,                                  --당기 세부금액
             INCOME_SUMMARY,                          --당기 합계금액
             EARLY_INCOME,          --전기 세부금액
             EARLY_INCOME_SUMMARY,  --전기 합계금액
             LEV,                                      -- 레벨
             SEARCH_PERIOD_NO	AS PERIOD_NO	--회계기수
      FROM
            (   SELECT L.ACCOUNT_INNER_CODE,                      --계정코드
                ROW_NUMBER() OVER(PARTITION BY L.LEV, L.PARENT_ACCOUNT_CODE
                            ORDER BY L.ACCOUNT_INNER_CODE)||'.'|| L.ACCOUNT_NAME AS ACCOUNT_NAME, --그룹 및 레벨별 계정과목
                 L.PARENT_ACCOUNT_CODE,                     --부모코드
                 I.INCOME,                                  --당기 세부금액
                 I.INCOME_SUMMARY,                          --당기 합계금액
                 E.INCOME AS  EARLY_INCOME,                 --전기 세부금액
                 E.INCOME_SUMMARY AS EARLY_INCOME_SUMMARY,  --전기 합계금액
                 L.LEV

            FROM (
                  SELECT DISTINCT ACCOUNT_INNER_CODE, ACCOUNT_NAME, PARENT_ACCOUNT_CODE, LEV         --DISTINCT = 중복데이터를 포함 안하겠다는 의미
                  FROM (SELECT *
                        FROM GET_INCOME_STATEMENT --당기손익계산

                        UNION ALL   --당기와 전기에 쓰인 계정과목을 추출하기위해 이런식으로 함

                        SELECT *
                        FROM GET_E_INCOME_STATEMENT) --전기손익계산
                 )L,
                 GET_INCOME_STATEMENT I,
                 GET_E_INCOME_STATEMENT E
            WHERE L.ACCOUNT_INNER_CODE = I.ACCOUNT_INNER_CODE(+)
            AND L.ACCOUNT_INNER_CODE = E.ACCOUNT_INNER_CODE(+)
            AND LENGTH(L.ACCOUNT_INNER_CODE)<5
        )

        START WITH PARENT_ACCOUNT_CODE IS NULL
        CONNECT BY PRIOR ACCOUNT_INNER_CODE = PARENT_ACCOUNT_CODE
        ORDER SIBLINGS BY LEV;


      P_ACCOUNTING_SETTLEMENT_STATUS(SEARCH_PERIOD_NO, ACCOUNTING_SETTLEMENT_STATUS, ERROR_CODE, ERROR_MSG, RESULT2);
      -- 회계결산현황 업데이트 여기에 대해서 수정 부탁 드립니다.

      IF ERROR_CODE != 0 THEN
         RETURN;   -- P_ACCOUNTING_SETTLEMENT_CHANGE의 에러 발생시 프로시저 종료한다
      END IF;

  ERROR_CODE := 0;
  ERROR_MSG := '손익계산서 성공';

 EXCEPTION
  WHEN
    NO_DATA_FOUND
    THEN
      ERROR_CODE := -1;
      ERROR_MSG := '조회할 데이터가 없습니다.';
  WHEN
    OTHERS
    THEN
      ERROR_CODE := -2;
      ERROR_MSG := SQLERRM;

END P_INCOME_STATEMENT;
/

