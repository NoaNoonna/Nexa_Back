create PROCEDURE     "P_EARLY_CLOSING" (
    p_period_no early_closing.account_period_no%TYPE
)

IS
v_price number;

BEGIN

    select price into v_price from
            (
                WITH
                    /*
                    1. 매출원가 = 상품매출원가 + 제품매출원가
                        - 상품매출원가 = 기초상품재고액 + 당기상품순매입액 - 기말상품재고액
                        - 제품매출원가 = 기초제품재고액 + 당기제품재고액 - 기말제품재고액
                        - 제품매출원가는 재료비 + 노무비(인건비) + 제조경비로 구성
                    2. 매출원가 및 기말상품재고액을 기존 데이터로는 계산으로 구할수 없어서 마진율을 70%을 적용
                        - 매출원가 = 상품매출 * (1-0.7)
                    */

                    -- 매출원가총계
                    SALES_COST_SUMMARY AS
                        (SELECT SUM(INCOME) * (1-0.7) AS INCOME_SUMMARY --매출원가총액 = 매출액 * (1-0.7)
                        FROM
                            (SELECT J.ACCOUNT_INNER_CODE
                                    , --계정내부코드(계정과목)
                                    A.ACCOUNT_NAME
                                    , --계정명(계정과목)
                                    SUM(NVL(J.RIGHT_CREDITS_PRICE, 0)) - SUM(NVL(J.LEFT_DEBTOR_PRICE, 0)) AS INCOME
                                    --대변(합계) - 총매출액 - 차변(합계) -매출에누리및환인,할인
                                FROM SLIP S
                                    , --전표
                                    JOURNAL J
                                    , -- 분개
                                    PERIOD P
                                    , -- 기수
                                    ACCOUNT A -- 계정과목
                                WHERE S.SLIP_NO = J.SLIP_NO --일련번호 전표번호,분개번호조인
                                    AND J.ACCOUNT_INNER_CODE = A.ACCOUNT_INNER_CODE --계정,분개 내부계정코드
                                    AND S.SLIP_STATUS LIKE '승인완료' --전표상태
                                    AND S.ACCOUNT_PERIOD_NO = P.ACCOUNT_PERIOD_NO --회계기수일련번호
                                    AND P.ACCOUNT_PERIOD_NO = P_PERIOD_NO
                                    AND A.PARENT_ACCOUNT_INNER_CODE = '0401-0430' --상위계정내부코드  매출
                                GROUP BY J.ACCOUNT_INNER_CODE, A.ACCOUNT_NAME
                            )
                        ),

                    -- 기초상품재고액
                    preyear_final_stock AS (
                        SELECT e.price AS income_summary
                        FROM
                            early_closing  e,
                            period         p
                        WHERE
                            e.account_period_no = p.ACCOUNT_PERIOD_NO
                            AND e.code = '1001'
                            AND p.ACCOUNT_PERIOD_NO = p_period_no - 1
                            ),

                    -- 당기상품순매입액 = 총매입액 - 에누리및환입 - 매입할인
                    purchase_result AS (
                        SELECT
                            abs(SUM(nvl(j.left_debtor_price, 0)) - SUM(nvl(j.right_credits_price, 0))) AS income_summary
                            --차변금액(분개) AS  차변(합계) 재료(상품) 총매입액
                            --대변금액(분개) AS  대변(합계) 에누리및환인, 할인, 세금
                        FROM
                            slip     s, --전표
                            journal  j, -- 분개
                            period   p, -- 기수
                            account  a -- 계정과목
                        WHERE
                            s.slip_no = j.slip_no --일련번호 전표번호,분개번호조인
                            AND j.account_inner_code = a.account_inner_code --계정,분개 내부계정코드
                            AND s.slip_status LIKE '승인완료' --전표상태
                            AND s.ACCOUNT_PERIOD_NO = p.ACCOUNT_PERIOD_NO --회계기수일련번호
                            AND p.ACCOUNT_PERIOD_NO = p_period_no
                            AND a.parent_account_inner_code = '0146-0175' --상위계정내부코드  매입
                            -- 수정전 AND A.ACCOUNT_INNER_CODE BETWEEN '0146' AND '0148'
                        )

                    --당기 기말상품재고액
                    SELECT SUM(price) AS price
                    FROM (
                        SELECT
                            income_summary AS price
                        FROM
                            preyear_final_stock -- 기초상품재고액
                        UNION ALL
                        SELECT
                            income_summary AS price
                        FROM
                            purchase_result --당기상품순매입액
                        UNION ALL
                        SELECT
                                (INCOME_SUMMARY *- 1) AS price
                        FROM
                            sales_cost_summary -- 매출원가
                )
        );






    MERGE INTO EARLY_CLOSING e
    		USING dual
    		ON (e.account_period_no = p_period_no)

						WHEN matched THEN    -- 당기의 회계기수가 있다면 업데이트
							    UPDATE SET e.price = v_price

            WHEN NOT MATCHED THEN    -- 당기의 회계기수가 없다면 생성
                            INSERT VALUES(
               				p_period_no
             					, '1001'
             					, '기말상품재고액'
             					, v_price
           				);


END P_EARLY_CLOSING;
/

