create PROCEDURE          "P_ORDER" --현재 전개된 결과 발주 및 재고처리
(
    V_MRP_GATHERING_NO_LIST IN VARCHAR2,-- 매개변수 선언부,소요량취합번호리스트
    ERROR_CODE OUT NUMBER -- 에러코드
    ,ERROR_MSG OUT VARCHAR2 -- 에러메세지
)

IS

-- 변수,상수 선언부시작
V_ORDER_NO order_info.order_no%TYPE;

-- 커서선언 시작
CURSOR C_ORDER_DIALOG_TEMP
IS
select *
from order_dialog_temp;   --발주 필요목록 조회 할때 insert해서 값이 있음
--





-- 커서선언 끝

BEGIN
-- 실행부시작

-- 커서 LOOP 문 시작
FOR R_ODT IN C_ORDER_DIALOG_TEMP
LOOP

    -- 필요량이 재고량보다 많은경우 ( 발주하는경우 )
    -- STOCK 테이블의 정보 업데이트
    -- IF문 시작
    IF R_ODT.CALCULATED_REQUIRED_AMOUNT > 0 THEN --실제발주필요량; 즉, 실제발주필요량이 존재하는경우
    UPDATE STOCK
    SET                                    -- R_ODT.STOCK_AMOUNT = 사용가능한재고량
    STOCK.input_amount = STOCK.input_amount + R_ODT.STOCK_AMOUNT, --투입예정재고량 = 투입예정재고량+사용가능한재고량
    STOCK.STOCK_AMOUNT = STOCK.STOCK_AMOUNT - R_ODT.STOCK_AMOUNT, --재고량-사용가능한재고량
    STOCK.ORDER_AMOUNT = STOCK.ORDER_AMOUNT + R_ODT.CALCULATED_REQUIRED_AMOUNT  --입고예정재고량+실제발주필요량
    WHERE
    stock.item_code = R_ODT.ITEM_CODE;
    -- STOCK테이블 업데이트 끝

    -- 발주번호생성
    case
        when length(ORDER_SEQUENCE.NEXTVAL)<3
        then  V_ORDER_NO := 'ORDG'||TO_CHAR(SYSDATE,'yyyymmdd')||'-'||lpad(ORDER_SEQUENCE.currval,3,0);
        else  V_ORDER_NO := 'ORDG'||TO_CHAR(SYSDATE,'yyyymmdd')||'-'||to_char(ORDER_SEQUENCE.currval);
        end case;

    -- ORDER_INFO에 발주정보등록
    INSERT INTO ORDER_INFO VALUES
    (V_ORDER_NO,SYSDATE,'운송중','취합발주',R_ODT.ITEM_CODE,R_ODT.ITEM_NAME,R_ODT.CALCULATED_REQUIRED_AMOUNT,'N','N');

-----------------------------------------------------------------------------------
    -- 스톡로그정보만들어서 STOCK_LOG 테이블에 찍기
    -- 재고량에서 투입예정재고량으로 이동했다고 남기는 로그
    -- 현재고량이 0일때는 재고를 투입예정재고로 이동할 수 없으므로 0이상일때만 이동하도록 IF문 추가.
    IF R_ODT.STOCK_AMOUNT > 0 THEN --
    INSERT INTO STOCK_LOG VALUES ('남은재고투입예정','재고에서 투입예정재고로 이동',TO_CHAR(SYSDATE,'YYYY-MM-DD HH24:MI:SS'),
    R_ODT.ITEM_CODE,R_ODT.ITEM_NAME,R_ODT.STOCK_AMOUNT,'발주 및 재고처리');
    END IF;
-----------------------------------------------------------------------------------

    -- 발주량만큼 입고예정재고량에 추가됬다고 남기는 로그
    INSERT INTO STOCK_LOG VALUES
    ('부족재고발주','입고예정재고 증가',TO_CHAR(SYSDATE,'YYYY-MM-DD HH24:MI:SS'),
    R_ODT.ITEM_CODE,R_ODT.ITEM_NAME,R_ODT.CALCULATED_REQUIRED_AMOUNT,'발주 및 재고처리');



    -- 재고량이 필요량보다 많은경우 ( 발주 안함 )
    -- STOCK 테이블의 정보 업데이트
    ELSIF R_ODT.CALCULATED_REQUIRED_AMOUNT = 0 THEN
    UPDATE
    STOCK
    SET
    STOCK.INPUT_AMOUNT = STOCK.INPUT_AMOUNT + R_ODT.REQUIRED_AMOUNT,   --투입예정재고량
    STOCK.STOCK_AMOUNT = STOCK.STOCK_AMOUNT - R_ODT.REQUIRED_AMOUNT    --재고량
    WHERE
    stock.item_code = R_ODT.ITEM_CODE;
    --  STOCK 테이블 정보 업데이트 끝

    -- 스톡로그정보만들어서 STOCK_LOG에 찍기
    -- 재고량에서 투입예정재고량으로 이동한 로그
    INSERT INTO STOCK_LOG VALUES
    ('남은재고투입예정','재고에서 투입예정재고로 이동',TO_CHAR(SYSDATE,'YYYY-MM-DD HH24:MI:SS'),
    R_ODT.ITEM_CODE,R_ODT.ITEM_NAME,R_ODT.REQUIRED_AMOUNT,'발주 및 재고처리');

    -- IF문 끝
    END IF;

    -- order_dialog 띄울때 사용하는 프로시저에서 생성되는
    -- MRP_NO_TEMP 임시테이블을 이용   --P_ORDER_DIALOG_OPEN에서 INSERT해서 값이 있음
    -- MRP REQUEST_STATUS = 'Y' 로 묵시적 커서방식를 이용해서 업데이트해줌
    FOR V_MRP_GATHERING_NO IN
    (SELECT TRIM( REGEXP_SUBSTR( V_MRP_GATHERING_NO_LIST ,'[^,]+', 1, LEVEL ) ) MRP_GATHERING_NO
    FROM DUAL
    CONNECT BY REGEXP_SUBSTR( V_MRP_GATHERING_NO_LIST , '[^,]+', 1, LEVEL ) IS NOT NULL)
    LOOP
         UPDATE MRP
         SET MRP.request_status = 'Y'
         WHERE MRP.MRP_GATHERING_NO = V_MRP_GATHERING_NO.MRP_GATHERING_NO;

         UPDATE MRP_GATHERING
         SET MRP_GATHERING.request_status = 'Y'
         WHERE MRP_GATHERING.MRP_GATHERING_NO = V_MRP_GATHERING_NO.MRP_GATHERING_NO;
    END LOOP;
    -- MRP 테이블 REQUEST_STATUS UPDATE 완료

-- 커서 LOOP문 끝
END LOOP;


-- 성공시 커밋
COMMIT;

ERROR_CODE := '0';
ERROR_MSG := '발주 성공//프로시저에서 날라온 값임';

-- 예외 발생시
EXCEPTION

WHEN NO_DATA_FOUND THEN
       DBMS_OUTPUT.PUT_LINE('NO_DATA_FOUND');
       ERROR_CODE := '-1';
       ERROR_MSG := 'NO_DATA_FOUND';
       RETURN;

WHEN DUP_VAL_ON_INDEX THEN
       DBMS_OUTPUT.PUT_LINE('DUP_VAL_ON_INDEX');
       ERROR_CODE := '-1';
       ERROR_MSG := 'DUP_VAL_ON_INDEX';
       RETURN;
WHEN OTHERS THEN
       DBMS_OUTPUT.PUT_LINE('OTHERS');
       ERROR_CODE := '-1';
       ERROR_MSG := '관리자에게 문의 하세요 // 01077239513';
       RETURN;


-- PROCEDURE 끝
END;
/

