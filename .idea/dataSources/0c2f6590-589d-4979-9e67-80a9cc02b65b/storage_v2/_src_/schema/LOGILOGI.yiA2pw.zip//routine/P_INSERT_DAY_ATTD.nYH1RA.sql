create PROCEDURE          P_INSERT_DAY_ATTD
(
      P_EMP_CODE      IN DAY_ATTD.EMP_CODE%TYPE, -- 출퇴근,외출 테이블의 데이터타입
      P_SEQUENCE      IN DAY_ATTD.ATTD_TYPE_CODE%TYPE,--시퀀스, 데이터값이중복되지않게고유번호
      P_DAY_ATTD_CODE IN DAY_ATTD.ATTD_TYPE_NAME%TYPE,
      P_DAY_ATTD_NAME IN DAY_ATTD.ATTD_TYPE_NAME%TYPE,
      P_APPLY_DAY     IN DAY_ATTD.APPLY_DAY%TYPE,
      P_TIME          IN DAY_ATTD.TIME%TYPE,
      P_ERROR_CODE    OUT VARCHAR2, -- 출력매개변수, 호출한곳으로리턴되는값
      P_ERROR_MSG     OUT VARCHAR2

)
IS  -- 변수선언부   IS 는 맞다아니다 구분, V는 여기서쓰는변수, P는파라메터로받은값

      V_ATTD_COUNT        DAY_ATTD.ATTD_TYPE_NAME%TYPE;      -- 이렇게 타입 형식을 들고 오는 이유는 변경된 데이터를 그대로 사용할 수 있기 때문에
     V_LEAVE_COUNT        DAY_ATTD.ATTD_TYPE_NAME%TYPE;
     V_COMMUTE_COUNT     DAY_ATTD.ATTD_TYPE_NAME%TYPE;
      V_ALREADY_QUIT      DAY_ATTD.ATTD_TYPE_NAME%TYPE;
      V_LAST_DAY_ATTD     DAY_ATTD.ATTD_TYPE_NAME%TYPE;
      V_LAST_LEAVE_TIME   DAY_ATTD.TIME%TYPE;

      V_DAY               VARCHAR2(20);
      V_HOLIDAY           HOLIDAY.HOLIDAY_NAME%TYPE;  -- 공휴일테이블의 데이터타입
      IS_HOLIDAY          HOLIDAY.HOLIDAY_NAME%TYPE; -- 공휴일 Y or N
      V_EARLY_OUT_TIME    REST_ATTD.START_TIME%TYPE; -- 근태외신청테이블의데이터타입
      IS_EARLY_OUT        VARCHAR2(20);
      IS_OVER_WORK        VARCHAR2(20); -- 초과근무 Y or N
      V_OVER_END_DAY      REST_ATTD.END_DATE%TYPE;
      V_OVER_END_TIME      REST_ATTD.END_TIME%TYPE;
      V_BANCHA            REST_ATTD.REST_TYPE_CODE%TYPE;
      IS_BANCHA           VARCHAR2(20);
      IS_INSERT           VARCHAR2(20);
      V_OUT_TIME          BASE_WORK_TIME.QUIT_TIME%TYPE; -- 기본근무시간관련테이블의데이터타입

      V_ATTD_CODE         DAY_ATTD.ATTD_TYPE_CODE%TYPE;
      V_ATTD_NAME         DAY_ATTD.ATTD_TYPE_NAME%TYPE;
      V_LAST_LEAVE        DAY_ATTD.ATTD_TYPE_NAME%TYPE;
      V_OUTSIDE              DAY_ATTD.ATTD_TYPE_CODE%TYPE;   -- 외출 변수 (추가)
      V_COUNTOUT           DAY_ATTD.ATTD_TYPE_NAME%TYPE;   -- 외출 찍은 횟수 변수(추가)
      V_COUNTIN             DAY_ATTD.ATTD_TYPE_NAME%TYPE;   --귀사 찍은 횟수 변수(추가)
      IS_OUT_SIDE          VARCHAR2(20);  --외출 변수(추가)
      IS_IN_SIDE       VARCHAR2(20);  -- 귀사 변수 (추가)


BEGIN       -- 이렇게 초기화 해주는 이유는 NOT NULL 일 경우 초기 값을 넣어주어야 한다.
        V_DAY := NULL;
        IS_HOLIDAY := NULL;
        IS_EARLY_OUT := NULL; --조퇴유무
        V_EARLY_OUT_TIME := 0;
        IS_BANCHA := NULL;
        IS_INSERT := 'N';  -- 퇴근기록 기본값 N
        IS_OVER_WORK := NULL;
       IS_OUT_SIDE  := NULL;
         IS_IN_SIDE  :=NULL;
--        P_ERROR_CODE :=0;
--        P_ERROR_MSG :='기록완료';

                     BEGIN   -- 새벽퇴근 중복 관련
                                SELECT COUNT(*)
                                 INTO V_LEAVE_COUNT  -- 퇴근 찍은 횟수
                                FROM DAY_ATTD
                                WHERE EMP_CODE=P_EMP_CODE
                                  AND APPLY_DAY=P_APPLY_DAY-1
                                 AND ATTD_TYPE_CODE='ADC002'; -- 퇴근
                                  END;

         BEGIN   -- 새벽퇴근 중복 관련
                                SELECT COUNT(*)
                                 INTO V_COMMUTE_COUNT  -- 전날 출근 찍은 횟수
                                FROM DAY_ATTD
                                WHERE EMP_CODE=P_EMP_CODE
                                  AND APPLY_DAY=P_APPLY_DAY-1
                                 AND ATTD_TYPE_CODE='ADC001'; -- 퇴근
                                  END;

        /* 기록 조건 검사 */
         -- 출근 제일먼저, 퇴근하면 아무것도 기록 못하게
        BEGIN
              SELECT COUNT(*)
              INTO V_ATTD_COUNT  -- 출근 찍은 횟수
              FROM DAY_ATTD
              WHERE EMP_CODE=P_EMP_CODE
              AND APPLY_DAY=P_APPLY_DAY
              AND ATTD_TYPE_CODE='ADC001';  --출근을 찍은 횟수 계산필요하기 때문에.
  -- 매개변수로 넘어온 p_emp_code,p_apply_day 가
  -- day_attd테이블의 사원코드와 날짜가 같을경우
  -- 전체행의 수를 V_ATTD_COUNT 변수에 담음

       IF V_ATTD_COUNT = 0  AND P_DAY_ATTD_CODE NOT IN ( 'ADC001')
             and  (V_LEAVE_COUNT=1 OR V_COMMUTE_COUNT=0) THEN -- 조회된데이터가없을경우실행(출근을 먼저 찍어야 하고 퇴근은 밑에서 제한 해두었다.)
               P_ERROR_CODE := -1;
                P_ERROR_MSG := '출근을 먼저 기록해주세요';
                RETURN;
                END IF;




  -- 조회된 데이터가 없을경우다음IF문실행
  -- CODE가 퇴근이랑 같우 ERROR_CODE에 0을 담고 퇴근이면
  -- ELSEIF로 출근이랑 같지 않을 경우 ERROR_CODE 에 -1,
  -- MSG에 출근먼저 기록 을 담고 프로시저호출한곳으로 빠져나감



--              IF V_ATTD_COUNT = 0
--                THEN
--                      IF P_DAY_ATTD_CODE = 'ADC002'
--                      THEN ;
--                ELSIF P_DAY_ATTD_CODE != 'ADC001'
--              THEN P_ERROR_CODE := '-1';
--                   P_ERROR_MSG  := '출근 먼저 기록해주세요';
--                   RETURN;
--              END IF;


              IF
              V_ATTD_COUNT = 1
              AND P_DAY_ATTD_CODE = 'ADC001'
              THEN P_ERROR_CODE := '-1';
                   P_ERROR_MSG  := '이미 출근 기록을 했습니다';
                   RETURN;
              END IF;

-- 조회된데이터가 있고, 출근일경우
-- 에러코드,에러메세지를 담아서 프로시저빠져나감


              SELECT COUNT(*)
              INTO V_ALREADY_QUIT   -- 퇴근 찍은 횟수 (변수 이름 변경 필요) 요상해
              FROM DAY_ATTD
              WHERE ATTD_TYPE_CODE='ADC002'
              AND EMP_CODE=P_EMP_CODE
              AND APPLY_DAY=P_APPLY_DAY ;
-- CODE가 퇴근이고 사원코드와 날짜가 같은 것을 조회


              IF V_ALREADY_QUIT = 1
              THEN P_ERROR_CODE := '-1';
                   P_ERROR_MSG  := '퇴근 후에는 기록할 수 없습니다';
                   RETURN;
              END IF;

        END;
-- 위에서구한값이 퇴근이기때문에 결과값이 한개가 나오는데
-- 이미 퇴근을 했으면 기록이 불가함
-- 이까지 프로시저가 return  없이 실행됬으면
--  EXCEPTION 으로 WHEN OTHERS THEN : 특별한예외명
-- 에러코드를 0으로 할당하고 다음 BEGIN절 실행 , 에러코드가 - 여야 에러발생임





        /* INSERT */
        BEGIN -- 오늘 요일
                SELECT TO_CHAR(P_APPLY_DAY,'D')
                INTO V_DAY
                FROM DUAL;
        END;
--더미테이블로 오늘 요일을 조회(1일-7)해서 V_DAY 변수에담음


        BEGIN -- 공휴일
                SELECT HOLIDAY_NAME
                INTO V_HOLIDAY
                FROM HOLIDAY  -- 공휴일테이블
                WHERE APPLY_DAY=P_APPLY_DAY;

                IS_HOLIDAY := 'Y';
        EXCEPTION
        WHEN NO_DATA_FOUND THEN
               IS_HOLIDAY := 'N';
        WHEN OTHERS THEN
               P_ERROR_CODE := '-1';
               P_ERROR_MSG  := 'HOLIDAY 찾다가 EXCEPTION';
        END;
-- 공휴일 날짜가 받아온값이랑 같은 걸 조회해서
-- V_HOLIDAY 변수에 공휴일 이름을 담고,
-- IS_HOLIDAY에 Y 있음 으로 할당함
-- 데이터가 없을 경우에 N 없다고 예외처리하고
-- ERROR_CODE, MSG 할당




        BEGIN -- 조퇴 데이터 가져오기
                SELECT START_TIME -- 신청시간
                INTO V_EARLY_OUT_TIME
                FROM REST_ATTD -- 근태외신청(공,사외출, 조퇴)
                WHERE APPLOVAL_STATUS='승인'
                AND REST_TYPE_CODE='DAC004'  -- 조퇴
                AND EMP_CODE=P_EMP_CODE
                AND START_DATE=P_APPLY_DAY ;
                IS_EARLY_OUT := 'Y';
        EXCEPTION
        WHEN NO_DATA_FOUND THEN
             IS_EARLY_OUT := 'N';
        WHEN OTHERS THEN
                P_ERROR_CODE := '-1';
                P_ERROR_MSG  := '조퇴 데이터 가져오다가 EXCEPTION 발생';
        END;



        ---------------------------- 내가 짠거

         BEGIN                -- 외출과 귀사의 횟수를 이용하여 정상적으로 작동 되는지 검사

                   SELECT A, B
                   INTO V_COUNTOUT,V_COUNTIN
                   FROM
             (SELECT COUNT(*)  A  FROM DAY_ATTD
              WHERE ATTD_TYPE_CODE IN( 'ADC003','ADC005','ADC011','ADC012','ADC013')
              AND EMP_CODE=P_EMP_CODE
              AND APPLY_DAY=P_APPLY_DAY
              )  , --외출
              (SELECT COUNT(*)  B FROM DAY_ATTD
                WHERE ATTD_TYPE_CODE IN ('ADC007','ADC008','ADC009','ADC010','ADC014')
                 AND EMP_CODE=P_EMP_CODE
              AND APPLY_DAY=P_APPLY_DAY
                ) ; -- 귀사


            IF V_COUNTOUT=V_COUNTIN  THEN
            IS_OUT_SIDE:='N' ;                        -- 외출,귀사 횟수 비교(외출용)
            IS_IN_SIDE:='Y' ;                    -- 외출,귀사 횟수 비교(귀사용) --- 어라????? 변수 하나로 사용 가능한거 같은데... 수정 고민 해보기
              ELSE  IS_OUT_SIDE:='Y' ;
               IS_IN_SIDE:='N' ;
              END IF;

                EXCEPTION
        WHEN NO_DATA_FOUND THEN
            IS_OUT_SIDE := 'N';

        WHEN OTHERS THEN

                P_ERROR_CODE := '-1';
                P_ERROR_MSG  := '비교하다가 오류 발생';

         END;


--         BEGIN -- 외출 데이터 가져오기
--
--         IF IS_OUT_SIDE = 'N' THEN
--
--                SELECT ATTD_TYPE_CODE
--                   INTO V_OUTSIDE
--                FROM (
--                SELECT ATTD_TYPE_CODE -- 신청시간
--               FROM DAY_ATTD -- 근태외신청(공,사외출, 조퇴)
--               WHERE ATTD_TYPE_CODE IN('ADC005','ADC003')
--               AND EMP_CODE=P_EMP_CODE
--              AND APPLY_DAY=P_APPLY_DAY
--              ORDER BY TIME DESC )
--              WHERE ROWNUM=1;
--
--                  END IF;
--
--        EXCEPTION
--        WHEN NO_DATA_FOUND THEN
--            IS_OUT_SIDE := 'N';
--        WHEN OTHERS THEN
--                        P_ERROR_CODE := '-1';
--                P_ERROR_MSG  := '외출 그만 나가!!!';
--        END;
--
         ------------------------------- 내가 짠거

-- 근태외신청테이블에서 승인, 조퇴코드, 사원코드, 신청시간이 맞으면
-- V_EARLY_OUT_TIME 에 신청날짜를 담고,
-- IS_EARLY_OUT에 Y 맞음으로 셋팅
-- 데이터가 없을경우 N 없고 나머지셋팅



               BEGIN -- 초과근무 데이터 가져오기
                SELECT END_DATE, END_TIME -- 종료날짜,시간
                INTO V_OVER_END_DAY, V_OVER_END_TIME
                FROM REST_ATTD
                WHERE APPLOVAL_STATUS='승인'
                AND REST_TYPE_CODE='ASC008' -- 초과근무
                AND EMP_CODE=P_EMP_CODE
                AND START_DATE=P_APPLY_DAY ;
                 IS_OVER_WORK :='Y';
        EXCEPTION
        WHEN NO_DATA_FOUND THEN
              IS_OVER_WORK :='N';
        WHEN OTHERS THEN
                P_ERROR_CODE := '-1';
                P_ERROR_MSG  := '초과근무 데이터 가져오다가 EXCEPTION 발생';
        END;

 -- 승인, 초과근무, 사원코드, 시작날짜가 맞으면
 -- V_OVER_END_DAY, V_OVER_END_TIME 종료날짜,시간넣고
 -- 초과근무 Y 데이터없으면 N


--        BEGIN   --초과근무(밤샘)
--                SELECT END_DATE, END_TIME
--                INTO V_OVER_END_DAY, V_OVER_END_TIME
--                FROM REST_ATTD
--                WHERE NUMBER_OF_DAYS=2
--                AND APPLOVAL_STATUS='승인'
--                AND REST_TYPE_CODE='ASC008'
--                AND EMP_CODE=P_EMP_CODE
--                AND START_DATE+1=P_APPLY_DAY;
--
--                IS_OVER_WORK :='Y';
--        EXCEPTION
--        WHEN NO_DATA_FOUND THEN
--             IS_OVER_WORK := 'N';
--
--        WHEN OTHERS THEN
--             P_ERROR_CODE := '-1';
--             P_ERROR_MSG  := '초과근무(밤샘) EXCEPTION임.';
--        END;


        BEGIN -- 오후반차
                SELECT REST_TYPE_CODE
                INTO V_BANCHA
                FROM REST_ATTD
                WHERE APPLOVAL_STATUS='승인'
                AND REST_TYPE_CODE='ASC007' -- 오후반차 DETAIL_CODE에있음
                AND EMP_CODE=P_EMP_CODE
                AND START_DATE=P_APPLY_DAY ;
                IS_BANCHA := 'Y';
        EXCEPTION
        WHEN NO_DATA_FOUND THEN
             IS_BANCHA := 'N';
        WHEN OTHERS THEN
             P_ERROR_CODE := '-1';
             P_ERROR_MSG  := '반차 EXCEPTION임.';
        END;







        BEGIN -- 퇴근시간
                SELECT QUIT_TIME
                INTO V_OUT_TIME
                FROM BASE_WORK_TIME
                WHERE APPLY_YEAR=2020;
        END;

-- 테이블에 2020년이없어서레코드추가함
-- 퇴근시간 18시로 고정되어있음




        BEGIN -- 기록
              CASE P_DAY_ATTD_CODE -- 출퇴근그런코드
              WHEN 'ADC001' THEN -- 출근이면 DAY_ATTD에 받아온 값을 추가
                            INSERT INTO DAY_ATTD VALUES(P_EMP_CODE,P_SEQUENCE, P_APPLY_DAY, P_DAY_ATTD_CODE,P_DAY_ATTD_NAME,P_TIME); RETURN;
              WHEN 'ADC002' THEN -- 퇴근
                IF P_TIME > 900 AND P_TIME < 1800 -- 근무시간
                                  THEN
                                        IF V_DAY IN (1,7) OR IS_HOLIDAY='Y'-- 주말(일,토요일)이거나 , 휴일
                                              THEN IS_INSERT :='Y';
                                        ELSIF IS_EARLY_OUT='Y' -- 조퇴
                                              THEN IF P_TIME = V_EARLY_OUT_TIME THEN IS_INSERT :='Y' ; --받아온값=신청시간이같으면
                                                      ELSE P_ERROR_CODE :=-1; P_ERROR_MSG:='조퇴 신청 시각을 확인해주세요';
                                                    END IF;
                                        ELSIF IS_BANCHA='Y' -- 오후반차
                                              THEN P_ERROR_CODE :=-1; P_ERROR_MSG:='반차 있음';
                                                    IF P_TIME >= 1300 THEN IS_INSERT :='Y';
                                                   ELSE P_ERROR_CODE :=-1; P_ERROR_MSG:='12시 이후에 퇴근할 수 있습니다';
                                                   END IF;

                                        ELSE P_ERROR_CODE :=-1; P_ERROR_MSG:='퇴근을 원하시면 조퇴신청이나 오후반차 신청을 해주세요';
                                        END IF;
                                     --=========================================
                                 --------- 심야근무 만들어야함, 초과근무 신청 안해도 퇴근이 늦게 찍히지만 근무시간에는 포함 안되게
                                 --==============================================

--                ELSIF P_TIME > 1900
--                AND P_TIME <= 2500 --초과근무구하기
--                                        THEN
--                                            IF IS_OVER_WORK = 'Y'  --초과근무
--                                                THEN
--                                                IF P_APPLY_DAY = V_OVER_END_DAY
--                                                THEN IS_INSERT :='Y'; --시작날짜와종료날짜가같으면
--                                                            ELSIF P_TIME=V_OVER_END_TIME
--                                                            THEN IS_INSERT :='Y'; --종료시간이같으면
--                                                            ELSE
--                                                            P_ERROR_CODE :=-1;
--                                                            P_ERROR_MSG:='퇴근 시각을 확인해주세요';
--                                                    END IF;
--                                            ELSE
--                                            P_ERROR_CODE :=-1;
--                                            P_ERROR_MSG:='퇴근을 원하시면 초과근무 신청을 해주세요';
--                                            END IF;
--                                  ELSIF P_TIME < 300
--                                    THEN
--                                      IF IS_OVER_WORK = 'Y'
--                                            THEN   IF  P_APPLY_DAY = V_OVER_END_DAY AND P_TIME = V_OVER_END_TIME THEN IS_INSERT :='Y';
--                                                    ELSE P_ERROR_CODE :=-1; P_ERROR_MSG:='퇴근 시각을 확인해주세요';
--                                                    END IF;
--                                      ELSE P_ERROR_CODE :=-1; P_ERROR_MSG:='퇴근을 원하시면 초과근무 신청을 해주세요'; --IS_OVER_WORK = 'Y'
--                                      END IF;
--
                      --           ELSE
                         --         P_ERROR_CODE :=-1;
                          --        P_ERROR_MSG:='조회 오류입니다';


                                  END IF;



                                IF V_LEAVE_COUNT=0 THEN           -- 새벽에 퇴근 찍었을 경우에  오전 9시 전 퇴근을 또 찍을 수 있거나 없게
                                      IF P_TIME< 900
                              THEN
                                  INSERT INTO
                                        DAY_ATTD
                                        VALUES(P_EMP_CODE,P_SEQUENCE, P_APPLY_DAY-1, P_DAY_ATTD_CODE,P_DAY_ATTD_NAME,P_TIME+2400);
                                     END IF;

                                ELSIF P_TIME <= 900 THEN
                               P_ERROR_CODE :=-1;
                              P_ERROR_MSG:='이미 퇴근 기록이 존재합니다. ';
                                   END IF;

                                  IF P_TIME >=1800
                                  THEN IS_INSERT :='Y';
                                  END IF; --퇴근시간

                                  IF IS_INSERT = 'Y'
                                  THEN
                                        INSERT INTO
                                        DAY_ATTD
                                        VALUES(P_EMP_CODE,P_SEQUENCE, P_APPLY_DAY, P_DAY_ATTD_CODE,P_DAY_ATTD_NAME,P_TIME);
                                        RETURN;

                                 END IF;
              WHEN 'ADC006' THEN -- 외출
                     IF IS_OUT_SIDE = 'Y' THEN  --- 밖에 있음
                     P_ERROR_CODE := '-1';
                     P_ERROR_MSG  := '있음';

                       RETURN;
           ELSE


                               BEGIN -- 승인된 공외출 사외출 rest_Attd에서 가져옴

                                        SELECT REST_TYPE_CODE, REST_TYPE_NAME
                                        INTO V_ATTD_CODE, V_ATTD_NAME
                                        FROM REST_ATTD
                                        WHERE APPLOVAL_STATUS='승인'
                                        AND EMP_CODE=P_EMP_CODE
                                        AND START_DATE= P_APPLY_DAY
                                        AND REST_TYPE_CODE IN ( 'ADC003','ADC005')
                                        AND P_TIME BETWEEN
                                         LOGILOGI.TIME_MINUS_FUNC(START_TIME,'30') AND
                                         LOGILOGI.TIME_PLUS_FUNC(START_TIME,'30') ;    --시간


                                        INSERT INTO DAY_ATTD VALUES(P_EMP_CODE,P_SEQUENCE, P_APPLY_DAY, V_ATTD_CODE,V_ATTD_NAME,P_TIME);
                                             RETURN;

                                  EXCEPTION

                                  WHEN NO_DATA_FOUND THEN --외출승인난게없으면데이터없음
                                      IF(P_TIME>=1300 AND P_TIME <=1400 ) THEN
                                   INSERT INTO DAY_ATTD VALUES(P_EMP_CODE,P_SEQUENCE, P_APPLY_DAY, 'ADC011','외출(점심)',P_TIME); -- 외출 신청없이 나간 경우

                                   ELSE IF (P_TIME<1300 OR P_TIME >1400 AND P_TIME<1800)
                                      THEN
                                     INSERT INTO DAY_ATTD VALUES(P_EMP_CODE,P_SEQUENCE, P_APPLY_DAY, 'ADC012','외출(무단)',P_TIME);  -- 점심시간 이외(정상근무 시간 중)

                                 -- 확인하기
                                  ELSE IF (P_TIME>=1800 AND   V_OVER_END_DAY IS NOT NULL)
                                    THEN
                                  INSERT INTO DAY_ATTD VALUES(P_EMP_CODE,P_SEQUENCE, P_APPLY_DAY, 'ADC013','외출(야간)',P_TIME);

                                     END IF;
                                   END IF;
                                   END IF;
                                  P_ERROR_CODE := '-1';
                                  P_ERROR_MSG  := '해당 시간에 승인된 외출이 없습니다';
                                  RETURN;
                                  END;
                                  END IF;


             WHEN 'ADC004' THEN -- 귀사

          IF   IS_IN_SIDE='N'  THEN   -- 외출
                BEGIN                --사귀사

             ----------------------------  짠거

                    SELECT
                        attd_type_code,
                        time
                    INTO
                        v_last_leave,
                        v_last_leave_time
                    FROM
                     ( SELECT * FROM  day_attd
                       WHERE
                        apply_day = p_apply_day
                        AND emp_code = p_emp_code
                        AND attd_type_code IN ( 'ADC003',  'ADC005','ADC011','ADC012','ADC013' )
                         ORDER BY TIME DESC)
                         WHERE ROWNUM=1 ;

                ----------------------------  짠거

                END;

                IF p_time < v_last_leave_time THEN
                    p_error_code := -1;
                    p_error_msg := '외출 이전시간은 입력할 수 없습니다.';
                ELSE
                    BEGIN
                        CASE v_last_leave
                            WHEN 'ADC003' THEN
                                v_attd_code := 'ADC007';
                                v_attd_name := '공귀사';
                            WHEN 'ADC005' THEN
                                v_attd_code := 'ADC008';
                                v_attd_name := '사귀사';
                           WHEN 'ADC011' THEN
                                v_attd_code := 'ADC009';
                                v_attd_name := '귀사(점심)';
                           WHEN 'ADC012' THEN
                                v_attd_code := 'ADC010';
                                v_attd_name := '귀사(무단)';
                          WHEN 'ADC013' THEN
                                v_attd_code := 'ADC014';
                                v_attd_name := '귀사(야간)';
                        END CASE;

                        INSERT INTO day_attd VALUES (
                            p_emp_code,
                            p_sequence,
                            p_apply_day,
                            v_attd_code,
                            v_attd_name,
                            p_time
                        );

                        return;
                    EXCEPTION
                        WHEN OTHERS THEN
                            p_error_code := -1;
                            p_error_msg := '귀사는 외출 기록 후에 가능합니다';
                            return;
                    END;

                END IF;
                END IF;
              END CASE;
        END;
END P_INSERT_DAY_ATTD;
/

