create PROCEDURE          "P_WORK_ORDER" --현재 모의전개된 결과 작업지시
(
    -- 매개변수 선언부
    P_MRP_GATHERING_NO IN VARCHAR2,
    P_WORKPLACE_CODE IN VARCHAR2 --사업장코드 로그인할때 선택하는 사업장코드
    ,P_PRODUCTION_PROCESS IN VARCHAR2 --생산공정코드 'PP002'
    ,ERROR_CODE OUT NUMBER -- 에러코드
    ,ERROR_MSG OUT VARCHAR2 -- 에러메세지
)

IS

-- 변수,상수 선언부시작

-- 작업지시품목이 반제품일때 완제품의 재료로 쓰일 제품인지 판매용반제품인지 검사하기위한 변수
V_FINISHED_OR_SEMI_FINISHED VARCHAR2(50);

-- 작업지시 일련번호 담는 변수
V_WORK_ORDER_NO VARCHAR2(50);

-- 아이템구분(단위)
V_ITEM_CLASSIFICATION VARCHAR2(50);

--생산공정코드
V_PRODUCTION_PROCESS_CODE VARCHAR2(50);

--생산공정명
V_PRODUCTION_PROCESS_NAME VARCHAR2(50);

--작업장코드
V_WORK_SITE_CODE VARCHAR2(50);

--작업장명
V_WORK_SITE_NAME VARCHAR2(50);

-- 조건문에서 담을 변수
V_WORK_NAME VARCHAR2(50);
-- 커서선언 시작
CURSOR C_WORK_ORDER_SIMUL_TEMP IS
SELECT * FROM WORK_ORDER_SIMUL_TEMP; -- 모의작업지시 버튼을 눌렀을때 프로시저안에서 INSERT 함

-- 커서선언 끝
-- 변수,상수 선언부 끝

BEGIN
-- 실행부시작
V_PRODUCTION_PROCESS_NAME := NULL ; --생산공정명

V_WORK_SITE_CODE := NULL; --작업장코드

V_WORK_SITE_NAME := NULL; --작업장명

V_WORK_NAME := NULL; -- 나중에 작업장 검색할때 V_WORK_NAME || '%' 할때 사용
-- 반제품수주인지 완제품수주인지 검사
-- 임시테이블에서 작업지시품목인 아이템 가져와서 MPS_NO, ITEM_CODE 가져옴

-- 작업지시번호생성
case
    when length(WORK_ORDER_SEQ.NEXTVAL)<3
    then  V_WORK_ORDER_NO := 'WO'||TO_CHAR(SYSDATE,'yyyymmdd')||'-'||lpad(WORK_ORDER_SEQ.currval,2,0);
    else  V_WORK_ORDER_NO := 'WO'||TO_CHAR(SYSDATE,'yyyymmdd')||'-'||to_char(WORK_ORDER_SEQ.currval);
    end case;


-- 커서 LOOP 문 시작
FOR V_WORK_ORDER IN C_WORK_ORDER_SIMUL_TEMP
LOOP

-- 작업지시품목의 경우
IF V_WORK_ORDER.mrp_gathering_no=P_MRP_GATHERING_NO THEN

select
decode(item_classification,'IT-SI','반제품','완제품') item_classification
into V_ITEM_CLASSIFICATION
from
item
where
item_code =
(
SELECT
item_code
FROM WORK_ORDERABLE_TEMP
where mrp_gathering_no=P_MRP_GATHERING_NO
);

    SELECT
    		WS.WORK_SITE_CODE , --작업장코드
        WS.WORK_SITE_NAME , --작업장이름
        PP.PRODUCTION_PROCESS_CODE ,
        PP.PRODUCTION_PROCESS_NAME
            INTO
        V_WORK_SITE_CODE ,
        V_WORK_SITE_NAME ,
        V_PRODUCTION_PROCESS_CODE ,
        V_PRODUCTION_PROCESS_NAME
      FROM PRODUCTION_PROCESS PP , WORK_SITE WS -- PRODUCTION_PROCESS(생산공정), WORK_SITE(작업장)
      WHERE PP.WORKPLACE_CODE = P_WORKPLACE_CODE
      AND PP.PRODUCTION_PROCESS_CODE = P_PRODUCTION_PROCESS
      AND WS.WORK_SITE_NAME LIKE V_ITEM_CLASSIFICATION||'%';

    INSERT INTO WORK_ORDER_INFO VALUES(
        V_WORK_ORDER_NO, --작업지시일련번호
        V_WORK_ORDER.MRP_GATHERING_NO, --소요량취합일련번호
        V_ITEM_CLASSIFICATION, --품목분류
        V_WORK_ORDER.ITEM_CODE, --품목코드
        V_WORK_ORDER.ITEM_NAME, --품목명
        V_WORK_ORDER.UNIT_OF_MRP, --단위
        V_WORK_ORDER.REQUIRED_AMOUNT, --필요수량
        V_PRODUCTION_PROCESS_CODE, --생산공정코드
        V_PRODUCTION_PROCESS_NAME, --생산공정명
        V_WORK_SITE_CODE, --작업장코드
        V_WORK_SITE_NAME, --작업장명
        'Y', --검사/세적상태창
        NULL, --제작상태창
        NULL, --검사완료
        NULL --작업완료
        );

    -- 작업지시품목인 경우에만 REQUEST_STATUS = 'Y' 로 변경
    UPDATE
    mrp_gathering
    SET
    REQUEST_STATUS='Y'
    WHERE
    MRP_GATHERING_NO = V_WORK_ORDER.MRP_GATHERING_NO;

-- 소요되는 반제품의 경우
--납품 예정재고량에서 차감
ELSIF V_WORK_ORDER.ITEM_CLASSIFICATION='반제품' THEN

    -- 원재료 투입할것이므로 STOCK 업데이트
    UPDATE
    STOCK
    SET
    -- 재고의 투입예정 재고량에서 제작할때 소요되는 수량만큼 제거
    stock.delivery_amount = delivery_amount-V_WORK_ORDER.REQUIRED_AMOUNT
    WHERE
    -- 서로 아이템 코드가 같은경우만
    STOCK.ITEM_CODE = V_WORK_ORDER.ITEM_CODE;

    -- 원재료 소요한 내용 STOCK_LOG 에 찍기
    INSERT INTO STOCK_LOG VALUES
    (
    '투입예정재고투입',
    '투입예정재고감소',
    TO_CHAR(SYSDATE,'YYYY-MM-DD HH24:MI:SS'),
    V_WORK_ORDER.ITEM_CODE,
    V_WORK_ORDER.ITEM_NAME,
    V_WORK_ORDER.REQUIRED_AMOUNT,
    '작업지시');
-- 작업지시품목 / 원재료 구분 IF문 끝


-- 소요되는 원재료의 경우
else

    -- 원재료 투입할것이므로 STOCK 업데이트
    UPDATE
    STOCK
    SET
    -- 재고의 투입예정 재고량에서 제작할때 소요되는 수량만큼 제거
    STOCK.INPUT_AMOUNT = STOCK.INPUT_AMOUNT-V_WORK_ORDER.REQUIRED_AMOUNT
    WHERE
    -- 서로 아이템 코드가 같은경우만
    STOCK.ITEM_CODE = V_WORK_ORDER.ITEM_CODE;

    -- 원재료 소요한 내용 STOCK_LOG 에 찍기
    INSERT INTO STOCK_LOG VALUES
    (
    '투입예정재고투입',
    '투입예정재고감소',
    TO_CHAR(SYSDATE,'YYYY-MM-DD HH24:MI:SS'),
    V_WORK_ORDER.ITEM_CODE,
    V_WORK_ORDER.ITEM_NAME,
    V_WORK_ORDER.REQUIRED_AMOUNT,
    '작업지시');
-- 작업지시품목 / 원재료 구분 IF문 끝

END IF;

-- 커서 LOOP문 끝
END LOOP;


-- 성공시 커밋
COMMIT;

ERROR_CODE := '0';
ERROR_MSG := '성공?!!!@?!?!';

-- 예외 발생시
EXCEPTION

WHEN NO_DATA_FOUND THEN
       DBMS_OUTPUT.PUT_LINE('NO_DATA_FOUND');
       ERROR_CODE := '-1';
       ERROR_MSG := 'NO_DATA_FOUND';
       RETURN;

WHEN DUP_VAL_ON_INDEX THEN
       DBMS_OUTPUT.PUT_LINE('DUP_VAL_ON_INDEX');
       ERROR_CODE := '-1';
       ERROR_MSG := 'DUP_VAL_ON_INDEX';
       RETURN;

WHEN OTHERS THEN
       DBMS_OUTPUT.PUT_LINE('OTHERS');
       ERROR_CODE := '-1';
       ERROR_MSG := '관리자에게 문의 하세요 // 01077239513';
       RETURN;

-- PROCEDURE 끝
END;
/

