create FUNCTION         "TIME_PLUS_FUNC" /* 시간 더하기 함수 */
(       
        FIRST_HOUR      IN VARCHAR2,                    -- 시간 더하기 함수는 들어 있는 시간을 합할때 사용한다.
        SECOND_HOUR     IN VARCHAR2                     -- ex) 사외출 2시간 + 공외출 1시간 = 3시간을 구할 때 사
        
)
RETURN VARCHAR2 
IS 
RESULT_HOUR VARCHAR2(100);

BEGIN              
    SELECT  LPAD(TRUNC((to_date(LPAD(FIRST_HOUR,4,'0'),'hh24mi')-to_date('0000','hh24mi'))*24+(to_date(LPAD(SECOND_HOUR,4,'0'),'hh24mi')-to_date('0000','hh24mi'))*24),2,'0') ||
            LPAD(ROUND(MOD((to_date(LPAD(FIRST_HOUR,4,'0'),'hh24mi')-to_date('0000','hh24mi'))*24+(to_date(LPAD(SECOND_HOUR,4,'0'),'hh24mi')-to_date('0000','hh24mi'))*24,1)*60,0),2,'0')
    INTO RESULT_HOUR
    FROM DUAL;
    
    RETURN RESULT_HOUR;
END TIME_PLUS_FUNC;

/* 코드설명 
            LPAD(TRUNC((to_date(LPAD(FIRST_HOUR,4,'0'),'hh24mi')-to_date('0000','hh24mi'))*24+(to_date(LPAD(SECOND_HOUR,4,'0'),'hh24mi')-to_date('0000','hh24mi'))*24),2,'0') ||
            FIRST_HOUR를 4자리수로 바꿔주기 위해 LPAD사용(0이면 0000으로 바꿔줌 // 50분만 들어있으면 0050으로 바꿔줌) 
            그 값을 TO_DATE방식으로 바꾸면 2020년 1월1일 00시50분이 됨
            LPAD(ROUND(MOD((to_date(LPAD(FIRST_HOUR,4,'0'),'hh24mi')-to_date('0000','hh24mi'))*24+(to_date(LPAD(SECOND_HOUR,4,'0'),'hh24mi')-to_date('0000','hh24mi'))*24,1)*60,0),2,'0')

*/
/

