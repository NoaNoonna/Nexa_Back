create FUNCTION         "LEAVE_HOUR_CAL_FUNC" 
(       
        OUT_TIME IN VARCHAR2,
        IN_TIME  IN VARCHAR2       
)
RETURN VARCHAR2 
IS 
LEAVE_HOUR VARCHAR2(100);
V_OUT_TIME  VARCHAR2(100);
V_IN_TIME  VARCHAR2(100);



BEGIN
    V_OUT_TIME := OUT_TIME;
    V_IN_TIME := IN_TIME;
    
    IF V_OUT_TIME >= 1300 AND V_OUT_TIME <=1400 THEN
        V_OUT_TIME := 1400;
    END IF;
    
    IF V_IN_TIME >= 1300 AND V_IN_TIME <1400 THEN
       V_IN_TIME := 1300;
    END IF;
    
    IF OUT_TIME <= 1300 AND IN_TIME>=1400 THEN
        select LPAD(TRUNC((to_date(LPAD(V_IN_TIME,4,'0'),'hh24mi')-to_date(LPAD(V_OUT_TIME,4,'0'),'hh24mi')-1/24)*24),2,'0')||
               LPAD(ROUND(MOD((to_date(LPAD(V_IN_TIME,4,'0'),'hh24mi')-to_date(LPAD(V_OUT_TIME,4,'0'),'hh24mi')-1/24)*24,1)*60),2,'0') 
        INTO LEAVE_HOUR 
        FROM  DUAL;
    ELSE 
        select LPAD(TRUNC((to_date(LPAD(V_IN_TIME,4,'0'),'hh24mi')-to_date(LPAD(V_OUT_TIME,4,'0'),'hh24mi'))*24),2,'0')||
               LPAD(ROUND(MOD((to_date(LPAD(V_IN_TIME,4,'0'),'hh24mi')-to_date(LPAD(V_OUT_TIME,4,'0'),'hh24mi'))*24,1)*60),2,'0') 
        INTO LEAVE_HOUR 
        FROM  DUAL;
    END IF;
    RETURN LEAVE_HOUR;
END LEAVE_HOUR_CAL_FUNC;
/

