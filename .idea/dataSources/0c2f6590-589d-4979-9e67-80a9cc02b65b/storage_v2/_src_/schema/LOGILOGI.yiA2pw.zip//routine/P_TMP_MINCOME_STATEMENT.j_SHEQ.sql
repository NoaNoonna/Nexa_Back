create PROCEDURE          P_TMP_MINCOME_STATEMENT(
SEARCH_YEAR_NO IN VARCHAR2,
P_YEAR IN VARCHAR2
)
 IS
SALES_SUMMARY NUMBER; --매출액(1)
SALES_COST_SUMMARY NUMBER;  --매출원가(2)
GROSS_MARGIN NUMBER;  --매출총이익(3)
SALES_MANAGE_COST_SUMMARY NUMBER;  --판관비(4)
OPERATING_PROFIT NUMBER;  --영업이익(5)
NON_OPERATING_PROFIT_SUMMARY NUMBER;  --영업외수익(6)
NON_OPERATING_COST_SUMMARY NUMBER;  --영외비용(7)
ORDINARY_PROFIT NUMBER;  --법인세차감전 이익(8)
CORPORATE_TAX_SUMMARY NUMBER;  --법인세비용(9)
NET_INCOME NUMBER;  --당기순이익(10)
YEAR_MONTH VARCHAR2(20);
LOOP_NUM NUMBER := 1;
BEGIN
	DELETE FROM TMP_MONTH_INCOME_STATEMENT2;
--YEAR_MONTH := SEARCH_YEAR_NO || '-08';
		LOOP
    SELECT (
   CASE WHEN LOOP_NUM < 10 THEN P_YEAR||'-0' || LOOP_NUM
   ELSE P_YEAR || '-' || LOOP_NUM
    END
   ) INTO YEAR_MONTH
    FROM DUAL;

--손익계산서 설계
--매출총이익(03)=매출액(01)-매출원가(02)
--영업이익(05)=매출총이익(03)-판관비(04)
--법인세차감전 이익(08)=영업이익(05)+영업외수익(06) - 영외비용(07)
--당기순이익(10)=법인세차감전이익(08)-법인세비용(09)

  --실제 사용공식
-- 매출액(1)+ 영업외수익(6) - 매출원가(2) - 판관비(4) - 영업외비용(7) - 법인세비용(9) = 당기순이익(10)
-- [매출 총이익] = 매출액총계(SALES_SUMMARY) - 매출원가총계(SALES_COST_SUMMARY)
-- 1.매출액총계
-- 2.매출원가 = 기초상품재고액  +  당기 상품 순매입액(총매입액 - 에누리 - 매입할인)  -  기말상품재고액(기초상품재고액 + 당기 상품순매입액)
-- 2-1. 기초상품재고액은 회계기간초 기업이 보유하고 있는 상품(즉 전기 재고를 말한다)
-- 2-2. 당기상품은 기업이 회계기간동안(당기) 판매할 목적으로 매입한 상품
-- 2-3. 기초상품재고액+당기상품매입액=판매가능상품액
-- 3.당기 상품 순매입액 = 총매입액 - 에누리 - 매입할인
-- 4.기말상품재고액 = 기초상품재고액 + 당기 상품순매입액

-- [영업 이익] = 매출총이익(GROSS_MARGIN) - 판관비총계(SALES_MANAGE_COST_SUMMARY)
-- [법인세 차감전 이익] = 영업이익(OPERATING_PROFIT) + 영업 외 수익(NON_OPERATING_PROFIT_SUMMARY) - 영업 외 비용 총계(NON_OPERATING_COST_SUMMARY)
-- 1.영업외 수익 총계(NON_OPERATING_PROFIT_SUMMARY)
-- 2.영업외 비용 총계(NON_OPERATING_COST_SUMMARY)
-- 3.법인세 총계(CORPORATE_TAX_SUMMARY)

-- [당기 순이익] =법인세차감전이익(ORDINARY_PROFIT) - 법인세 총계(CORPORATE_TAX_SUMMARY)
    --INSERT INTO TMP_MONTH_INCOME_STATEMENT select SEARCH_MONTH,SEARCH_YEAR_NO, SALES_SUMMARY,SALES_COST_SUMMARY ,GROSS_MARGIN,
		--SALES_MANAGE_COST_SUMMARY, OPERATING_PROFIT, NON_OPERATING_PROFIT_SUMMARY, NON_OPERATING_COST_SUMMARY,
  --  ORDINARY_PROFIT,CORPORATE_TAX_SUMMARY,NET_INCOME FROM (

 --SALES_SUMMARY 변수에 값 대입 (매출액) NVL이 복잡하게 되어있지만 귀찮아서 안고침
SELECT NVL((SUM(NVL(J.RIGHT_CREDITS_PRICE, 0))-SUM(NVL(J.LEFT_DEBTOR_PRICE, 0))),0) INTO SALES_SUMMARY --대변금액(분개) AS  대변(합계)임시시산표테이블  -- 매출총액
               FROM SLIP S, --전표
                    JOURNAL J, -- 분개
                    PERIOD P, -- 기수
                    ACCOUNT A -- 계정과목
               WHERE S.SLIP_NO = J.SLIP_NO --일련번호 전표번호,분개번호조인
                 AND J.ACCOUNT_INNER_CODE = A.ACCOUNT_INNER_CODE --계정,분개 내부계정코드
                 AND S.SLIP_STATUS LIKE '승인완료' --전표상태
                 AND S.REPORTING_DATE LIKE  YEAR_MONTH ||'%'
                   AND J.ACCOUNT_INNER_CODE BETWEEN '0401' AND '0430';      --상위계정내부코드      매출



--SALES_COST_SUMMARY 변수에 값 대입 (매출원가)
--기초상품재고액+ 상품매출원가 + 당기상품순매입액 -기말상품재고액= 매출원가
--인데 기말상품재고액=기초상품재고액+당기상품순매입액 이니까 상품매출원가만 하면 되는거 아님??
SELECT
			NVL(SUM(J.LEFT_DEBTOR_PRICE), 0) -  NVL(SUM(J.RIGHT_CREDITS_PRICE), 0) --상품매출원가
			INTO SALES_COST_SUMMARY
        	FROM SLIP S,
             JOURNAL J,
             ACCOUNT A,
             PERIOD P
        	WHERE S.SLIP_NO = J.SLIP_NO
          AND J.ACCOUNT_INNER_CODE = A.ACCOUNT_INNER_CODE
          AND S.SLIP_STATUS LIKE '승인완료'
         	AND S.REPORTING_DATE LIKE  YEAR_MONTH ||'%'
          AND J.ACCOUNT_INNER_CODE BETWEEN  '0451' AND '0470'; --상품매출원가코드

GROSS_MARGIN := SALES_SUMMARY - SALES_COST_SUMMARY ;

SELECT NVL(SUM( DEBITS_SUM - CREDITS_SUM),0) INTO SALES_MANAGE_COST_SUMMARY
          FROM (
                 SELECT
                        SUM(NVL(J.LEFT_DEBTOR_PRICE,0))   AS DEBITS_SUM,
                        SUM(NVL(J.RIGHT_CREDITS_PRICE,0)) AS CREDITS_SUM
                 FROM SLIP S,
                      JOURNAL J,
                      ACCOUNT A,
                      PERIOD P

                 WHERE S.SLIP_NO = J.SLIP_NO
                   AND J.ACCOUNT_INNER_CODE = A.ACCOUNT_INNER_CODE
                   AND S.SLIP_STATUS LIKE '승인완료'
                   AND S.REPORTING_DATE LIKE YEAR_MONTH ||'%'
                   AND J.ACCOUNT_INNER_CODE BETWEEN '0801' AND '0900');

OPERATING_PROFIT := GROSS_MARGIN - SALES_MANAGE_COST_SUMMARY;

SELECT NVL(SUM(CREDITS_SUM - DEBITS_SUM),0) INTO NON_OPERATING_PROFIT_SUMMARY  -- 영업외수익
          FROM (
                 SELECT
                        SUM(NVL(J.LEFT_DEBTOR_PRICE,0))   AS DEBITS_SUM,
                        SUM(NVL(J.RIGHT_CREDITS_PRICE,0)) AS CREDITS_SUM
                 FROM SLIP S,
                      JOURNAL J,
                      ACCOUNT A,
                      PERIOD P
                 WHERE S.SLIP_NO = J.SLIP_NO
                   AND J.ACCOUNT_INNER_CODE = A.ACCOUNT_INNER_CODE
                   AND S.SLIP_STATUS LIKE '승인완료'
                   AND J.ACCOUNT_INNER_CODE BETWEEN '0901' AND '0950'
                   AND S.REPORTING_DATE LIKE  YEAR_MONTH ||'%'
               );

SELECT NVL(DEBITS_SUM - CREDITS_SUM,0) INTO NON_OPERATING_COST_SUMMARY  --영업외비용
          FROM (
                 SELECT
                        SUM(NVL(J.LEFT_DEBTOR_PRICE,0))   AS DEBITS_SUM,
                        SUM(NVL(J.RIGHT_CREDITS_PRICE,0)) AS CREDITS_SUM
                 FROM SLIP S,
                      JOURNAL J,
                      ACCOUNT A,
                      PERIOD P
                 WHERE S.SLIP_NO = J.SLIP_NO
                   AND J.ACCOUNT_INNER_CODE = A.ACCOUNT_INNER_CODE
                   AND S.SLIP_STATUS LIKE '승인완료'
                   AND J.ACCOUNT_INNER_CODE BETWEEN '0951' AND '0997' --영업외비용
                  AND S.REPORTING_DATE LIKE YEAR_MONTH ||'%'
               );

ORDINARY_PROFIT :=OPERATING_PROFIT+ NON_OPERATING_PROFIT_SUMMARY -NON_OPERATING_COST_SUMMARY ;

SELECT NVL(SUM( CREDITS_SUM - DEBITS_SUM),0) INTO CORPORATE_TAX_SUMMARY  --법인세비용
          FROM (
                 SELECT
                        SUM(NVL(J.LEFT_DEBTOR_PRICE,0))   AS DEBITS_SUM,
                        SUM(NVL(J.RIGHT_CREDITS_PRICE,0)) AS CREDITS_SUM
                 FROM SLIP S,
                      JOURNAL J,
                      ACCOUNT A,
                      PERIOD P
                 WHERE S.SLIP_NO = J.SLIP_NO
                   AND J.ACCOUNT_INNER_CODE = A.ACCOUNT_INNER_CODE
                   AND S.SLIP_STATUS LIKE '승인완료'
                   AND J.ACCOUNT_INNER_CODE BETWEEN '0998' AND '0999'
                   AND S.REPORTING_DATE LIKE  YEAR_MONTH ||'%'
               );

NET_INCOME := ORDINARY_PROFIT - CORPORATE_TAX_SUMMARY;





INSERT INTO TMP_MONTH_INCOME_STATEMENT2
 VALUES(
SEARCH_YEAR_NO,  --year
LOOP_NUM, --month
SALES_SUMMARY,
SALES_COST_SUMMARY,
GROSS_MARGIN,
SALES_MANAGE_COST_SUMMARY,
OPERATING_PROFIT,
NON_OPERATING_PROFIT_SUMMARY,
NON_OPERATING_COST_SUMMARY,
ORDINARY_PROFIT,
CORPORATE_TAX_SUMMARY,
NET_INCOME);



LOOP_NUM := LOOP_NUM + 1;

EXIT WHEN LOOP_NUM >12;
END LOOP;



END P_TMP_MINCOME_STATEMENT;
/

