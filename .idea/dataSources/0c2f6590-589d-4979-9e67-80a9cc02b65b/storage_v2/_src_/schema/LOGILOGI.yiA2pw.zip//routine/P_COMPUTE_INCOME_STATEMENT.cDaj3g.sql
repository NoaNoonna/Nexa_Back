create PROCEDURE          P_COMPUTE_INCOME_STATEMENT (
SEARCH_PERIOD_NO IN NUMBER,
IS_EARLY_PERIOD IN NUMBER)
IS
BEGIN
--손익계산서 설계
--매출총이익(03)=매출액(01)-매출원가(02)
--영업이익(05)=매출총이익(03)-판관비(04)
--법인세차감전 이익(08)=영업이익(05)+영업외수익(06) - 영외비용(07)
--당기순이익(10)=법인세차감전이익(08)-법인세비용(09)

  --실제 사용공식
-- 매출액+ 영업외수익 - 매출원가 - 판관비 - 영업외비용 - 법인세비용 = 당기순이익
-- [매출 총이익] = 매출액총계(SALES_SUMMARY) - 매출원가총계(SALES_COST_SUMMARY)
-- 1.매출액총계
-- 2.매출원가 = 기초상품재고액  +  당기 상품 순매입액(총매입액 - 에누리 - 매입할인)  -  기말상품재고액(기초상품재고액 + 당기 상품순매입액)
-- 2-1. 기초상품재고액은 회계기간초 기업이 보유하고 있는 상품(즉 전기 재고를 말한다)
-- 2-2. 당기상품은 기업이 회계기간동안(당기) 판매할 목적으로 매입한 상품
-- 2-3. 기초상품재고액+당기상품매입액=판매가능상품액
-- 3.당기 상품 순매입액 = 총매입액 - 에누리 - 매입할인
-- 4.기말상품재고액 = 기초상품재고액 + 당기 상품순매입액

-- [영업 이익] = 매출총이익(GROSS_MARGIN) - 판관비총계(SALES_MANAGE_COST_SUMMARY)
-- [법인세 차감전 이익] = 영업이익(OPERATING_PROFIT) + 영업 외 수익(NON_OPERATING_PROFIT_SUMMARY) - 영업 외 비용 총계(NON_OPERATING_COST_SUMMARY)
-- 1.영업외 수익 총계(NON_OPERATING_PROFIT_SUMMARY)
-- 2.영업외 비용 총계(NON_OPERATING_COST_SUMMARY)
-- 3.법인세 총계(CORPORATE_TAX_SUMMARY)

-- [당기 순이익] =법인세차감전이익(ORDINARY_PROFIT) - 법인세 총계(CORPORATE_TAX_SUMMARY)


  IF IS_EARLY_PERIOD <> 0 THEN /*당기*/
    INSERT INTO TMP_INCOME_STATEMENT(ACCOUNT_INNER_CODE, ACCOUNT_NAME, PARENT_ACCOUNT_CODE, INCOME, INCOME_SUMMARY,
                                     PERIOD_NO) -- ACCOUNT 계정,PARENT_ACCOUNT_CODE 임시테이블손익계산서

    WITH
      -- 매출액 상세내용
      SALES_DETAIL AS (
               SELECT J.ACCOUNT_INNER_CODE AS ACCOUNT_INNER_CODE, --계정내부코드(계정과목)
                          A.ACCOUNT_NAME AS ACCOUNT_NAME,       --계정명(계정과목)
                          '01' AS PARENT_ACCOUNT_CODE,
                          (SUM(NVL(J.RIGHT_CREDITS_PRICE, 0))-SUM(NVL(J.LEFT_DEBTOR_PRICE, 0))) AS  INCOME,  --대변금액(분개) AS  대변(합계)임시시산표테이블
                          NULL AS INCOME_SUMMARY
               FROM SLIP S, --전표
                    JOURNAL J, -- 분개
                    PERIOD P, -- 기수
                    ACCOUNT A -- 계정과목
               WHERE S.SLIP_NO = J.SLIP_NO --일련번호 전표번호,분개번호조인
                 AND J.ACCOUNT_INNER_CODE = A.ACCOUNT_INNER_CODE --계정,분개 내부계정코드
                 AND S.SLIP_STATUS LIKE '승인' --전표상태
                 AND S.ACCOUNT_PERIOD_NO = SEARCH_PERIOD_NO --회계기수일련번호
                   AND PARENT_ACCOUNT_INNER_CODE='0401-0430'      --상위계정내부코드      매출
               GROUP BY J.ACCOUNT_INNER_CODE, A.ACCOUNT_NAME
      ),
      -- 매출액 총계
      SALES_SUMMARY AS (SELECT '01'          AS ACCOUNT_INNER_CODE,
                               UNISTR('매출액') AS ACCOUNT_NAME,
                               NULL          AS PARENT_ACCOUNT_CODE,
                               NULL          AS INCOME,
                               SUM(INCOME)   AS INCOME_SUMMARY
                        FROM SALES_DETAIL), --매출액 상세내용에서 INCOME SUM해줌

      -- 기초상품재고액
      PREYEAR_FINAL_STOCK AS
        (SELECT E.PRICE AS INCOME_SUMMARY
         FROM EARLY_CLOSING E,
              PERIOD P
         WHERE E.ACCOUNT_PERIOD_NO = P.ACCOUNT_PERIOD_NO
           AND E.CODE = '1001'      -- 자산
           AND P.ACCOUNT_PERIOD_NO = SEARCH_PERIOD_NO - 1),

      --   총매입액

      CURRENT_PRODUCT_PURCHASES AS
        (SELECT  SUM(NVL(J.LEFT_DEBTOR_PRICE, 0)) - SUM(NVL(J.RIGHT_CREDITS_PRICE, 0)) AS INCOME_SUMMARY
         FROM SLIP S,
              JOURNAL J,
              PERIOD P,
              ACCOUNT A
         WHERE S.SLIP_NO = J.SLIP_NO
           AND J.ACCOUNT_INNER_CODE = A.ACCOUNT_INNER_CODE
                  -- N:1
           AND S.SLIP_STATUS LIKE '승인'
           AND S.ACCOUNT_PERIOD_NO = P.ACCOUNT_PERIOD_NO
           AND P.ACCOUNT_PERIOD_NO = SEARCH_PERIOD_NO
           AND J.ACCOUNT_INNER_CODE = '0146' --상품 = 코드번호    유동자산
         GROUP BY J.ACCOUNT_INNER_CODE, A.ACCOUNT_NAME),

      --   당기 에누리 차감 계정
      CURRENT_PURCHASES_RETURNS AS
        (SELECT SUM(NVL(J.RIGHT_CREDITS_PRICE, 0)) - SUM(NVL(J.LEFT_DEBTOR_PRICE, 0)) AS INCOME_SUMMARY
         FROM SLIP S,
              JOURNAL J,
              PERIOD P,
              ACCOUNT A
         WHERE S.SLIP_NO = J.SLIP_NO
           AND J.ACCOUNT_INNER_CODE = A.ACCOUNT_INNER_CODE
           AND S.SLIP_STATUS LIKE '승인'
           AND S.ACCOUNT_PERIOD_NO = P.ACCOUNT_PERIOD_NO
           AND P.ACCOUNT_PERIOD_NO = SEARCH_PERIOD_NO
           AND J.ACCOUNT_INNER_CODE = '0147'  -- 유동자산
         GROUP BY J.ACCOUNT_INNER_CODE, A.ACCOUNT_NAME),

      --   당기 매입할인 차감 계정
      CURRENT_PURCHASES_DISCOUNT AS
        (SELECT SUM(NVL(J.RIGHT_CREDITS_PRICE, 0)) - SUM(NVL(J.LEFT_DEBTOR_PRICE, 0)) AS INCOME_SUMMARY
         FROM SLIP S,
              JOURNAL J,
              PERIOD P,
              ACCOUNT A
         WHERE S.SLIP_NO = J.SLIP_NO
           AND J.ACCOUNT_INNER_CODE = A.ACCOUNT_INNER_CODE
           AND S.SLIP_STATUS LIKE '승인'
           AND S.ACCOUNT_PERIOD_NO = P.ACCOUNT_PERIOD_NO
           AND P.ACCOUNT_PERIOD_NO = SEARCH_PERIOD_NO
           AND J.ACCOUNT_INNER_CODE = '0148'  --유동자산
         GROUP BY J.ACCOUNT_INNER_CODE, A.ACCOUNT_NAME),

      -- 상품매출원가 계정과목
      ACCOUNT_SALES_COST AS (
        SELECT J.ACCOUNT_INNER_CODE,
               A.ACCOUNT_NAME,
               NVL(SUM(J.LEFT_DEBTOR_PRICE), 0) -  NVL(SUM(J.RIGHT_CREDITS_PRICE), 0)AS INCOME_SUMMARY
        FROM SLIP S,
             JOURNAL J,
             ACCOUNT A,
             PERIOD P
        WHERE S.SLIP_NO = J.SLIP_NO
          AND J.ACCOUNT_INNER_CODE = A.ACCOUNT_INNER_CODE
          AND S.SLIP_STATUS LIKE '승인'
          AND P.ACCOUNT_PERIOD_NO = SEARCH_PERIOD_NO
          AND S.ACCOUNT_PERIOD_NO = P.ACCOUNT_PERIOD_NO
          AND J.ACCOUNT_INNER_CODE = '0451' --상품매출원가코드
        GROUP BY J.ACCOUNT_INNER_CODE, A.ACCOUNT_NAME
      ),

      -- 당기 상품 순매입액 = 총매입액 - 에누리 - 매입할인
      PURCHASE_RESULT AS (
        SELECT ABS(SUM(INCOME_SUMMARY)) AS INCOME_SUMMARY
        FROM (SELECT INCOME_SUMMARY
              FROM CURRENT_PRODUCT_PURCHASES --총매입액
              UNION ALL
              SELECT INCOME_SUMMARY * -1
              FROM CURRENT_PURCHASES_RETURNS --당기 에누리
              UNION ALL
              SELECT INCOME_SUMMARY * -1  --당기 매입할인
              FROM CURRENT_PURCHASES_DISCOUNT)
      ),

      --당기 기말상품재고액
      CURRENT_FINAL_STOCK AS
        (SELECT SUM(PRICE) AS PRICE
         FROM (SELECT INCOME_SUMMARY AS PRICE
               FROM PREYEAR_FINAL_STOCK -- 기초상품재고액
               UNION ALL
               SELECT INCOME_SUMMARY AS PRICE
               FROM PURCHASE_RESULT --당기 상품 순매입액
              )
        ),

      -- 매출원가 상세내용
      SALES_COST_DETAIL AS (
        SELECT ACCOUNT_INNER_CODE,
               ACCOUNT_NAME,
               '02'           AS PARENT_ACCOUNT_CODE,
               INCOME_SUMMARY AS INCOME,
               NULL           AS INCOME_SUMMARY
        FROM ACCOUNT_SALES_COST --상품매출원가 계정과목

        UNION ALL

        SELECT '021'                  AS ACCOUNT_INNER_CODE,
               UNISTR('기초상품재고액') AS ACCOUNT_NAME,
               '02'                   AS PARENT_ACCOUNT_CODE,
               INCOME_SUMMARY         AS INCOME,
               NULL                   AS INCOME_SUMMARY
        FROM PREYEAR_FINAL_STOCK
        UNION ALL
        SELECT '022'                    AS ACCOUNT_INNER_CODE,
               UNISTR('당기상품순매입액') AS ACCOUNT_NAME,
               '02'                     AS PARENT_ACCOUNT_CODE,
               INCOME_SUMMARY AS INCOME,
               NULL                     AS INCOME_SUMMARY
        FROM PURCHASE_RESULT
        UNION ALL
        SELECT '023'                  AS ACCOUNT_INNER_CODE,
               UNISTR('기말상품재고액') AS ACCOUNT_NAME,
               '02'                   AS PARENT_ACCOUNT_CODE,
               PRICE  *-1             AS INCOME,
               NULL                   AS INCOME_SUMMARY
        FROM CURRENT_FINAL_STOCK
      )
        ,





      -- 매출원가 총계
      SALES_COST_SUMMARY
        AS
        (
          SELECT '02'                AS ACCOUNT_INNER_CODE,
                 UNISTR('매출원가')   AS ACCOUNT_NAME,
                 NULL                AS PARENT_ACCOUNT_CODE,
                 NULL                AS INCOME,
                 NVL(SUM(INCOME), 0) AS INCOME_SUMMARY
          FROM SALES_COST_DETAIL
        )
        ,

      -- 매출 총이익 = 매출액총계(SALES_SUMMARY) - 매출원가총계(SALES_COST_SUMMARY)
      GROSS_MARGIN
        AS
        (
          SELECT '03'                                AS ACCOUNT_INNER_CODE,
                 UNISTR('매출총이익')                 AS ACCOUNT_NAME,
                 NULL                                AS PARENT_ACCOUNT_CODE,
                 NULL                                AS INCOME,
                 H.INCOME_SUMMARY - C.INCOME_SUMMARY AS INCOME_SUMMARY
          FROM SALES_SUMMARY H, --매출액총계
               SALES_COST_SUMMARY C --매출원가총계
        )
        ,

      -- 판매 및 관리비 상세내용
      SALES_MANAGE_COST_DETAIL
        AS
        (
          SELECT ACCOUNT_INNER_CODE,
                 ACCOUNT_NAME,
                 '04'                     AS PARENT_ACCOUNT_CODE,
                 DEBITS_SUM - CREDITS_SUM AS INCOME,
                 NULL                     AS INCOME_SUMMARY
          FROM (
                 SELECT J.ACCOUNT_INNER_CODE,
                        A.ACCOUNT_NAME,
                        SUM(J.LEFT_DEBTOR_PRICE)   AS DEBITS_SUM,
                        SUM(J.RIGHT_CREDITS_PRICE) AS CREDITS_SUM
                 FROM SLIP S,
                      JOURNAL J,
                      ACCOUNT A,
                      PERIOD P

                 WHERE S.SLIP_NO = J.SLIP_NO
                   AND J.ACCOUNT_INNER_CODE = A.ACCOUNT_INNER_CODE
                   AND S.SLIP_STATUS LIKE '승인'
                   AND S.ACCOUNT_PERIOD_NO = P.ACCOUNT_PERIOD_NO
                   AND P.ACCOUNT_PERIOD_NO = SEARCH_PERIOD_NO
                   AND J.ACCOUNT_INNER_CODE BETWEEN '0801' AND '0900'
                 GROUP BY J.ACCOUNT_INNER_CODE, A.ACCOUNT_NAME
               )
        )
        ,

      -- 판매 및 관리비 총계
      SALES_MANAGE_COST_SUMMARY
        AS
        (
          SELECT '04'                   AS ACCOUNT_INNER_CODE,
                 UNISTR('판매 및 관리비') AS ACCOUNT_NAME,
                 NULL                   AS PARENT_ACCOUNT_CODE,
                 NULL                   AS INCOME,
                 NVL(SUM(INCOME), 0)    AS INCOME_SUMMARY
          FROM SALES_MANAGE_COST_DETAIL
        )
        ,

      -- 영업 이익 = 매출총이익(GROSS_MARGIN) - 판관비총계(SALES_MANAGE_COST_SUMMARY)
      OPERATING_PROFIT
        AS
        (
          SELECT '05'                                 AS ACCOUNT_INNER_CODE,
                 UNISTR('영업이익')                    AS ACCOUNT_NAME,
                 NULL                                 AS PARENT_ACCOUNT_CODE,
                 NULL                                 AS INCOME,
                 G.INCOME_SUMMARY - S.INCOME_SUMMARY AS INCOME_SUMMARY
          FROM GROSS_MARGIN G,             --매출총이익
               SALES_MANAGE_COST_SUMMARY S --판관비총계
        )
        ,


      -- 영업외 수익 상세내용
      NON_OPERATING_PROFIT_DETAIL
        AS
        (
          SELECT ACCOUNT_INNER_CODE,
                 ACCOUNT_NAME,
                 '06'                     AS PARENT_ACCOUNT_CODE,
                 CREDITS_SUM - DEBITS_SUM AS INCOME,
                 NULL                     AS INCOME_SUMMARY
          FROM (
                 SELECT J.ACCOUNT_INNER_CODE,
                        A.ACCOUNT_NAME,
                        SUM(J.LEFT_DEBTOR_PRICE)   AS DEBITS_SUM,
                        SUM(J.RIGHT_CREDITS_PRICE) AS CREDITS_SUM
                 FROM SLIP S,
                      JOURNAL J,
                      ACCOUNT A,
                      PERIOD P
                 WHERE S.SLIP_NO = J.SLIP_NO
                   AND J.ACCOUNT_INNER_CODE = A.ACCOUNT_INNER_CODE
                   AND S.SLIP_STATUS LIKE '승인'
                   AND J.ACCOUNT_INNER_CODE BETWEEN '0901' AND '0950'
                   AND S.ACCOUNT_PERIOD_NO = P.ACCOUNT_PERIOD_NO
                   AND P.ACCOUNT_PERIOD_NO = SEARCH_PERIOD_NO
                 GROUP BY J.ACCOUNT_INNER_CODE, A.ACCOUNT_NAME
               )
        )
        ,

      -- 영업외 수익 총계
      NON_OPERATING_PROFIT_SUMMARY
        AS
        (
          SELECT '06'                AS ACCOUNT_INNER_CODE,
                 UNISTR('영업외 수익')AS ACCOUNT_NAME,
                 NULL                AS PARENT_ACCOUNT_CODE,
                 NULL                AS INCOME,
                 NVL(SUM(INCOME), 0) AS INCOME_SUMMARY
          FROM NON_OPERATING_PROFIT_DETAIL
        )
        ,


      -- 영업외 비용 상세내용
      NON_OPERATING_COST_DETAIL
        AS
        (
          SELECT ACCOUNT_INNER_CODE,
                 ACCOUNT_NAME,
                 '07'                     AS PARENT_ACCOUNT_CODE,
                 DEBITS_SUM - CREDITS_SUM AS INCOME,
                 NULL                     AS INCOME_SUMMARY
          FROM (
                 SELECT J.ACCOUNT_INNER_CODE,
                        A.ACCOUNT_NAME,
                        SUM(J.LEFT_DEBTOR_PRICE)   AS DEBITS_SUM,
                        SUM(J.RIGHT_CREDITS_PRICE) AS CREDITS_SUM
                 FROM SLIP S,
                      JOURNAL J,
                      ACCOUNT A,
                      PERIOD P
                 WHERE S.SLIP_NO = J.SLIP_NO
                   AND J.ACCOUNT_INNER_CODE = A.ACCOUNT_INNER_CODE
                   AND S.SLIP_STATUS LIKE '승인'
                   AND J.ACCOUNT_INNER_CODE BETWEEN '0951' AND '0997' --영업외비용
                   AND S.ACCOUNT_PERIOD_NO = P.ACCOUNT_PERIOD_NO
                   AND P.ACCOUNT_PERIOD_NO = SEARCH_PERIOD_NO
                 GROUP BY J.ACCOUNT_INNER_CODE, A.ACCOUNT_NAME
               )
        )
        ,

      -- 영업외 비용 총계
      NON_OPERATING_COST_SUMMARY
        AS
        (
          SELECT '07'                AS ACCOUNT_INNER_CODE,
                 UNISTR('영업외 비용') AS ACCOUNT_NAME,
                 NULL                AS PARENT_ACCOUNT_CODE,
                 NULL                AS INCOME,
                 NVL(SUM(INCOME), 0) AS INCOME_SUMMARY
          FROM NON_OPERATING_COST_DETAIL
        )
        ,

      -- 법인세 차감전 이익 = 영업이익(OPERATING_PROFIT) + 영업 외 수익(NON_OPERATING_PROFIT_SUMMARY) - 영업 외 비용 총계(NON_OPERATING_COST_SUMMARY)
      ORDINARY_PROFIT
        AS
        (
          SELECT '08'                                                   AS ACCOUNT_INNER_CODE,
                 UNISTR('법인세 차감전 이익')                             AS ACCOUNT_NAME,
                 NULL                                                   AS PARENT_ACCOUNT_CODE,
                 NULL                                                   AS INCOME,
                 O.INCOME_SUMMARY + P.INCOME_SUMMARY - C.INCOME_SUMMARY AS INCOME_SUMMARY
          FROM OPERATING_PROFIT O,
               NON_OPERATING_PROFIT_SUMMARY P,
               NON_OPERATING_COST_SUMMARY C
        )
        ,


      -- 법인세 상세내용
      CORPORATE_TAX_DETAIL
        AS
        (
          SELECT ACCOUNT_INNER_CODE,
                 ACCOUNT_NAME,
                 '09'                     AS PARENT_ACCOUNT_CODE,
                 CREDITS_SUM - DEBITS_SUM AS INCOME,
                 NULL                     AS INCOME_SUMMARY
          FROM (
                 SELECT J.ACCOUNT_INNER_CODE,
                        A.ACCOUNT_NAME,
                        SUM(J.LEFT_DEBTOR_PRICE)   AS DEBITS_SUM,
                        SUM(J.RIGHT_CREDITS_PRICE) AS CREDITS_SUM
                 FROM SLIP S,
                      JOURNAL J,
                      ACCOUNT A,
                      PERIOD P
                 WHERE S.SLIP_NO = J.SLIP_NO
                   AND J.ACCOUNT_INNER_CODE = A.ACCOUNT_INNER_CODE
                   AND S.SLIP_STATUS LIKE '승인'
                   AND J.ACCOUNT_INNER_CODE BETWEEN '0998' AND '0999'
                   AND S.ACCOUNT_PERIOD_NO = P.ACCOUNT_PERIOD_NO
                   AND P.ACCOUNT_PERIOD_NO = SEARCH_PERIOD_NO
                 GROUP BY J.ACCOUNT_INNER_CODE, A.ACCOUNT_NAME
               )
        )
        ,

      -- 법인세 총계
      CORPORATE_TAX_SUMMARY
        AS
        (
          SELECT '09'                AS ACCOUNT_INNER_CODE,
                 UNISTR('법인세')     AS ACCOUNT_NAME,
                 NULL                AS PARENT_ACCOUNT_CODE,
                 NULL                AS INCOME,
                 NVL(SUM(INCOME), 0) AS INCOME_SUMMARY
          FROM CORPORATE_TAX_DETAIL
        )
        ,

      -- 당기 순이익 =법인세차감전이익(ORDINARY_PROFIT) - 법인세 총계(CORPORATE_TAX_SUMMARY)
      NET_INCOME
        AS
        (
          SELECT '10'                                AS ACCOUNT_INNER_CODE,
                 UNISTR('당기 순이익')                AS ACCOUNT_NAME,
                 NULL                                AS PARENT_ACCOUNT_CODE,
                 NULL                                AS INCOME,
                 O.INCOME_SUMMARY - C.INCOME_SUMMARY AS INCOME_SUMMARY
          FROM ORDINARY_PROFIT O,
               CORPORATE_TAX_SUMMARY C
        )
    SELECT A.*, SEARCH_PERIOD_NO
    FROM (
           SELECT *
           FROM SALES_SUMMARY --                                        1 매출액 총계
           UNION ALL
           SELECT *
           FROM SALES_DETAIL  --                                              매출액 상세내용
           UNION ALL
           SELECT *
           FROM SALES_COST_SUMMARY --                            2 매출원가 총액
           UNION ALL
           SELECT *
           FROM SALES_COST_DETAIL --                                  매출원가 상세 내용
           UNION ALL
           SELECT *
           FROM GROSS_MARGIN             --                            3 매출 총이익
           UNION ALL
           SELECT *
           FROM SALES_MANAGE_COST_SUMMARY --         4 판관비 총액
           UNION ALL
           SELECT *
           FROM SALES_MANAGE_COST_DETAIL --                판관비 상세
           UNION ALL
           SELECT *
           FROM OPERATING_PROFIT --                                     5 영업이익
           UNION ALL
           SELECT *
           FROM NON_OPERATING_PROFIT_SUMMARY --    6 영업외 수익 총액
           UNION ALL
           SELECT *
           FROM NON_OPERATING_PROFIT_DETAIL --       영업외 수익 상세
           UNION ALL
           SELECT *
           FROM NON_OPERATING_COST_SUMMARY --       7 영업외 비용 총액
           UNION ALL
           SELECT *
           FROM NON_OPERATING_COST_DETAIL  --          영업외 비용 상세
           UNION ALL
           SELECT *
           FROM ORDINARY_PROFIT --                                        8 법인세 차감전 이익
           UNION ALL
           SELECT *
           FROM CORPORATE_TAX_SUMMARY --                   9 법인세 총액
           UNION ALL
           SELECT *
           FROM CORPORATE_TAX_DETAIL --                            법인세 상세
           UNION ALL
           SELECT *
           FROM NET_INCOME --                                                    당기 순이익
         ) A;


  ELSE
    --전기
    INSERT INTO TMP_INCOME_STATEMENT(ACCOUNT_INNER_CODE, ACCOUNT_NAME, PARENT_ACCOUNT_CODE, INCOME, INCOME_SUMMARY,
                                     PERIOD_NO)
    WITH
      -- 전기 매출액 상세내용
      E_SALES_DETAIL AS (
        SELECT ACCOUNT_INNER_CODE,
               ACCOUNT_NAME,
               '01'                     AS PARENT_ACCOUNT_CODE,
               CREDITS_SUM - DEBITS_SUM AS INCOME,
               NULL                     AS INCOME_SUMMARY
        FROM (
               SELECT E.ACCOUNT_INNER_CODE,
                      A.ACCOUNT_NAME,
                      NVL(SUM(E.LEFT_DEBTOR_PRICE), 0)   AS DEBITS_SUM,
                      NVL(SUM(E.RIGHT_CREDITS_PRICE), 0) AS CREDITS_SUM
               FROM EARLY_STATEMENTS E,
                    ACCOUNT A,
                    PERIOD P
               WHERE E.ACCOUNT_INNER_CODE = A.ACCOUNT_INNER_CODE
                 AND P.ACCOUNT_PERIOD_NO = SEARCH_PERIOD_NO - 1
                 AND E.ACCOUNT_PERIOD_NO = P.ACCOUNT_PERIOD_NO
                 AND E.ACCOUNT_INNER_CODE BETWEEN '0401' AND '0450' --매출
                 AND E.ACCOUNT_INNER_CODE NOT LIKE '%-%'
               GROUP BY E.ACCOUNT_INNER_CODE, A.ACCOUNT_NAME)
      ),


      -- 매출액 총계
      E_SALES_SUMMARY AS (SELECT '01'          AS ACCOUNT_INNER_CODE,
                                 UNISTR('매출액') AS ACCOUNT_NAME,
                                 NULL          AS PARENT_ACCOUNT_CODE,
                                 NULL          AS INCOME,
                                 SUM(INCOME)   AS INCOME_SUMMARY
                          FROM E_SALES_DETAIL),



      -- 기초상품재고액
      E_PREYEAR_FINAL_STOCK AS
        (SELECT nvl(E.PRICE,0) AS PRICE
         FROM EARLY_CLOSING E,
              PERIOD P
         WHERE E.ACCOUNT_PERIOD_NO = P.ACCOUNT_PERIOD_NO
           AND E.CODE = '1001'
           AND P.ACCOUNT_PERIOD_NO = (SEARCH_PERIOD_NO - 1)),



      -- 기말상품재고액
      E_CURRENT_FINAL_STOCK AS
        (SELECT E.PRICE
         FROM EARLY_CLOSING E,
              PERIOD P
         WHERE E.ACCOUNT_PERIOD_NO = P.ACCOUNT_PERIOD_NO
           AND E.CODE = '1001'
           AND P.ACCOUNT_PERIOD_NO = SEARCH_PERIOD_NO - 1),

      --   총매입액
      E_CURRENT_PRODUCT_PURCHASES AS
        (SELECT  NVL(SUM(E.LEFT_DEBTOR_PRICE), 0) - NVL(SUM(E.RIGHT_CREDITS_PRICE), 0)  AS INCOME_SUMMARY
         FROM EARLY_STATEMENTS E,
              ACCOUNT A,
              PERIOD P
         WHERE E.ACCOUNT_INNER_CODE = A.ACCOUNT_INNER_CODE
           AND P.ACCOUNT_PERIOD_NO = SEARCH_PERIOD_NO - 1
           AND E.ACCOUNT_PERIOD_NO = P.ACCOUNT_PERIOD_NO
           AND E.ACCOUNT_INNER_CODE = '0146'
         GROUP BY E.ACCOUNT_INNER_CODE, A.ACCOUNT_NAME),

      -- 전기 에누리
      E_CURRENT_PURCHASES_RETURNS AS
        (SELECT NVL(SUM(E.RIGHT_CREDITS_PRICE), 0) - NVL(SUM(E.LEFT_DEBTOR_PRICE), 0) AS INCOME_SUMMARY
         FROM EARLY_STATEMENTS E,
              ACCOUNT A,
              PERIOD P
         WHERE E.ACCOUNT_INNER_CODE = A.ACCOUNT_INNER_CODE
           AND P.ACCOUNT_PERIOD_NO = SEARCH_PERIOD_NO - 1
           AND E.ACCOUNT_PERIOD_NO = P.ACCOUNT_PERIOD_NO
           AND E.ACCOUNT_INNER_CODE = '0147'
         GROUP BY E.ACCOUNT_INNER_CODE, A.ACCOUNT_NAME),
      -- 전기 매입할인
      E_CURRENT_PURCHASES_DISCOUNT AS
        (SELECT NVL(SUM(E.RIGHT_CREDITS_PRICE), 0) - NVL(SUM(E.LEFT_DEBTOR_PRICE), 0) AS INCOME_SUMMARY
         FROM EARLY_STATEMENTS E,
              ACCOUNT A,
              PERIOD P
         WHERE E.ACCOUNT_INNER_CODE = A.ACCOUNT_INNER_CODE
           AND P.ACCOUNT_PERIOD_NO = SEARCH_PERIOD_NO - 1
           AND E.ACCOUNT_PERIOD_NO = P.ACCOUNT_PERIOD_NO
           AND E.ACCOUNT_INNER_CODE = '0148'
         GROUP BY E.ACCOUNT_INNER_CODE, A.ACCOUNT_NAME),
      -- 상품매출원가 계정과목
      E_ACCOUNT_SALES_COST AS (
        SELECT E.ACCOUNT_INNER_CODE,
               A.ACCOUNT_NAME,
               NVL(SUM(E.LEFT_DEBTOR_PRICE), 0) - NVL(SUM(E.RIGHT_CREDITS_PRICE), 0)  AS INCOME_SUMMARY
        FROM EARLY_STATEMENTS E,
             ACCOUNT A,
             PERIOD P
        WHERE E.ACCOUNT_INNER_CODE = A.ACCOUNT_INNER_CODE
          AND P.ACCOUNT_PERIOD_NO = SEARCH_PERIOD_NO - 1
          AND E.ACCOUNT_PERIOD_NO = P.ACCOUNT_PERIOD_NO
          AND E.ACCOUNT_INNER_CODE = '0451'
        GROUP BY E.ACCOUNT_INNER_CODE, A.ACCOUNT_NAME
      ),

      -- 매출원가 상세내용
      E_SALES_COST_DETAIL AS (
        SELECT ACCOUNT_INNER_CODE,
               ACCOUNT_NAME,
               '02'           AS PARENT_ACCOUNT_CODE,
               INCOME_SUMMARY AS INCOME,
               NULL           AS INCOME_SUMMARY
        FROM E_ACCOUNT_SALES_COST   -- 상품매출원가
        UNION ALL
        SELECT '021'             AS ACCOUNT_INNER_CODE,
               UNISTR('기초상품재고액') AS ACCOUNT_NAME,
               '02'              AS PARENT_ACCOUNT_CODE,
               PRICE             AS INCOME,
               NULL              AS INCOME_SUMMARY
        FROM E_PREYEAR_FINAL_STOCK  -- 기초상품재고액
        UNION ALL
        SELECT '022'                    AS ACCOUNT_INNER_CODE,
               UNISTR('당기상품순매입액')        AS ACCOUNT_NAME,
               '02'                     AS PARENT_ACCOUNT_CODE,
               ABS(SUM(INCOME_SUMMARY)) AS INCOME,
               NULL                     AS INCOME_SUMMARY
        FROM (SELECT INCOME_SUMMARY
              FROM E_CURRENT_PRODUCT_PURCHASES  --   총매입액
              UNION ALL
              SELECT INCOME_SUMMARY * -1
              FROM E_CURRENT_PURCHASES_RETURNS -- 에누리
              UNION ALL
              SELECT INCOME_SUMMARY * -1
              FROM E_CURRENT_PURCHASES_DISCOUNT)  -- 매입할인
        UNION ALL
        SELECT '023'             AS ACCOUNT_INNER_CODE,
               UNISTR('기말상품재고액') AS ACCOUNT_NAME,
               '02'              AS PARENT_ACCOUNT_CODE,
               PRICE *-1      AS INCOME,
               NULL              AS INCOME_SUMMARY
        FROM E_CURRENT_FINAL_STOCK -- 기말상품재고액
      ),

      -- 매출원가 총계
      E_SALES_COST_SUMMARY AS (SELECT '02'                AS ACCOUNT_INNER_CODE,
                                      UNISTR('매출원가')      AS ACCOUNT_NAME,
                                      NULL                AS PARENT_ACCOUNT_CODE,
                                      NULL                AS INCOME,
                                      NVL(SUM(INCOME), 0) AS INCOME_SUMMARY
                               FROM E_SALES_COST_DETAIL),  -- 매출원가 상세내용

      -- 매출 총이익
      E_GROSS_MARGIN AS (SELECT '03'                                AS ACCOUNT_INNER_CODE,
                                UNISTR('매출총이익')                     AS ACCOUNT_NAME,
                                NULL                                AS PARENT_ACCOUNT_CODE,
                                NULL                                AS INCOME,
                                H.INCOME_SUMMARY - C.INCOME_SUMMARY AS INCOME_SUMMARY
                         FROM E_SALES_SUMMARY H, -- 매출액 총계
                              E_SALES_COST_SUMMARY C), -- 매출원가 총계

      -- 판매 및 관리비 상세내용
      E_SALES_MANAGE_COST_DETAIL AS (
        SELECT ACCOUNT_INNER_CODE,
               ACCOUNT_NAME,
               '04'                     AS PARENT_ACCOUNT_CODE,
                DEBITS_SUM - CREDITS_SUM AS INCOME,
               NULL                     AS INCOME_SUMMARY
        FROM (
               SELECT E.ACCOUNT_INNER_CODE,
                      A.ACCOUNT_NAME,
                      NVL(SUM(E.LEFT_DEBTOR_PRICE), 0)   AS DEBITS_SUM,
                      NVL(SUM(E.RIGHT_CREDITS_PRICE), 0) AS CREDITS_SUM
               FROM EARLY_STATEMENTS E,
                    ACCOUNT A,
                    PERIOD P
               WHERE E.ACCOUNT_INNER_CODE = A.ACCOUNT_INNER_CODE
                 AND P.ACCOUNT_PERIOD_NO = SEARCH_PERIOD_NO - 1
                 AND E.ACCOUNT_PERIOD_NO = P.ACCOUNT_PERIOD_NO
                 AND E.ACCOUNT_INNER_CODE BETWEEN '0801' AND '0900'
                 AND E.ACCOUNT_INNER_CODE NOT LIKE '%-%'
               GROUP BY E.ACCOUNT_INNER_CODE, A.ACCOUNT_NAME)
      ),

      -- 판매 및 관리비 총계
      E_SALES_MANAGE_COST_SUMMARY AS (SELECT '04'                AS ACCOUNT_INNER_CODE,
                                             UNISTR('판매 및 관리비')  AS ACCOUNT_NAME,
                                             NULL                AS PARENT_ACCOUNT_CODE,
                                             NULL                AS INCOME,
                                             NVL(SUM(INCOME), 0) AS INCOME_SUMMARY
                                      FROM E_SALES_MANAGE_COST_DETAIL),

      -- 영업 이익
      E_OPERATING_PROFIT AS (SELECT '05'                                AS ACCOUNT_INNER_CODE,
                                    UNISTR('영업이익')                      AS ACCOUNT_NAME,
                                    NULL                                AS PARENT_ACCOUNT_CODE,
                                    NULL                                AS INCOME,
                                    G.INCOME_SUMMARY - S.INCOME_SUMMARY AS INCOME_SUMMARY
                             FROM E_GROSS_MARGIN G, -- 매출 총이익
                                  E_SALES_MANAGE_COST_SUMMARY S), -- 판매 및 관리비 총계


      -- 영업외 수익 상세내용
      E_NON_OPERATING_PROFIT_DETAIL AS (
        SELECT ACCOUNT_INNER_CODE,
               ACCOUNT_NAME,
               '06'                     AS PARENT_ACCOUNT_CODE,
               CREDITS_SUM - DEBITS_SUM AS INCOME,
               NULL                     AS INCOME_SUMMARY
        FROM (
               SELECT E.ACCOUNT_INNER_CODE,
                      A.ACCOUNT_NAME,
                      NVL(SUM(E.LEFT_DEBTOR_PRICE), 0)   AS DEBITS_SUM,
                      NVL(SUM(E.RIGHT_CREDITS_PRICE), 0) AS CREDITS_SUM
               FROM EARLY_STATEMENTS E,
                    ACCOUNT A,
                    PERIOD P
               WHERE E.ACCOUNT_INNER_CODE = A.ACCOUNT_INNER_CODE
                 AND P.ACCOUNT_PERIOD_NO = SEARCH_PERIOD_NO - 1
                 AND E.ACCOUNT_PERIOD_NO = P.ACCOUNT_PERIOD_NO
                 AND E.ACCOUNT_INNER_CODE BETWEEN '0901' AND '0950'
                 AND E.ACCOUNT_INNER_CODE NOT LIKE '%-%'
               GROUP BY E.ACCOUNT_INNER_CODE, A.ACCOUNT_NAME)
      ),

      -- 영업외 수익 총계
      E_NON_OPERATING_PROFIT_SUMMARY AS (SELECT '06'                AS ACCOUNT_INNER_CODE,
                                                UNISTR('영업외 수익')    AS ACCOUNT_NAME,
                                                NULL                AS PARENT_ACCOUNT_CODE,
                                                NULL                AS INCOME,
                                                NVL(SUM(INCOME), 0) AS INCOME_SUMMARY
                                         FROM E_NON_OPERATING_PROFIT_DETAIL),


      -- 영업외 비용 상세내용
      E_NON_OPERATING_COST_DETAIL AS (
        SELECT ACCOUNT_INNER_CODE,
               ACCOUNT_NAME,
               '07'                     AS PARENT_ACCOUNT_CODE,
               DEBITS_SUM - CREDITS_SUM  AS INCOME,
               NULL                     AS INCOME_SUMMARY
        FROM (SELECT E.ACCOUNT_INNER_CODE,
                     A.ACCOUNT_NAME,
                     NVL(SUM(E.LEFT_DEBTOR_PRICE), 0)   AS DEBITS_SUM,
                     NVL(SUM(E.RIGHT_CREDITS_PRICE), 0) AS CREDITS_SUM
              FROM EARLY_STATEMENTS E,
                   ACCOUNT A,
                   PERIOD P
              WHERE E.ACCOUNT_INNER_CODE = A.ACCOUNT_INNER_CODE
                AND P.ACCOUNT_PERIOD_NO = SEARCH_PERIOD_NO - 1
                AND E.ACCOUNT_PERIOD_NO = P.ACCOUNT_PERIOD_NO
                AND E.ACCOUNT_INNER_CODE BETWEEN '0951' AND '0997'
                AND E.ACCOUNT_INNER_CODE NOT LIKE '%-%'
              GROUP BY E.ACCOUNT_INNER_CODE, A.ACCOUNT_NAME)
      ),

      -- 영업외 비용 총계
      E_NON_OPERATING_COST_SUMMARY AS (SELECT '07'                AS ACCOUNT_INNER_CODE,
                                              UNISTR('영업외 비용')    AS ACCOUNT_NAME,
                                              NULL                AS PARENT_ACCOUNT_CODE,
                                              NULL                AS INCOME,
                                              NVL(SUM(INCOME), 0) AS INCOME_SUMMARY
                                       FROM E_NON_OPERATING_COST_DETAIL),

      -- 법인세 차감전 이익
      E_ORDINARY_PROFIT AS (SELECT '08'                                                   AS ACCOUNT_INNER_CODE,
                                   UNISTR('법인세 차감전 이익')                                   AS ACCOUNT_NAME,
                                   NULL                                                   AS PARENT_ACCOUNT_CODE,
                                   NULL                                                   AS INCOME,
                                   O.INCOME_SUMMARY + P.INCOME_SUMMARY - C.INCOME_SUMMARY AS INCOME_SUMMARY
                            FROM E_OPERATING_PROFIT O, -- 영업 이익
                                 E_NON_OPERATING_PROFIT_SUMMARY P, -- 영업외 수익 총계
                                 E_NON_OPERATING_COST_SUMMARY C), -- 영업외 비용 총계


      -- 법인세 상세내용
      E_CORPORATE_TAX_DETAIL AS (
        SELECT ACCOUNT_INNER_CODE,
               ACCOUNT_NAME,
               '09'                     AS PARENT_ACCOUNT_CODE,
                DEBITS_SUM - CREDITS_SUM AS INCOME,
               NULL                     AS INCOME_SUMMARY
        FROM (
               SELECT E.ACCOUNT_INNER_CODE,
                      A.ACCOUNT_NAME,
                      NVL(SUM(E.LEFT_DEBTOR_PRICE), 0)   AS DEBITS_SUM,
                      NVL(SUM(E.RIGHT_CREDITS_PRICE), 0) AS CREDITS_SUM
               FROM EARLY_STATEMENTS E,
                    ACCOUNT A,
                    PERIOD P
               WHERE E.ACCOUNT_INNER_CODE = A.ACCOUNT_INNER_CODE
                 AND P.ACCOUNT_PERIOD_NO = SEARCH_PERIOD_NO - 1
                 AND E.ACCOUNT_PERIOD_NO = P.ACCOUNT_PERIOD_NO
                 AND E.ACCOUNT_INNER_CODE BETWEEN '0998' AND '0999'
                 AND E.ACCOUNT_INNER_CODE NOT LIKE '%-%'
               GROUP BY E.ACCOUNT_INNER_CODE, A.ACCOUNT_NAME
             )
      ),

      -- 법인세 총계
      E_CORPORATE_TAX_SUMMARY AS (SELECT '09'                AS ACCOUNT_INNER_CODE,
                                         UNISTR('법인세')       AS ACCOUNT_NAME,
                                         NULL                AS PARENT_ACCOUNT_CODE,
                                         NULL                AS INCOME,
                                         NVL(SUM(INCOME), 0) AS INCOME_SUMMARY
                                  FROM E_CORPORATE_TAX_DETAIL),

      -- 당기 순이익
      E_NET_INCOME AS (SELECT '10'                                AS ACCOUNT_INNER_CODE,
                              UNISTR('당기 순이익')                    AS ACCOUNT_NAME,
                              NULL                                AS PARENT_ACCOUNT_CODE,
                              NULL                                AS INCOME,
                              O.INCOME_SUMMARY - C.INCOME_SUMMARY AS INCOME_SUMMARY
                       FROM E_ORDINARY_PROFIT O,-- 법인세 차감전 이익
                            E_CORPORATE_TAX_SUMMARY C) -- 법인세 총계

    SELECT A.*, SEARCH_PERIOD_NO - 1
    FROM (
           SELECT *
           FROM E_SALES_SUMMARY
           UNION ALL
           SELECT *
           FROM E_SALES_DETAIL
           UNION ALL
           SELECT *
           FROM E_SALES_COST_SUMMARY
           UNION ALL
           SELECT *
           FROM E_SALES_COST_DETAIL
           UNION ALL
           SELECT *
           FROM E_GROSS_MARGIN
           UNION ALL
           SELECT *
           FROM E_SALES_MANAGE_COST_SUMMARY
           UNION ALL
           SELECT *
           FROM E_SALES_MANAGE_COST_DETAIL
           UNION ALL
           SELECT *
           FROM E_OPERATING_PROFIT
           UNION ALL
           SELECT *
           FROM E_NON_OPERATING_PROFIT_SUMMARY
           UNION ALL
           SELECT *
           FROM E_NON_OPERATING_PROFIT_DETAIL
           UNION ALL
           SELECT *
           FROM E_NON_OPERATING_COST_SUMMARY
           UNION ALL
           SELECT *
           FROM E_NON_OPERATING_COST_DETAIL
           UNION ALL
           SELECT *
           FROM E_ORDINARY_PROFIT
           UNION ALL
           SELECT *
           FROM E_CORPORATE_TAX_SUMMARY
           UNION ALL
           SELECT *
           FROM E_CORPORATE_TAX_DETAIL
           UNION ALL
           SELECT *
           FROM E_NET_INCOME) A;
  END IF;
END P_COMPUTE_INCOME_STATEMENT;
/

