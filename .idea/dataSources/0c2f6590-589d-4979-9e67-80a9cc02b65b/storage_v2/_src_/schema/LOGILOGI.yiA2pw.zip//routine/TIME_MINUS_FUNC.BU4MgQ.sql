create FUNCTION         "TIME_MINUS_FUNC" /* 시간 빼기 함수 */
(       
        FIRST_HOUR      IN VARCHAR2,                -- 시간 빼기는 기본적으로 뒷시간에서 앞시간을 빼면 나머지 시간을 구할 수 있다.
        SECOND_HOUR     IN VARCHAR2     
)
RETURN VARCHAR2 
IS 
RESULT_HOUR VARCHAR2(100); 

BEGIN
IF FIRST_HOUR>2400
THEN 

SELECT LPAD(TRUNC(((to_date(LPAD(FIRST_HOUR-2400,4,'0'),'hh24mi')+1)-to_date(LPAD(SECOND_HOUR,4,'0'),'hh24mi'))*24),2,'0')||
           LPAD(ROUND(MOD(((to_date(LPAD(FIRST_HOUR-2400,4,'0'),'hh24mi')+1)-to_date(LPAD(SECOND_HOUR,4,'0'),'hh24mi'))*24,1)*60),2,'0') 
 INTO RESULT_HOUR 
    FROM DUAL;
ELSE

    SELECT LPAD(TRUNC((to_date(LPAD(FIRST_HOUR,4,'0'),'hh24mi')-to_date(LPAD(SECOND_HOUR,4,'0'),'hh24mi'))*24),2,'0')||
           LPAD(ROUND(MOD((to_date(LPAD(FIRST_HOUR,4,'0'),'hh24mi')-to_date(LPAD(SECOND_HOUR,4,'0'),'hh24mi'))*24,1)*60),2,'0') 
    INTO RESULT_HOUR 
    FROM DUAL;
    END IF;
    RETURN RESULT_HOUR;
END TIME_MINUS_FUNC;
/

