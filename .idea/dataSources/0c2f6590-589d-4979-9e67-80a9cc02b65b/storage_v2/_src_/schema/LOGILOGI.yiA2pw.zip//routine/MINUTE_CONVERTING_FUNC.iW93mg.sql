create FUNCTION         "MINUTE_CONVERTING_FUNC" 
(   
        NUM_MINUTE IN VARCHAR2
)
        RETURN VARCHAR2  --문자로 받음
IS
        MINUTE VARCHAR2(100);
BEGIN
        MINUTE                  := 0;

		IF SUBSTR(NUM_MINUTE,1,1) = '-' THEN
                MINUTE          := 0;
				RETURN TO_NUMBER(MINUTE);
		END IF;

        IF LENGTH(NUM_MINUTE)    = 5 THEN -- 실제 근무시간이 100시간이 넘을 경우
                MINUTE          := (TO_NUMBER(SUBSTR(TO_CHAR(NUM_MINUTE),1,3))*60) + TO_NUMBER(SUBSTR(TO_CHAR(NUM_MINUTE),4,2));
        ELSIF LENGTH(NUM_MINUTE) = 4 THEN -- 실제 근무시간이 10시간이 넘을 경우
                MINUTE          := (TO_NUMBER(SUBSTR(TO_CHAR(NUM_MINUTE),1,2))*60) + TO_NUMBER(SUBSTR(TO_CHAR(NUM_MINUTE),3,2));
        ELSIF LENGTH(NUM_MINUTE) = 3 THEN -- 실제 근무시간이 1시간이 넘을 경우
                MINUTE          := (TO_NUMBER(SUBSTR(TO_CHAR(NUM_MINUTE),1,1))*60) + TO_NUMBER(SUBSTR(TO_CHAR(NUM_MINUTE),2,2));
		ELSIF LENGTH(NUM_MINUTE) = 2 THEN -- 1시간이 안될경우 경우 (급여계산외에 사용됨)
                MINUTE          := NUM_MINUTE;
        END IF;
        RETURN TO_NUMBER(MINUTE); --넘버형태로 다시 돌려줌
EXCEPTION
WHEN OTHERS THEN
        RETURN('');
END;
/

