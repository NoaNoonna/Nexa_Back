create PROCEDURE P_INSPECTION         
        (
        V_ORDER_NO_LIST IN VARCHAR2 -- ORDER_DIALOG_OPEN 진행할 ORDER 넘버 발주일련번호,ORDG20200428-898
        , ERROR_CODE OUT NUMBER -- 에러코드
        , ERROR_MSG OUT VARCHAR2 -- 에러메세지
        )
        IS
        
        
-- 커서선언시작
-- 커서에는 뷰단에서 넘어온 ORDER NO를 통해서 각각에 해당하는 모든 정보를 ORDER_INFO에서 받아온다
-- ORDER_NO, ORDER_DATE, ORDER_INFO_STATUS, ORDER_SORT, ITEM_CODE, ITEM_NAME, ORDER_AMOUNT 정보가 담겨 있다
CURSOR C_INSPECTION_LIST
IS
    WITH ORDER_NO_STR AS
    (
    SELECT
    V_ORDER_NO_LIST --뷰단에서 받아온 발주번호 ; 예)ORDG20200428-898
    FROM
    DUAL
    ), -- (ORDER_NO_STR WITH절)
    ORDER_NO_LIST AS
    (
    SELECT
    TRIM( REGEXP_SUBSTR( (SELECT * FROM ORDER_NO_STR ) ,'[^,]+', 1, LEVEL ) ) ORDER_NO
    FROM
    DUAL
    CONNECT BY REGEXP_SUBSTR( (SELECT * FROM ORDER_NO_STR ) , '[^,]+', 1, LEVEL ) IS NOT NULL
    ), --(ORDER_NO_LIST WITH절)
    INSPECTION_LIST AS
    (
    SELECT *
    FROM ORDER_INFO
    WHERE ORDER_NO IN ( SELECT ORDER_NO FROM ORDER_NO_LIST )
    )
    SELECT * FROM INSPECTION_LIST; -- 직접적인 커서 선언절 C_WAREHOUSING_LIST
    																-- 뷰단에서 넘어온 ORDER_NO로 ORDER_INFO에 있는 모든정보를 담음
    -- 커서끝
-- 변수 상수 선언부 끝

-- 실행부 시작

BEGIN

  FOR V_INSPECTION_ROW IN C_INSPECTION_LIST
LOOP

update order_info set inspection_status='Y'
where order_no=V_INSPECTION_ROW.ORDER_NO;

end loop;

END P_INSPECTION;
/

