create PROCEDURE          P_COMPUTE_COST_STATEMENT
       (
           SEARCH_PERIOD_NO IN NUMBER
         , IS_EARLY_PERIOD IN NUMBER
       )
   IS
       BEGIN --원가상세서 설계
       --매출총이익=매출액-매출원가
       --매출원가 = 기초제품재고액+당기제품제조원가-기말제품재고액 <-원가상세서에는 기입X
       --재료비(1) = 기초재료재고액(2)+당기재료매입액(3)-기말재료재고액(4)
       --노무비(5) = 급여 + 일용급여 + 퇴직급여
       --경비(6)
       --당기총제조원가(7) =재료비(4)+노무비(5)+경비(6)
       --기초재공품원가(8)
       --합계(9) = 당기총제조원가(7) + 기초재공품원가(8)
       --기말재공품원가(10)
       --당기제품제조원가(11) = 합계(9)-기말재공품원가(10)
       IF IS_EARLY_PERIOD <> 0 THEN /*당기*/
INSERT INTO TMP_COST_STATEMENT
       (
           ACCOUNT_INNER_CODE
         , ACCOUNT_NAME
         , PARENT_ACCOUNT_CODE
         , COST
         , COST_SUMMARY
         , PERIOD_NO
       ) -- ACCOUNT 계정,PARENT_ACCOUNT_CODE 임시테이블손익계산서
WITH --기초재료재고액 상세내용
       E_MATERIAL_STOCK AS
       (SELECT ACCOUNT_INNER_CODE
            ,--계정내부코드
              UNISTR('기초재료재고액') AS ACCOUNT_NAME
            , '02' AS PARENT_ACCOUNT_CODE
            ,--상위계정내부코드(임시테이블 손익계산서)
              CREDITS_SUM - DEBITS_SUM AS COST
            , --세부금액(")
              --대변(합계) - 차변(합계)
              NULL AS COST_SUMMARY --합계금액(")
         FROM
              (SELECT J.ACCOUNT_INNER_CODE
                   , --계정내부코드(계정과목)
                     A.ACCOUNT_NAME
                   , --계정명(계정과목)
                     SUM(NVL(J.LEFT_DEBTOR_PRICE, 0)) AS DEBITS_SUM
                   , ---차변금액(분개) AS  차변(합계)임시시산표테이블
                     SUM(NVL(J.RIGHT_CREDITS_PRICE, 0)) AS CREDITS_SUM --대변금액(분개) AS  대변(합계)임시시산표테이블
                FROM SLIP S
                   , --전표 --전기에서는 전표와 분개가 아닌 EARLY_STATEMENTS 에서 값을 구함
                     JOURNAL J
                   , -- 분개
                     PERIOD P
                   , -- 기수
                     ACCOUNT A -- 계정과목
               WHERE S.SLIP_NO = J.SLIP_NO --일련번호 전표번호,분개번호조인
                     AND J.ACCOUNT_INNER_CODE = A.ACCOUNT_INNER_CODE --계정,분개 내부계정코드
                     AND S.SLIP_STATUS LIKE '승인' --전표상태
                     AND S.ACCOUNT_PERIOD_NO = P.ACCOUNT_PERIOD_NO --회계기수일련번호
                     AND P.ACCOUNT_PERIOD_NO = SEARCH_PERIOD_NO-1 --전기
                     AND J.BALANCE_DIVISION='대변'
                     AND A.ACCOUNT_CHARACTER LIKE '%료비' --상위계정내부코드  매출
               GROUP BY J.ACCOUNT_INNER_CODE
                   , A.ACCOUNT_NAME
              )
       )
     ,  --기초재료재고액 총계
       E_MATERIAL_STOCK_SUMMARY AS
       (SELECT '02' AS ACCOUNT_INNER_CODE
            , UNISTR('기초재료재고액') AS ACCOUNT_NAME
            , NULL AS PARENT_ACCOUNT_CODE
            , NVL(SUM(COST), 0) AS COST
            , NULL AS COST_SUMMARY
         FROM E_MATERIAL_STOCK --기초재료재고액 상세내용
       )
     ,  --당기재료매입액 상세내용
       MATERIAL_BUY AS
       (SELECT ACCOUNT_INNER_CODE
            ,--계정내부코드
              UNISTR('당기재료매입액') AS ACCOUNT_NAME
            , '03' AS PARENT_ACCOUNT_CODE
            ,--상위계정내부코드(임시테이블 손익계산서)
              DEBITS_SUM - CREDITS_SUM AS COST
            , --세부금액(")
              --차변(합계) - 대변(합계)
              NULL AS COST_SUMMARY --합계금액(")
         FROM
              (SELECT J.ACCOUNT_INNER_CODE
                   , --계정내부코드(계정과목)
                     A.ACCOUNT_NAME
                   , --계정명(계정과목)
                     SUM(NVL(J.LEFT_DEBTOR_PRICE, 0)) AS DEBITS_SUM
                   , ---차변금액(분개) AS  차변(합계)임시시산표테이블
                     SUM(NVL(J.RIGHT_CREDITS_PRICE, 0)) AS CREDITS_SUM --대변금액(분개) AS  대변(합계)임시시산표테이블
                FROM SLIP S
                   , --전표 --전기에서는 전표와 분개가 아닌 EARLY_STATEMENTS 에서 값을 구함
                     JOURNAL J
                   , -- 분개
                     PERIOD P
                   , -- 기수
                     ACCOUNT A -- 계정과목
               WHERE S.SLIP_NO = J.SLIP_NO --일련번호 전표번호,분개번호조인
                     AND J.ACCOUNT_INNER_CODE = A.ACCOUNT_INNER_CODE --계정,분개 내부계정코드
                     AND S.SLIP_STATUS LIKE '승인' --전표상태
                     AND S.ACCOUNT_PERIOD_NO = P.ACCOUNT_PERIOD_NO --회계기수일련번호
                     AND P.ACCOUNT_PERIOD_NO = SEARCH_PERIOD_NO --당기
                     AND J.BALANCE_DIVISION='차변'
                     AND A.ACCOUNT_CHARACTER LIKE '%료비' --상위계정내부코드  매출
               GROUP BY J.ACCOUNT_INNER_CODE
                   , A.ACCOUNT_NAME
              )
       )
     ,  --당기재료매입액 총계
       MATERIAL_BUY_SUMMARY AS
       (SELECT '03' AS ACCOUNT_INNER_CODE
            , UNISTR('당기재료매입액') AS ACCOUNT_NAME
            , NULL AS PARENT_ACCOUNT_CODE
            , NVL(SUM(COST), 0) AS COST
            , NULL AS COST_SUMMARY
         FROM MATERIAL_BUY --당기재료매입액 상세내용
       )
     ,     --기말재료재고액 상세내용
       MATERIAL_STOCK AS
       (SELECT ACCOUNT_INNER_CODE
            ,--계정내부코드
              UNISTR('기말재료재고액') AS ACCOUNT_NAME
            , '04' AS PARENT_ACCOUNT_CODE
            ,--상위계정내부코드(임시테이블 손익계산서)
              CREDITS_SUM - DEBITS_SUM AS COST
            , --세부금액(")
              -- 대변(합계) - 차변(합계)
              NULL AS COST_SUMMARY --합계금액(")
         FROM
              (SELECT J.ACCOUNT_INNER_CODE
                   , --계정내부코드(계정과목)
                     A.ACCOUNT_NAME
                   , --계정명(계정과목)
                     SUM(NVL(J.LEFT_DEBTOR_PRICE, 0)) AS DEBITS_SUM
                   , ---차변금액(분개) AS  차변(합계)임시시산표테이블
                     SUM(NVL(J.RIGHT_CREDITS_PRICE, 0)) AS CREDITS_SUM --대변금액(분개) AS  대변(합계)임시시산표테이블
                FROM SLIP S
                   , --전표 --전기에서는 전표와 분개가 아닌 EARLY_STATEMENTS 에서 값을 구함
                     JOURNAL J
                   , -- 분개
                     PERIOD P
                   , -- 기수
                     ACCOUNT A -- 계정과목
               WHERE S.SLIP_NO = J.SLIP_NO --일련번호 전표번호,분개번호조인
                     AND J.ACCOUNT_INNER_CODE = A.ACCOUNT_INNER_CODE --계정,분개 내부계정코드
                     AND S.SLIP_STATUS LIKE '승인' --전표상태
                     AND S.ACCOUNT_PERIOD_NO = P.ACCOUNT_PERIOD_NO --회계기수일련번호
                     AND P.ACCOUNT_PERIOD_NO = SEARCH_PERIOD_NO --당기
                     AND J.BALANCE_DIVISION='대변'
                     AND A.ACCOUNT_CHARACTER LIKE '%료비' --상위계정내부코드  매출
               GROUP BY J.ACCOUNT_INNER_CODE
                   , A.ACCOUNT_NAME
              )
       )
     ,  --기말재료재고액 총계
       MATERIAL_STOCK_SUMMARY AS
       (SELECT '04' AS ACCOUNT_INNER_CODE
            , UNISTR('기말재료재고액') AS ACCOUNT_NAME
            , NULL AS PARENT_ACCOUNT_CODE
            , NVL(SUM(COST), 0) AS COST
            , NULL AS COST_SUMMARY
         FROM MATERIAL_STOCK --기말재료재고액 상세내용
       )
     ,   --재료비 = 기초재료재고액 총계+당기재료매입액 총계 -기말재료재고액 총계
       MATERIAL_COST AS
       (SELECT '01' AS ACCOUNT_INNER_CODE
            , UNISTR('재료비') AS ACCOUNT_NAME
            , NULL AS PARENT_ACCOUNT_CODE
            , NULL AS COST
            , E.COST + B.COST - M.COST AS COST_SUMMARY
         FROM E_MATERIAL_STOCK_SUMMARY E
            , --기초재료재고액 총계
              MATERIAL_BUY_SUMMARY B
            , --당기재료매입액 총계
              MATERIAL_STOCK_SUMMARY M --기말재료재고액 총계
       )
     ,        --노무비 상세내용
       SALARY AS
       (SELECT ACCOUNT_INNER_CODE
            ,--계정내부코드
              UNISTR('노무비') AS ACCOUNT_NAME
            , '05' AS PARENT_ACCOUNT_CODE
            ,--상위계정내부코드(임시테이블 손익계산서)
              DEBITS_SUM - CREDITS_SUM AS COST
            , --세부금액(")
              --차변(합계)  -  대변(합계)
              NULL AS COST_SUMMARY --합계금액(")
         FROM
              (SELECT J.ACCOUNT_INNER_CODE
                   , --계정내부코드(계정과목)
                     A.ACCOUNT_NAME
                   , --계정명(계정과목)
                     SUM(NVL(J.LEFT_DEBTOR_PRICE, 0)) AS DEBITS_SUM
                   , ---차변금액(분개) AS  차변(합계)임시시산표테이블
                     SUM(NVL(J.RIGHT_CREDITS_PRICE, 0)) AS CREDITS_SUM --대변금액(분개) AS  대변(합계)임시시산표테이블
                FROM SLIP S
                   , --전표 --전기에서는 전표와 분개가 아닌 EARLY_STATEMENTS 에서 값을 구함
                     JOURNAL J
                   , -- 분개
                     PERIOD P
                   , -- 기수
                     ACCOUNT A -- 계정과목
               WHERE S.SLIP_NO = J.SLIP_NO --일련번호 전표번호,분개번호조인
                     AND J.ACCOUNT_INNER_CODE = A.ACCOUNT_INNER_CODE --계정,분개 내부계정코드
                     AND S.SLIP_STATUS LIKE '승인' --전표상태
                     AND S.ACCOUNT_PERIOD_NO = P.ACCOUNT_PERIOD_NO --회계기수일련번호
                     AND P.ACCOUNT_PERIOD_NO = SEARCH_PERIOD_NO --당기
                     AND A.ACCOUNT_CHARACTER LIKE '인건비%' --상위계정내부코드  매출
               GROUP BY J.ACCOUNT_INNER_CODE
                   , A.ACCOUNT_NAME
                  UNION ALL
              SELECT J.ACCOUNT_INNER_CODE
                   , --계정내부코드(계정과목)
                     A.ACCOUNT_NAME
                   , --계정명(계정과목)
                     SUM(NVL(J.LEFT_DEBTOR_PRICE, 0)) AS DEBITS_SUM
                   , ---차변금액(분개) AS  차변(합계)임시시산표테이블
                     SUM(NVL(J.RIGHT_CREDITS_PRICE, 0)) AS CREDITS_SUM --대변금액(분개) AS  대변(합계)임시시산표테이블
                FROM SLIP S
                   , --전표 --전기에서는 전표와 분개가 아닌 EARLY_STATEMENTS 에서 값을 구함
                     JOURNAL J
                   , -- 분개
                     PERIOD P
                   , -- 기수
                     ACCOUNT A -- 계정과목
               WHERE S.SLIP_NO = J.SLIP_NO --일련번호 전표번호,분개번호조인
                     AND J.ACCOUNT_INNER_CODE = A.ACCOUNT_INNER_CODE --계정,분개 내부계정코드
                     AND S.SLIP_STATUS LIKE '승인' --전표상태
                     AND S.ACCOUNT_PERIOD_NO = P.ACCOUNT_PERIOD_NO --회계기수일련번호
                     AND P.ACCOUNT_PERIOD_NO = SEARCH_PERIOD_NO --당기
                     AND A.ACCOUNT_CHARACTER LIKE '노무비%' --상위계정내부코드  매출
               GROUP BY J.ACCOUNT_INNER_CODE
                   , A.ACCOUNT_NAME
              )
       )
     ,  --노무비 총계
       SALARY_SUMMARY AS
       (SELECT '05' AS ACCOUNT_INNER_CODE
            , UNISTR('노무비') AS ACCOUNT_NAME
            , NULL AS PARENT_ACCOUNT_CODE
            , NULL AS COST
            , NVL(SUM(COST), 0) AS COST_SUMMARY
         FROM SALARY --노무비 상세내용
       )
     ,    --경비 상세내용
       MF_EXPENSES AS
       (SELECT ACCOUNT_INNER_CODE
            ,--계정내부코드
              UNISTR('경비') AS ACCOUNT_NAME
            , '06' AS PARENT_ACCOUNT_CODE
            ,--상위계정내부코드(임시테이블 손익계산서)
              DEBITS_SUM - CREDITS_SUM AS COST
            , --세부금액(")
              --차변(합계) - 대변(합계)
              NULL AS COST_SUMMARY --합계금액(")
         FROM
              (SELECT J.ACCOUNT_INNER_CODE
                   , --계정내부코드(계정과목)
                     A.ACCOUNT_NAME
                   , --계정명(계정과목)
                     SUM(NVL(J.LEFT_DEBTOR_PRICE, 0)) AS DEBITS_SUM
                   , ---차변금액(분개) AS  차변(합계)임시시산표테이블
                     SUM(NVL(J.RIGHT_CREDITS_PRICE, 0)) AS CREDITS_SUM --대변금액(분개) AS  대변(합계)임시시산표테이블
                FROM SLIP S
                   , --전표 --전기에서는 전표와 분개가 아닌 EARLY_STATEMENTS 에서 값을 구함
                     JOURNAL J
                   , -- 분개
                     PERIOD P
                   , -- 기수
                     ACCOUNT A -- 계정과목
               WHERE S.SLIP_NO = J.SLIP_NO --일련번호 전표번호,분개번호조인
                     AND J.ACCOUNT_INNER_CODE = A.ACCOUNT_INNER_CODE --계정,분개 내부계정코드
                     AND S.SLIP_STATUS LIKE '승인' --전표상태
                     AND S.ACCOUNT_PERIOD_NO = P.ACCOUNT_PERIOD_NO --회계기수일련번호
                     AND P.ACCOUNT_PERIOD_NO = SEARCH_PERIOD_NO --당기
                     AND A.ACCOUNT_CHARACTER LIKE '%경비' --상위계정내부코드  매출
               GROUP BY J.ACCOUNT_INNER_CODE
                   , A.ACCOUNT_NAME
              )
       )
     ,  --경비 총계
       MF_EXPENSES_SUMMARY AS
       (SELECT '06' AS ACCOUNT_INNER_CODE
            , UNISTR('경비') AS ACCOUNT_NAME
            , NULL AS PARENT_ACCOUNT_CODE
            , NULL AS COST
            , NVL(SUM(COST), 0) AS COST_SUMMARY
         FROM MF_EXPENSES --경비 상세내용
       )
     ,  --당기총제조원가(7) =재료비(4)+노무비(5)+경비(6)
       MF_COST AS
       (SELECT '07' AS ACCOUNT_INNER_CODE
            , UNISTR('당기총제조원가') AS ACCOUNT_NAME
            , NULL AS PARENT_ACCOUNT_CODE
            , NULL AS COST
            , M.COST_SUMMARY + S.COST_SUMMARY + E.COST_SUMMARY AS COST_SUMMARY
         FROM MATERIAL_COST M
            , --재료비
              SALARY_SUMMARY S
            , --노무비
              MF_EXPENSES_SUMMARY E --경비
       )
     ,  --기초재공품원가 상세내용
       E_WORK_IN_PROCESS AS
       (SELECT ACCOUNT_INNER_CODE
            ,--계정내부코드
              UNISTR('기초재공품원가') AS ACCOUNT_NAME
            , '08' AS PARENT_ACCOUNT_CODE
            ,--상위계정내부코드(임시테이블 손익계산서)
              NULL AS COST
            , CREDITS_SUM - DEBITS_SUM AS COST_SUMMARY --합계금액(")
              --대변(합계) - 차변(합계)
         FROM
              (SELECT J.ACCOUNT_INNER_CODE
                   , --계정내부코드(계정과목)
                     A.ACCOUNT_NAME
                   , --계정명(계정과목)
                     SUM(NVL(J.LEFT_DEBTOR_PRICE, 0)) AS DEBITS_SUM
                   , ---차변금액(분개) AS  차변(합계)임시시산표테이블
                     SUM(NVL(J.RIGHT_CREDITS_PRICE, 0)) AS CREDITS_SUM --대변금액(분개) AS  대변(합계)임시시산표테이블
                FROM SLIP S
                   , --전표 --전기에서는 전표와 분개가 아닌 EARLY_STATEMENTS 에서 값을 구함
                     JOURNAL J
                   , -- 분개
                     PERIOD P
                   , -- 기수
                     ACCOUNT A -- 계정과목
               WHERE S.SLIP_NO = J.SLIP_NO --일련번호 전표번호,분개번호조인
                     AND J.ACCOUNT_INNER_CODE = A.ACCOUNT_INNER_CODE --계정,분개 내부계정코드
                     AND S.SLIP_STATUS LIKE '승인' --전표상태
                     AND S.ACCOUNT_PERIOD_NO = P.ACCOUNT_PERIOD_NO --회계기수일련번호
                     AND P.ACCOUNT_PERIOD_NO = SEARCH_PERIOD_NO-1 --당기
                     AND J.BALANCE_DIVISION = '대변'
                     AND A.ACCOUNT_NAME LIKE '재공품' --상위계정내부코드  매출
               GROUP BY J.ACCOUNT_INNER_CODE
                   , A.ACCOUNT_NAME
              )
       )
     ,  --기초재공품원가 총계
       E_WORK_IN_PROCESS_SUMMARY AS
       (SELECT '08' AS ACCOUNT_INNER_CODE
            , UNISTR('기초재공품원가') AS ACCOUNT_NAME
            , NULL AS PARENT_ACCOUNT_CODE
            , NULL AS COST
            , NVL(SUM(COST_SUMMARY), 0) AS COST_SUMMARY
         FROM E_WORK_IN_PROCESS --기초재공품원가 상세내용
       )
     ,  --합계=당기총제조원가+기초재공품원가
       TOTAL_COST AS
       (SELECT '09' AS ACCOUNT_INNER_CODE
            , UNISTR('합계') AS ACCOUNT_NAME
            , NULL AS PARENT_ACCOUNT_CODE
            , NULL AS COST
            , C.COST_SUMMARY + W.COST_SUMMARY AS COST_SUMMARY
         FROM MF_COST C
            , E_WORK_IN_PROCESS_SUMMARY W --기초재공품원가 총계
       )
     ,   --기말재공품원가 상세내용
       WORK_IN_PROCESS AS
       (SELECT ACCOUNT_INNER_CODE
            ,--계정내부코드
              UNISTR('기말재공품원가') AS ACCOUNT_NAME
            , '10' AS PARENT_ACCOUNT_CODE
            ,--상위계정내부코드(임시테이블 손익계산서)
              CREDITS_SUM - DEBITS_SUM AS COST
            , --합계금액(")
              --대변(합계) - 차변(합계)
              NULL AS COST_SUMMARY
         FROM
              (SELECT J.ACCOUNT_INNER_CODE
                   , --계정내부코드(계정과목)
                     A.ACCOUNT_NAME
                   , --계정명(계정과목)
                     SUM(NVL(J.LEFT_DEBTOR_PRICE, 0)) AS DEBITS_SUM
                   , ---차변금액(분개) AS  차변(합계)임시시산표테이블
                     SUM(NVL(J.RIGHT_CREDITS_PRICE, 0)) AS CREDITS_SUM --대변금액(분개) AS  대변(합계)임시시산표테이블
                FROM SLIP S
                   , --전표 --전기에서는 전표와 분개가 아닌 EARLY_STATEMENTS 에서 값을 구함
                     JOURNAL J
                   , -- 분개
                     PERIOD P
                   , -- 기수
                     ACCOUNT A -- 계정과목
               WHERE S.SLIP_NO = J.SLIP_NO --일련번호 전표번호,분개번호조인
                     AND J.ACCOUNT_INNER_CODE = A.ACCOUNT_INNER_CODE --계정,분개 내부계정코드
                     AND S.SLIP_STATUS LIKE '승인' --전표상태
                     AND S.ACCOUNT_PERIOD_NO = P.ACCOUNT_PERIOD_NO --회계기수일련번호
                     AND P.ACCOUNT_PERIOD_NO = SEARCH_PERIOD_NO --당기
                     AND J.BALANCE_DIVISION = '대변'
                     AND A.ACCOUNT_NAME LIKE '재공품' --상위계정내부코드  매출
               GROUP BY J.ACCOUNT_INNER_CODE
                   , A.ACCOUNT_NAME
              )
       )
     ,  --기말재공품원가 총계
       WORK_IN_PROCESS_SUMMARY AS
       (SELECT '10' AS ACCOUNT_INNER_CODE
            , UNISTR('기말재공품원가') AS ACCOUNT_NAME
            , NULL AS PARENT_ACCOUNT_CODE
            , NULL AS COST
            , NVL(SUM(COST), 0) AS COST_SUMMARY
         FROM WORK_IN_PROCESS --기초재공품원가 상세내용
       )
     ,  --당기제품제조원가 = 합계-기말재공품원가
       TOTAL_MF_COST AS
       (SELECT '11' AS ACCOUNT_INNER_CODE
            , UNISTR('당기제품제조원가') AS ACCOUNT_NAME
            , NULL AS PARENT_ACCOUNT_CODE
            , NULL AS COST
            , C.COST_SUMMARY - W.COST_SUMMARY AS COST_SUMMARY
         FROM TOTAL_COST C
            , --합계
              WORK_IN_PROCESS_SUMMARY W --기말재공품원가 총계
       )
SELECT A.*
     , SEARCH_PERIOD_NO
  FROM
       (SELECT *
         FROM MATERIAL_COST
           UNION ALL
       SELECT*
         FROM E_MATERIAL_STOCK_SUMMARY
           UNION ALL
       SELECT*
         FROM MATERIAL_BUY_SUMMARY
           UNION ALL
       SELECT*
         FROM MATERIAL_STOCK_SUMMARY
           UNION ALL
       SELECT*
         FROM SALARY_SUMMARY
           UNION ALL
       SELECT*
         FROM MF_EXPENSES_SUMMARY
           UNION ALL
       SELECT*
         FROM MF_COST
           UNION ALL
       SELECT*
         FROM E_WORK_IN_PROCESS_SUMMARY
           UNION ALL
       SELECT*
         FROM TOTAL_COST
           UNION ALL
       SELECT*
         FROM WORK_IN_PROCESS_SUMMARY
           UNION ALL
       SELECT*
         FROM TOTAL_MF_COST
       ) A;
ELSE

    INSERT INTO TMP_COST_STATEMENT
           (
               ACCOUNT_INNER_CODE
             , ACCOUNT_NAME
             , PARENT_ACCOUNT_CODE
             , COST
             , COST_SUMMARY
             , PERIOD_NO
           ) -- ACCOUNT 계정,PARENT_ACCOUNT_CODE 임시테이블손익계산서
    WITH --기초재료재고액 상세내용
           S_E_MATERIAL_STOCK AS
           (SELECT ACCOUNT_INNER_CODE
                ,--계정내부코드
                  UNISTR('기초재료재고액') AS ACCOUNT_NAME
                , '02' AS PARENT_ACCOUNT_CODE
                ,--상위계정내부코드(임시테이블 손익계산서)
                  CREDITS_SUM - DEBITS_SUM AS COST
                , --세부금액(")
                  --대변(합계) - 차변(합계)
                  NULL AS COST_SUMMARY --합계금액(")
             FROM
                  (SELECT E.ACCOUNT_INNER_CODE
                       , --계정내부코드(계정과목)
                         A.ACCOUNT_NAME
                       , --계정명(계정과목)
                         SUM(NVL(E.LEFT_DEBTOR_PRICE, 0)) AS DEBITS_SUM
                       , ---차변금액(분개) AS  차변(합계)임시시산표테이블
                         SUM(NVL(E.RIGHT_CREDITS_PRICE, 0)) AS CREDITS_SUM --대변금액(분개) AS  대변(합계)임시시산표테이블
                    FROM EARLY_STATEMENTS E
                       , PERIOD P
                       , -- 기수
                         ACCOUNT A -- 계정과목
                   WHERE E.ACCOUNT_INNER_CODE = A.ACCOUNT_INNER_CODE --계정,분개 내부계정코드
                         AND E.ACCOUNT_PERIOD_NO = P.ACCOUNT_PERIOD_NO
                         AND P.ACCOUNT_PERIOD_NO = SEARCH_PERIOD_NO-1 --전기
                         AND NVL(E.LEFT_DEBTOR_PRICE,'0')='0'
                         AND A.ACCOUNT_CHARACTER LIKE '%료비' --상위계정내부코드  매출
                   GROUP BY E.ACCOUNT_INNER_CODE
                       , A.ACCOUNT_NAME
                  )
           )
         ,  --기초재료재고액 총계
           S_E_MATERIAL_STOCK_SUMMARY AS
           (SELECT '02' AS ACCOUNT_INNER_CODE
                , UNISTR('기초재료재고액') AS ACCOUNT_NAME
                , NULL AS PARENT_ACCOUNT_CODE
                , NVL(SUM(COST), 0) AS COST
                , NULL AS COST_SUMMARY
             FROM S_E_MATERIAL_STOCK --기초재료재고액 상세내용
           )
         ,  --당기재료매입액 상세내용
           S_MATERIAL_BUY AS
           (SELECT ACCOUNT_INNER_CODE
                ,--계정내부코드
                  UNISTR('당기재료매입액') AS ACCOUNT_NAME
                , '03' AS PARENT_ACCOUNT_CODE
                ,--상위계정내부코드(임시테이블 손익계산서)
                  DEBITS_SUM - CREDITS_SUM AS COST
                , --세부금액(")
                  --차변(합계) - 대변(합계)
                  NULL AS COST_SUMMARY --합계금액(")
             FROM
                  (SELECT E.ACCOUNT_INNER_CODE
                       , --계정내부코드(계정과목)
                         A.ACCOUNT_NAME
                       , --계정명(계정과목)
                         SUM(NVL(E.LEFT_DEBTOR_PRICE, 0)) AS DEBITS_SUM
                       , ---차변금액(분개) AS  차변(합계)임시시산표테이블
                         SUM(NVL(E.RIGHT_CREDITS_PRICE, 0)) AS CREDITS_SUM --대변금액(분개) AS  대변(합계)임시시산표테이블
                    FROM EARLY_STATEMENTS E
                       , PERIOD P
                       , -- 기수
                         ACCOUNT A -- 계정과목
                   WHERE E.ACCOUNT_INNER_CODE = A.ACCOUNT_INNER_CODE --계정,분개 내부계정코드
                         AND E.ACCOUNT_PERIOD_NO = P.ACCOUNT_PERIOD_NO
                         AND P.ACCOUNT_PERIOD_NO = SEARCH_PERIOD_NO --당기
                         AND NVL(E.RIGHT_CREDITS_PRICE,'0')='0'
                         AND A.ACCOUNT_CHARACTER LIKE '%료비' --상위계정내부코드  매출
                   GROUP BY E.ACCOUNT_INNER_CODE
                       , A.ACCOUNT_NAME
                  )
           )
         ,  --당기재료매입액 총계
           S_MATERIAL_BUY_SUMMARY AS
           (SELECT '03' AS ACCOUNT_INNER_CODE
                , UNISTR('당기재료매입액') AS ACCOUNT_NAME
                , NULL AS PARENT_ACCOUNT_CODE
                , NVL(SUM(COST), 0) AS COST
                , NULL AS COST_SUMMARY
             FROM S_MATERIAL_BUY --당기재료매입액 상세내용
           )
         ,     --기말재료재고액 상세내용
           S_MATERIAL_STOCK AS
           (SELECT ACCOUNT_INNER_CODE
                ,--계정내부코드
                  UNISTR('기말재료재고액') AS ACCOUNT_NAME
                , '04' AS PARENT_ACCOUNT_CODE
                ,--상위계정내부코드(임시테이블 손익계산서)
                  DEBITS_SUM - CREDITS_SUM AS COST
                , --세부금액(")
                  --차변(합계) - 대변(합계)
                  NULL AS COST_SUMMARY --합계금액(")
             FROM
                  (SELECT E.ACCOUNT_INNER_CODE
                       , --계정내부코드(계정과목)
                         A.ACCOUNT_NAME
                       , --계정명(계정과목)
                         SUM(NVL(E.LEFT_DEBTOR_PRICE, 0)) AS DEBITS_SUM
                       , ---차변금액(분개) AS  차변(합계)임시시산표테이블
                         SUM(NVL(E.RIGHT_CREDITS_PRICE, 0)) AS CREDITS_SUM --대변금액(분개) AS  대변(합계)임시시산표테이블
                    FROM EARLY_STATEMENTS E
                       , PERIOD P
                       , -- 기수
                         ACCOUNT A -- 계정과목
                   WHERE E.ACCOUNT_INNER_CODE = A.ACCOUNT_INNER_CODE --계정,분개 내부계정코드
                         AND E.ACCOUNT_PERIOD_NO = P.ACCOUNT_PERIOD_NO
                         AND P.ACCOUNT_PERIOD_NO = SEARCH_PERIOD_NO --당기
                         AND NVL(E.LEFT_DEBTOR_PRICE,'0')='0'
                         AND A.ACCOUNT_CHARACTER LIKE '%료비' --상위계정내부코드  매출
                   GROUP BY E.ACCOUNT_INNER_CODE
                       , A.ACCOUNT_NAME
                  )
           )
         ,  --기말재료재고액 총계
           S_MATERIAL_STOCK_SUMMARY AS
           (SELECT '04' AS ACCOUNT_INNER_CODE
                , UNISTR('기말재료재고액') AS ACCOUNT_NAME
                , NULL AS PARENT_ACCOUNT_CODE
                , NVL(SUM(COST), 0) AS COST
                , NULL AS COST_SUMMARY
             FROM S_MATERIAL_STOCK --기말재료재고액 상세내용
           )
         ,   --재료비 = 기초재료재고액 총계+당기재료매입액 총계 -기말재료재고액 총계
           S_MATERIAL_COST AS
           (SELECT '01' AS ACCOUNT_INNER_CODE
                , UNISTR('재료비') AS ACCOUNT_NAME
                , NULL AS PARENT_ACCOUNT_CODE
                , NULL AS COST
                , E.COST + B.COST - M.COST AS COST_SUMMARY
             FROM S_E_MATERIAL_STOCK_SUMMARY E
                , --기초재료재고액 총계
                  S_MATERIAL_BUY_SUMMARY B
                , --당기재료매입액 총계
                  S_MATERIAL_STOCK_SUMMARY M --기말재료재고액 총계
           )
         ,        --노무비 상세내용
           S_SALARY AS
           (SELECT ACCOUNT_INNER_CODE
                ,--계정내부코드
                  UNISTR('노무비') AS ACCOUNT_NAME
                , '05' AS PARENT_ACCOUNT_CODE
                ,--상위계정내부코드(임시테이블 손익계산서)
                  DEBITS_SUM - CREDITS_SUM AS COST
                , --세부금액(")
                  --차변(합계) - 대변(합계)
                  NULL AS COST_SUMMARY --합계금액(")
             FROM
                  (SELECT E.ACCOUNT_INNER_CODE
                       , --계정내부코드(계정과목)
                         A.ACCOUNT_NAME
                       , --계정명(계정과목)
                         SUM(NVL(E.LEFT_DEBTOR_PRICE, 0)) AS DEBITS_SUM
                       , ---차변금액(분개) AS  차변(합계)임시시산표테이블
                         SUM(NVL(E.RIGHT_CREDITS_PRICE, 0)) AS CREDITS_SUM --대변금액(분개) AS  대변(합계)임시시산표테이블
                    FROM EARLY_STATEMENTS E
                       , PERIOD P
                       , -- 기수
                         ACCOUNT A -- 계정과목
                   WHERE E.ACCOUNT_INNER_CODE = A.ACCOUNT_INNER_CODE --계정,분개 내부계정코드
                         AND E.ACCOUNT_PERIOD_NO = P.ACCOUNT_PERIOD_NO
                         AND P.ACCOUNT_PERIOD_NO = SEARCH_PERIOD_NO --당기
                         AND A.ACCOUNT_CHARACTER LIKE '인건비%' --상위계정내부코드  매출
                   GROUP BY E.ACCOUNT_INNER_CODE
                       , A.ACCOUNT_NAME
                      UNION ALL
                  SELECT E.ACCOUNT_INNER_CODE
                       , --계정내부코드(계정과목)
                         A.ACCOUNT_NAME
                       , --계정명(계정과목)
                         SUM(NVL(E.LEFT_DEBTOR_PRICE, 0)) AS DEBITS_SUM
                       , ---차변금액(분개) AS  차변(합계)임시시산표테이블
                         SUM(NVL(E.RIGHT_CREDITS_PRICE, 0)) AS CREDITS_SUM --대변금액(분개) AS  대변(합계)임시시산표테이블
                    FROM EARLY_STATEMENTS E
                       , PERIOD P
                       , -- 기수
                         ACCOUNT A -- 계정과목
                   WHERE E.ACCOUNT_INNER_CODE = A.ACCOUNT_INNER_CODE --계정,분개 내부계정코드
                         AND E.ACCOUNT_PERIOD_NO = P.ACCOUNT_PERIOD_NO
                         AND P.ACCOUNT_PERIOD_NO = SEARCH_PERIOD_NO --당기
                         AND A.ACCOUNT_CHARACTER LIKE '노무비%' --상위계정내부코드  매출
                   GROUP BY E.ACCOUNT_INNER_CODE
                       , A.ACCOUNT_NAME
                  )
           )
         ,  --노무비 총계
           S_SALARY_SUMMARY AS
           (SELECT '05' AS ACCOUNT_INNER_CODE
                , UNISTR('노무비') AS ACCOUNT_NAME
                , NULL AS PARENT_ACCOUNT_CODE
                , NULL AS COST
                , NVL(SUM(COST), 0) AS COST_SUMMARY
             FROM S_SALARY --노무비 상세내용
           )
         ,    --경비 상세내용
           S_MF_EXPENSES AS
           (SELECT ACCOUNT_INNER_CODE
                ,--계정내부코드
                  UNISTR('경비') AS ACCOUNT_NAME
                , '06' AS PARENT_ACCOUNT_CODE
                ,--상위계정내부코드(임시테이블 손익계산서)
                  DEBITS_SUM - CREDITS_SUM AS COST
                , --세부금액(")
                  --차변(합계) - 대변(합계)
                  NULL AS COST_SUMMARY --합계금액(")
             FROM
                  (SELECT E.ACCOUNT_INNER_CODE
                       , --계정내부코드(계정과목)
                         A.ACCOUNT_NAME
                       , --계정명(계정과목)
                         SUM(NVL(E.LEFT_DEBTOR_PRICE, 0)) AS DEBITS_SUM
                       , ---차변금액(분개) AS  차변(합계)임시시산표테이블
                         SUM(NVL(E.RIGHT_CREDITS_PRICE, 0)) AS CREDITS_SUM --대변금액(분개) AS  대변(합계)임시시산표테이블
                    FROM EARLY_STATEMENTS E
                       , PERIOD P
                       , -- 기수
                         ACCOUNT A -- 계정과목
                   WHERE E.ACCOUNT_INNER_CODE = A.ACCOUNT_INNER_CODE --계정,분개 내부계정코드
                         AND E.ACCOUNT_PERIOD_NO = P.ACCOUNT_PERIOD_NO
                         AND P.ACCOUNT_PERIOD_NO = SEARCH_PERIOD_NO --당기
                         AND A.ACCOUNT_CHARACTER LIKE '%경비' --상위계정내부코드  매출
                   GROUP BY E.ACCOUNT_INNER_CODE
                       , A.ACCOUNT_NAME
                  )
           )
         ,  --경비 총계
           S_MF_EXPENSES_SUMMARY AS
           (SELECT '06' AS ACCOUNT_INNER_CODE
                , UNISTR('경비') AS ACCOUNT_NAME
                , NULL AS PARENT_ACCOUNT_CODE
                , NULL AS COST
                , NVL(SUM(COST), 0) AS COST_SUMMARY
             FROM S_MF_EXPENSES --경비 상세내용
           )
         ,  --당기총제조원가(7) =재료비(4)+노무비(5)+경비(6)
           S_MF_COST AS
           (SELECT '07' AS ACCOUNT_INNER_CODE
                , UNISTR('당기총제조원가') AS ACCOUNT_NAME
                , NULL AS PARENT_ACCOUNT_CODE
                , NULL AS COST
                , M.COST_SUMMARY + S.COST_SUMMARY + E.COST_SUMMARY AS COST_SUMMARY
             FROM S_MATERIAL_COST M
                , --재료비
                  S_SALARY_SUMMARY S
                , --노무비
                  S_MF_EXPENSES_SUMMARY E --경비
           )
         ,  --기초재공품원가 상세내용
           S_E_WORK_IN_PROCESS AS
           (SELECT ACCOUNT_INNER_CODE
                ,--계정내부코드
                  UNISTR('기초재공품원가') AS ACCOUNT_NAME
                , '08' AS PARENT_ACCOUNT_CODE
                ,--상위계정내부코드(임시테이블 손익계산서)
                  NULL AS COST
                , CREDITS_SUM - DEBITS_SUM AS COST_SUMMARY --합계금액(")
                  --대변(합계) - 차변(합계)
             FROM
                  (SELECT E.ACCOUNT_INNER_CODE
                       , --계정내부코드(계정과목)
                         A.ACCOUNT_NAME
                       , --계정명(계정과목)
                         SUM(NVL(E.LEFT_DEBTOR_PRICE, 0)) AS DEBITS_SUM
                       , ---차변금액(분개) AS  차변(합계)임시시산표테이블
                         SUM(NVL(E.RIGHT_CREDITS_PRICE, 0)) AS CREDITS_SUM --대변금액(분개) AS  대변(합계)임시시산표테이블
                    FROM EARLY_STATEMENTS E
                       , PERIOD P
                       , -- 기수
                         ACCOUNT A -- 계정과목
                   WHERE E.ACCOUNT_INNER_CODE = A.ACCOUNT_INNER_CODE --계정,분개 내부계정코드
                         AND E.ACCOUNT_PERIOD_NO = P.ACCOUNT_PERIOD_NO
                         AND P.ACCOUNT_PERIOD_NO = SEARCH_PERIOD_NO-1 --전기
                         AND NVL(E.LEFT_DEBTOR_PRICE,'0')='0'
                         AND A.ACCOUNT_NAME LIKE '재공품' --상위계정내부코드  매출
                   GROUP BY E.ACCOUNT_INNER_CODE
                       , A.ACCOUNT_NAME
                  )
           )
         ,  --기초재공품원가 총계
           S_E_WORK_IN_PROCESS_SUMMARY AS
           (SELECT '08' AS ACCOUNT_INNER_CODE
                , UNISTR('기초재공품원가') AS ACCOUNT_NAME
                , NULL AS PARENT_ACCOUNT_CODE
                , NULL AS COST
                , NVL(SUM(COST_SUMMARY), 0) AS COST_SUMMARY
             FROM S_E_WORK_IN_PROCESS --기초재공품원가 상세내용
           )
         ,  --합계=당기총제조원가+기초재공품원가
           S_TOTAL_COST AS
           (SELECT '09' AS ACCOUNT_INNER_CODE
                , UNISTR('합계') AS ACCOUNT_NAME
                , NULL AS PARENT_ACCOUNT_CODE
                , NULL AS COST
                , C.COST_SUMMARY + W.COST_SUMMARY AS COST_SUMMARY
             FROM S_MF_COST C
                , S_E_WORK_IN_PROCESS_SUMMARY W --기초재공품원가 총계
           )
         ,   --기말재공품원가 상세내용
           S_WORK_IN_PROCESS AS
           (SELECT ACCOUNT_INNER_CODE
                ,--계정내부코드
                  UNISTR('기말재공품원가') AS ACCOUNT_NAME
                , '10' AS PARENT_ACCOUNT_CODE
                ,--상위계정내부코드(임시테이블 손익계산서)
                  CREDITS_SUM - DEBITS_SUM AS COST
                , --합계금액(")
                  NULL AS COST_SUMMARY --대변(합계) - 차변(합계)
             FROM
                  (SELECT E.ACCOUNT_INNER_CODE
                       , --계정내부코드(계정과목)
                         A.ACCOUNT_NAME
                       , --계정명(계정과목)
                         SUM(NVL(E.LEFT_DEBTOR_PRICE, 0)) AS DEBITS_SUM
                       , ---차변금액(분개) AS  차변(합계)임시시산표테이블
                         SUM(NVL(E.RIGHT_CREDITS_PRICE, 0)) AS CREDITS_SUM --대변금액(분개) AS  대변(합계)임시시산표테이블
                    FROM EARLY_STATEMENTS E
                       , PERIOD P
                       , -- 기수
                         ACCOUNT A -- 계정과목
                   WHERE E.ACCOUNT_INNER_CODE = A.ACCOUNT_INNER_CODE --계정,분개 내부계정코드
                         AND E.ACCOUNT_PERIOD_NO = P.ACCOUNT_PERIOD_NO
                         AND P.ACCOUNT_PERIOD_NO = SEARCH_PERIOD_NO --당기
                         AND NVL(E.LEFT_DEBTOR_PRICE,'0')='0'
                         AND A.ACCOUNT_NAME LIKE '재공품' --상위계정내부코드  매출
                   GROUP BY E.ACCOUNT_INNER_CODE
                       , A.ACCOUNT_NAME
                  )
           )
         ,  --기말재공품원가 총계
           S_WORK_IN_PROCESS_SUMMARY AS
           (SELECT '10' AS ACCOUNT_INNER_CODE
                , UNISTR('기말재공품원가') AS ACCOUNT_NAME
                , NULL AS PARENT_ACCOUNT_CODE
                , NULL AS COST
                , NVL(SUM(COST), 0) AS COST_SUMMARY
             FROM S_WORK_IN_PROCESS --기초재공품원가 상세내용
           )
         ,  --당기제품제조원가 = 합계-기말재공품원가
           S_TOTAL_MF_COST AS
           (SELECT '11' AS ACCOUNT_INNER_CODE
                , UNISTR('당기제품제조원가') AS ACCOUNT_NAME
                , NULL AS PARENT_ACCOUNT_CODE
                , NULL AS COST
                , C.COST_SUMMARY - W.COST_SUMMARY AS COST_SUMMARY
             FROM S_TOTAL_COST C
                , --합계
                  S_WORK_IN_PROCESS_SUMMARY W --기말재공품원가 총계
           )
    SELECT A.*
         , SEARCH_PERIOD_NO
      FROM
           (SELECT *
             FROM S_MATERIAL_COST
               UNION ALL
           SELECT*
             FROM S_E_MATERIAL_STOCK_SUMMARY
               UNION ALL
           SELECT*
             FROM S_MATERIAL_BUY_SUMMARY
               UNION ALL
           SELECT*
             FROM S_MATERIAL_STOCK_SUMMARY
               UNION ALL
           SELECT*
             FROM S_SALARY_SUMMARY
               UNION ALL
           SELECT*
             FROM S_MF_EXPENSES_SUMMARY
               UNION ALL
           SELECT*
             FROM S_MF_COST
               UNION ALL
           SELECT*
             FROM S_E_WORK_IN_PROCESS_SUMMARY
               UNION ALL
           SELECT*
             FROM S_TOTAL_COST
               UNION ALL
           SELECT*
             FROM S_WORK_IN_PROCESS_SUMMARY
               UNION ALL
           SELECT*
             FROM S_TOTAL_MF_COST
           ) A;
END IF;
END P_COMPUTE_COST_STATEMENT;
/

