create PROCEDURE          "P_TMP_FINANCIAL_POSITION"   -- 60번째줄부터 보쟈.!
    ( P_PERIOD_NO IN VARCHAR2 )
IS
    V_NET_INCOME        NUMBER;

CURSOR GET_FINANCIAL_POSITION IS
    WITH DETAIL AS (
        SELECT
            LEV,                 /*레벨링*/
            CODE  AS ACCOUNT_CODE,/*계정코드*/
            MIN,                 /*코드그룹최소코드*/
            MAX,                 /*코드그룹최대코드*/
            CATEGORY,            /*계정과목최상위제목*/
            ACCOUNT_NAME,        /*계정과목*/

             CASE
                WHEN  SUBSTR(LEAD(ACCOUNT_NAME) OVER(ORDER BY 1),1,1) ='└'
                AND SUBSTR(LEAD(ACCOUNT_NAME,2) OVER(ORDER BY 1),1,1) ='└'
                THEN BALANCE

                WHEN SUBSTR(LEAD(ACCOUNT_NAME) OVER(ORDER BY 1),1,1) ='└' THEN BALANCE

                ELSE BALANCE_DETAIL

            END   AS BALANCE_DETAIL, /*세부금액*/



            CASE
                WHEN SUBSTR(LEAD(ACCOUNT_NAME) OVER(ORDER BY 1),1,1) ='└'
                AND SUBSTR(LEAD(ACCOUNT_NAME,2) OVER(ORDER BY 1),1,1) ='└'
                AND SUBSTR(ACCOUNT_NAME,1,1) !='└'
                THEN BALANCE + LEAD(BALANCE_DETAIL) OVER(ORDER BY 1) + LEAD(BALANCE_DETAIL,2) OVER(ORDER BY 1)

                WHEN SUBSTR(LEAD(ACCOUNT_NAME) OVER(ORDER BY 1),1,1) ='└'
                AND   SUBSTR(ACCOUNT_NAME,1,1) !='└'
                    THEN BALANCE + LEAD(BALANCE_DETAIL) OVER(ORDER BY 1)

                WHEN BALANCE IS NULL THEN 0
                ELSE BALANCE

            END  AS BALANCE_DETAIL_SUMMARY /**합계금액*/

        FROM
            (  SELECT
                    LEV,  /*레벨링*/               -- DETAIL3
                    CODE, /*계정코드*/
                    MIN,  /*코드그룹최소코드*/
                    MAX,  /*코드그룹최대코드*/

                    CASE
                        WHEN CODE < '0251'  THEN '자산' -- CODE 0251 이하 자산
                        WHEN CODE < '0331'  THEN '부채' -- CODE 0331 이하 부채
                        WHEN CODE < '0401'  THEN '자본' -- CODE 0401 이하 자본
                    END  AS CATEGORY, /*계정과목최상위제목*/

                    ACCOUNT_NAME, /*계정과목*/

                    CASE
                        WHEN SUBSTR(ACCOUNT_NAME,1,1) = '└'  THEN BALANCE
                        ELSE  0
                    END  AS BALANCE_DETAIL, /*세부금액*/

                    CASE
                        WHEN SIGN(BALANCE) = 1 THEN BALANCE		-- SIGN(숫자) : 숫자의 부호 확인
                        WHEN SIGN(BALANCE) = - 1
                        AND  SUBSTR(ACCOUNT_NAME,1,1) != '└'  THEN BALANCE
                    END  AS BALANCE       /*합계금액*/

                FROM


-----------------------------------------------------------------------------------------------------
                    -- 합계잔액시산표에서  당기 자산, 자본, 부채에 대한 값을 가지고와서 잔액을 구한다
                    ( SELECT
                            LEV,  /*레벨링*/
                            CODE, /*계정코드*/      -- EX. 0501, 0101-0145
                            SUBSTR(CODE, 1, 4)       AS MIN, /*코드그룹최소코드*/
                            SUBSTR(CODE, 6, 4)       AS MAX, /*코드그룹최대코드*/
                            ACCOUNT_NAME, /*계정과목*/   -- ORA-12704: 문자 집합이 미일치 (VARCHAR2 - NVARCHAR2)(UNISTR(ACCOUNT_NAME)     AS ACCOUNT_NAME -> ACCOUNT_NAME로 수정)
                            CASE
                                WHEN CODE < '0251' THEN    -- 자산이라면 값을 온전히(+-까지) 가져온다
                                    NVL(DEBITS_SUM_BALANCE, 0) - NVL(CREDITS_SUM_BALANCE, 0)
                                WHEN  --CODE NOT LIKE '%-%'OR
                                      CODE BETWEEN '0251' AND '0400' THEN -- 부채와 자본
                                    NVL(CREDITS_SUM_BALANCE, 0) - NVL(DEBITS_SUM_BALANCE, 0)
                            END                      AS BALANCE
                        FROM
                            (   SELECT *
                                FROM TMP_EARLY_STATEMENTS2 A    --TMP_EARLY_STATEMENTS에서 TMP_EARLY_STATEMENTS2로 변경
                                WHERE A.ACCOUNT_PERIOD_NO = P_PERIOD_NO   -- A.ACCOUNT_PERIOD_NO = ACCOUNT_PERIOD_NO 를 A.ACCOUNT_PERIOD_NO = P_PERIOD_NO 로 변경
                            )     -- DETAIL1
                        WHERE ( CODE < '0400' )

-----------------------------------------------------------------------------------------------------


                        UNION ALL

                        SELECT
                            1, -- 이익잉여금
                            ACCOUNT_INNER_CODE                     AS CODE,
                            SUBSTR(ACCOUNT_INNER_CODE, 1, 4)       AS MIN,
                            SUBSTR(ACCOUNT_INNER_CODE, 6, 4)       AS MAX,
                            ACCOUNT_NAME,
                            V_NET_INCOME                           AS BALANCE	--하기 Begin절의 당기 순이익 데이터가 들어옴(동일 데이터 들어옴)
                        FROM ACCOUNT
                        WHERE ACCOUNT_INNER_CODE = '0351-0380'

                        UNION ALL

                        SELECT
                            2, -- 미처분이익잉여금
                            ACCOUNT_INNER_CODE                     AS CODE,
                            SUBSTR(ACCOUNT_INNER_CODE, 1, 4)       AS MIN,
                            SUBSTR(ACCOUNT_INNER_CODE, 6, 4)       AS MAX,
                            ACCOUNT_NAME,
                            V_NET_INCOME                           AS BALANCE	--하기 Begin절의 당기 순이익 데이터가 들어옴(동일 데이터 들어옴)
                        FROM ACCOUNT
                        WHERE ACCOUNT_INNER_CODE = '0377'
                    )
                ORDER BY SUBSTR(CODE, 1, 4), SUBSTR(CODE, 6) DESC NULLS LAST
            )
    ),
--DETAIL TABLE
----------------------------------------------------------------------------------------
-- 위의 테이블(AS DETAIL)에서 LEV이 1인것만 가지고온다.(자산,부채,자본의 합계)
    SUMMARY AS (
        SELECT
            0                            AS LEV,
            CASE CATEGORY
                WHEN '자산'  THEN '0250'
                WHEN '부채'  THEN '0330'
                WHEN '자본'  THEN '0400'
            END                           AS MIN,
            NULL                          AS MAX,
            CASE
                WHEN CATEGORY = '자산'    THEN '0250'
                WHEN CATEGORY = '부채'    THEN '0330'
                WHEN CATEGORY = '자본'    THEN '0400'
            END                              AS ACCOUNT_CODE,
            '총계'                            AS CATEGORY,
            UNISTR(CATEGORY || '총계')        AS ACCOUNT_NAME,
            0                                 AS BALANCE_DETAIL,
            SUM(BALANCE_DETAIL_SUMMARY)              AS BALANCE_DETAIL_SUMMARY
        FROM DETAIL
        WHERE LEV = 1
        GROUP BY CATEGORY

    )
--WITH절 끝
------------------------------------------------------------------------------------
    SELECT

        LEV,        /*레벨링*/
        CATEGORY,     /*계정과목최상위제목*/
        ACCOUNT_NAME,     /*계정과목*/
        BALANCE_DETAIL,   /*세부금액*/
        BALANCE_DETAIL_SUMMARY,  /*합계금액*/
        P_PERIOD_NO AS PERIOD_NO, /*기수넘버*/
        ACCOUNT_CODE      /*계정코드*/

    FROM
        (
            SELECT* FROM DETAIL

            UNION ALL

            SELECT * FROM SUMMARY

            UNION ALL

            SELECT
                0                     AS LEV,					-- DETAIL테이블에 0계층(합계)의 정보를 추가. 실행문에서 UNION ALL하려고 칼럼갯수 맞춰줌
                '9999-9999'              AS ACCOUNT_CODE,
                '9999'                   AS MIN,
                NULL                     AS MAX,
                CATEGORY,
                UNISTR('부채 및 자본 총계')     AS ACCOUNT_NAME,
                0                        AS BALANCE_DETAIL,
                SUM(BALANCE_DETAIL_SUMMARY)     AS BALANCE_DETAIL_SUMMARY
            FROM SUMMARY
            WHERE MIN != '0250'
            GROUP BY CATEGORY
        );

    TYPE FINANCIAL_POSITION_TYPE IS RECORD (
        LEV              NUMBER(38),
        CATEGORY         NVARCHAR2(20),
        ACCOUNT_NAME     NVARCHAR2(20),
        BALANCE_DETAIL   NUMBER(38),
        BALANCE_DETAIL_SUMMARY  NUMBER(38),
        PERIOD_NO   VARCHAR2(2),
        ACCOUNT_CODE     VARCHAR2(20)
    );

    FINANCIAL_POSITION  FINANCIAL_POSITION_TYPE;

    BEGIN
            -- P_TMP_EARLY_STATEMENTS(P_PERIOD_NO); -- 당기 합계잔액시산표 호출로 TMP 테이블에 저장
            -- P_TMP_INCOME_STATEMENT(P_PERIOD_NO); -- 당기 손익계산서 호출로 TMP 테이블에 저장
    SELECT SUM(INCOME_SUMMARY)INTO V_NET_INCOME FROM INCOME_STATEMENT	--기수에 해당하는 당기 순이익 데이터 가져옴!!
    WHERE PERIOD_NO IN ( P_PERIOD_NO )
          AND ACCOUNT_INNER_CODE = '10';

            --SELECT SUM(INCOME_SUMMARY) INTO INCOME
            --FROM (
            --    -- 기존 당기순이익 호출문
            --    -- SELECT * FROM INCOME_STATEMENT WHERE INCOME_STATEMENT.PERIOD_NO = P_PERIOD_NO)
            --    SELECT * FROM TMP_INCOME_STATEMENTS )
            --WHERE ACCOUNT_INNER_CODE = '10';
            --SELECT SUM(INCOME_SUMMARY) INTO PRE_INCOME
            --FROM (SELECT * FROM INCOME_STATEMENT I WHERE I.PERIOD_NO = P_PERIOD_NO-1 AND ACCOUNT_INNER_CODE = '10');
            --WHERE ACCOUNT_INNER_CODE = '10';

            -- V_NET_INCOME
            -- 손익계산서 결과 테이블 INCOME_STATEMENT 에서 10번 항목의  당기순이익 및 전기순이익을 가져온다.
            -- V_NET_INCOME은 결국 당기와 전기의 순이익의 합친 금액이 나온다.

    DELETE FROM TMP_FINANCIAL_POSITIONS;

    OPEN GET_FINANCIAL_POSITION;
    LOOP
        FETCH GET_FINANCIAL_POSITION INTO FINANCIAL_POSITION;
        EXIT WHEN GET_FINANCIAL_POSITION%NOTFOUND;
        INSERT INTO TMP_FINANCIAL_POSITIONS VALUES (

             -- TMP 테이블에 저장
        FINANCIAL_POSITION.PERIOD_NO,
        FINANCIAL_POSITION.LEV,
        FINANCIAL_POSITION.CATEGORY,
        FINANCIAL_POSITION.ACCOUNT_NAME,
        FINANCIAL_POSITION.BALANCE_DETAIL,
        FINANCIAL_POSITION.BALANCE_DETAIL_SUMMARY,
        FINANCIAL_POSITION.ACCOUNT_CODE
        );

    END LOOP;

END P_TMP_FINANCIAL_POSITION;
/

