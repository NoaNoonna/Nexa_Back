create PROCEDURE          P_BUDGET_COMPARISON(
v_account_period_no in budget.ACCOUNT_PERIOD_NO%type,
v_account_inner_code IN budget.ACCOUNT_INNER_CODE%type,
v_workplace_code in budget.workplace_code%type,
v_dept_code in budget.dept_code%type,
RESULT OUT SYS_REFCURSOR
)
IS BEGIN


OPEN RESULT FOR

SELECT
DECODE (a.budget_date, NULL,'1분기', a.budget_date) budget_date,
SUM(a.app_budget) app_budget,
SUM(a.org_budget) org_budget,
SUM(b.exec_perform) exec_perform,
SUM(NVL(a.org_budget, 0)-NVL(b.exec_perform, 0)) budget_account_comparison

FROM (
   SELECT DECODE(a.budget_date,null, b.budget_date, a.budget_date) budget_date, a.org_budget, b.app_budget FROM

      (SELECT DECODE(budget_date, 'M1_BUDGET', '1월', 'M2_BUDGET', '2월', 'M3_BUDGET', '3월') budget_date, org_budget
            FROM budget UNPIVOT (org_budget FOR budget_date IN(M1_BUDGET, M2_BUDGET, M3_BUDGET))
            WHERE
            BUDGETING_CODE = 2 AND
            ACCOUNT_PERIOD_NO = v_account_period_no AND        -- 연도
            DEPT_CODE = v_dept_code AND      -- 부서
            WORKPLACE_CODE = v_workplace_code AND   -- 사업장
            ACCOUNT_INNER_CODE = v_account_inner_code      -- 계정코드

            ) a
   FULL join
      (SELECT app_budget, DECODE(budget_date, 'M1_BUDGET', '1월', 'M2_BUDGET', '2월', 'M3_BUDGET', '3월') budget_date
            FROM budget UNPIVOT (app_budget FOR budget_date IN(M1_BUDGET, M2_BUDGET, M3_BUDGET))
            WHERE
            BUDGETING_CODE = 1 AND
            ACCOUNT_PERIOD_NO = v_account_period_no AND        -- 연도
            DEPT_CODE = v_dept_code AND        -- 부서
            WORKPLACE_CODE = v_workplace_code AND   -- 사업장
            ACCOUNT_INNER_CODE = v_account_inner_code-- 계정코드
            ) b
   ON a.budget_date=b.budget_date
   ) a,
    (
   SELECT
      DECODE(SUBSTR(j.SLIP_NO, 5, 2), '01', '1월', '02', '2월', '03', '3월') budget_date,
      SUM(j.LEFT_DEBTOR_PRICE) exec_perform
      FROM JOURNAL j, SLIP s
      WHERE j.ACCOUNT_INNER_CODE = v_account_inner_code AND      -- 계정 코드
      j.BALANCE_DIVISION = '차변' AND
      s.SLIP_NO = j.SLIP_NO AND
      s.ACCOUNT_PERIOD_NO = v_account_period_no             -- 년도
      GROUP BY DECODE(SUBSTR(j.SLIP_NO, 5, 2), '01', '1월', '02', '2월', '03', '3월')
      ) b
   WHERE a.budget_date = b.budget_date(+)
   GROUP BY ROLLUP(a.budget_date)

UNION ALL

SELECT
DECODE (a.budget_date, NULL,'2분기', a.budget_date) budget_date,
SUM(a.app_budget) app_budget,
SUM(a.org_budget) org_budget,
SUM(b.exec_perform) exec_perform,
SUM(NVL(a.org_budget, 0)-NVL(b.exec_perform, 0)) budget_account_comparison

FROM (
   SELECT DECODE(a.budget_date,null, b.budget_date, a.budget_date) budget_date, a.org_budget, b.app_budget FROM

      (SELECT DECODE(budget_date, 'M4_BUDGET', '4월', 'M5_BUDGET', '5월', 'M6_BUDGET', '6월') budget_date, org_budget
            FROM budget UNPIVOT (org_budget FOR budget_date IN(M4_BUDGET, M5_BUDGET, M6_BUDGET))
            WHERE
            BUDGETING_CODE = 2 AND
            ACCOUNT_PERIOD_NO = v_account_period_no AND        -- 연도
            DEPT_CODE = v_dept_code AND      -- 부서
            WORKPLACE_CODE = v_workplace_code AND   -- 사업장
            ACCOUNT_INNER_CODE = v_account_inner_code      -- 계정코드

            ) a
   FULL join
      (SELECT app_budget, DECODE(budget_date, 'M4_BUDGET', '4월', 'M5_BUDGET', '5월', 'M6_BUDGET', '6월') budget_date
            FROM budget UNPIVOT (app_budget FOR budget_date IN(M4_BUDGET, M5_BUDGET, M6_BUDGET))
            WHERE
            BUDGETING_CODE = 1 AND
            ACCOUNT_PERIOD_NO = v_account_period_no AND        -- 연도
            DEPT_CODE = v_dept_code AND        -- 부서
            WORKPLACE_CODE = v_workplace_code AND   -- 사업장
            ACCOUNT_INNER_CODE = v_account_inner_code-- 계정코드
            ) b
   ON a.budget_date=b.budget_date
   ) a,
    (
   SELECT
      DECODE(SUBSTR(j.SLIP_NO, 5, 2), '04', '4월', '05', '5월', '06', '6월') budget_date,
      SUM(j.LEFT_DEBTOR_PRICE) exec_perform
      FROM JOURNAL j, SLIP s
      WHERE j.ACCOUNT_INNER_CODE = v_account_inner_code AND      -- 계정 코드
      j.BALANCE_DIVISION = '차변' AND
      s.SLIP_NO = j.SLIP_NO AND
      s.ACCOUNT_PERIOD_NO = v_account_period_no             -- 년도
      GROUP BY DECODE(SUBSTR(j.SLIP_NO, 5, 2), '04', '4월', '05', '5월', '06', '6월')
      ) b
   WHERE a.budget_date = b.budget_date(+)
   GROUP BY ROLLUP(a.budget_date)

UNION ALL

SELECT
DECODE (a.budget_date, NULL,'3분기', a.budget_date) budget_date,
SUM(a.app_budget) app_budget,
SUM(a.org_budget) org_budget,
SUM(b.exec_perform) exec_perform,
SUM(NVL(a.org_budget, 0)-NVL(b.exec_perform, 0)) budget_account_comparison

FROM (
   SELECT DECODE(a.budget_date,null, b.budget_date, a.budget_date) budget_date, a.org_budget, b.app_budget FROM

      (SELECT DECODE(budget_date, 'M7_BUDGET', '7월', 'M8_BUDGET', '8월', 'M9_BUDGET', '9월') budget_date, org_budget
            FROM budget UNPIVOT (org_budget FOR budget_date IN(M7_BUDGET, M8_BUDGET, M9_BUDGET))
            WHERE
            BUDGETING_CODE = 2 AND
            ACCOUNT_PERIOD_NO= v_account_period_no AND        -- 연도
            DEPT_CODE = v_dept_code AND      -- 부서
            WORKPLACE_CODE = v_workplace_code AND   -- 사업장
            ACCOUNT_INNER_CODE = v_account_inner_code      -- 계정코드

            ) a
   FULL join
      (SELECT app_budget, DECODE(budget_date, 'M7_BUDGET', '7월', 'M8_BUDGET', '8월', 'M9_BUDGET', '9월') budget_date
            FROM budget UNPIVOT (app_budget FOR budget_date IN(M7_BUDGET, M8_BUDGET, M9_BUDGET))
            WHERE
            BUDGETING_CODE = 1 AND
            ACCOUNT_PERIOD_NO = v_account_period_no AND        -- 연도
            DEPT_CODE = v_dept_code AND        -- 부서
            WORKPLACE_CODE = v_workplace_code AND   -- 사업장
            ACCOUNT_INNER_CODE = v_account_inner_code-- 계정코드
            ) b
   ON a.budget_date=b.budget_date
   ) a,
    (
   SELECT
      DECODE(SUBSTR(j.SLIP_NO, 5, 2), '07', '7월', '08', '8월', '09', '9월') budget_date,
      SUM(j.LEFT_DEBTOR_PRICE) exec_perform
      FROM JOURNAL j, SLIP s
      WHERE j.ACCOUNT_INNER_CODE = v_account_inner_code AND      -- 계정 코드
      j.BALANCE_DIVISION = '차변' AND
      s.SLIP_NO = j.SLIP_NO AND
      s.ACCOUNT_PERIOD_NO = v_account_period_no             -- 년도
      GROUP BY DECODE(SUBSTR(j.SLIP_NO, 5, 2), '07', '7월', '08', '8월', '09', '9월')
      ) b
   WHERE a.budget_date = b.budget_date(+)
   GROUP BY ROLLUP(a.budget_date)

UNION ALL

SELECT
DECODE (a.budget_date, NULL,'4분기', a.budget_date) budget_date,
SUM(a.app_budget) app_budget,
SUM(a.org_budget) org_budget,
SUM(b.exec_perform) exec_perform,
SUM(NVL(a.org_budget, 0)-NVL(b.exec_perform, 0)) budget_account_comparison

FROM (
   SELECT DECODE(a.budget_date,null, b.budget_date, a.budget_date) budget_date, a.org_budget, b.app_budget FROM

      (SELECT DECODE(budget_date, 'M10_BUDGET', '10월', 'M11_BUDGET', '11월', 'M12_BUDGET', '12월') budget_date, org_budget
            FROM budget UNPIVOT (org_budget FOR budget_date IN(M10_BUDGET, M11_BUDGET, M12_BUDGET))
            WHERE
            BUDGETING_CODE = 2 AND
            ACCOUNT_PERIOD_NO = v_account_period_no AND        -- 연도
            DEPT_CODE = v_dept_code AND      -- 부서
            WORKPLACE_CODE = v_workplace_code AND   -- 사업장
            ACCOUNT_INNER_CODE = v_account_inner_code      -- 계정코드

            ) a
   FULL join
      (SELECT app_budget, DECODE(budget_date, 'M10_BUDGET', '10월', 'M11_BUDGET', '11월', 'M12_BUDGET', '12월') budget_date
            FROM budget UNPIVOT (app_budget FOR budget_date IN(M10_BUDGET, M11_BUDGET, M12_BUDGET))
            WHERE
            BUDGETING_CODE = 1 AND
            ACCOUNT_PERIOD_NO = v_account_period_no AND        -- 연도
            DEPT_CODE = v_dept_code AND        -- 부서
            WORKPLACE_CODE = v_workplace_code AND   -- 사업장
            ACCOUNT_INNER_CODE = v_account_inner_code-- 계정코드
            ) b
   ON a.budget_date=b.budget_date
   ) a,
    (
   SELECT
      DECODE(SUBSTR(j.SLIP_NO, 5, 2), '10', '10월', '11', '11월', '12', '12월') budget_date,
      SUM(j.LEFT_DEBTOR_PRICE) exec_perform
      FROM JOURNAL j, SLIP s
      WHERE j.ACCOUNT_INNER_CODE = v_account_inner_code AND      -- 계정 코드
      j.BALANCE_DIVISION = '차변' AND
      s.SLIP_NO = j.SLIP_NO AND
      s.ACCOUNT_PERIOD_NO= v_account_period_no             -- 년도
      GROUP BY DECODE(SUBSTR(j.SLIP_NO, 5, 2), '10', '10월', '11', '11월', '12', '12월')
      ) b
   WHERE a.budget_date = b.budget_date(+)
   GROUP BY ROLLUP(a.budget_date);


END P_BUDGET_COMPARISON;
/

