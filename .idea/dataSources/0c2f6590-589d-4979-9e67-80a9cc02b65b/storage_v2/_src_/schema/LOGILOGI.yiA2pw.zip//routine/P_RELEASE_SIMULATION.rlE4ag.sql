create PROCEDURE          "P_RELEASE_SIMULATION" ( --외주 자재 출고 모의전개
    -- 매개변수 선언부
    v_mrp_gathering_no     IN           VARCHAR2 -- 뷰단에서 파라메터 값으로 받아온 mrpGatheringNo
    ,
    v_id in varchar2,
    v_seq in number,
    error_code   OUT          NUMBER -- 에러코드
    ,
    error_msg    OUT          VARCHAR2 -- 에러메세지
    ,
    result       OUT          SYS_REFCURSOR -- 결과 값 반환 커서
) IS

v_required_amount number;

BEGIN


       DELETE FROM RELEASE_SIMUL_TEMP
       where
       id = v_id
       and
       seq = v_seq;


        select
        OUTSOURC_AMOUNT
        into
        v_required_amount
        from OUTSOURC_INFO  --외주자재 출고 목록에서 외주 넣은  수량 가져옴~
        where
        mrp_gathering_no = v_mrp_gathering_no;


    INSERT INTO RELEASE_SIMUL_TEMP
    --동작: with절을 포함한 select절을 TEMP에 담아 뷰단에 뿌린다.
        SELECT
            *
        FROM
            (
                WITH stock_amount AS (
                    SELECT
                        item_code,
                        ( stock_amount+DELIVERY_AMOUNT - safety_allowance_amount ) stock_amount,
                        to_char(input_amount+stock.delivery_amount) input_amount
                    FROM
                        stock
                ),


                         --작업지시 해당 제품 정보 테이블(완제품 OR 반제품)
                 work_order_simul_item AS (
                    SELECT
                        mrp_gathering_seq,
                        item_code,
                        item_name
                    FROM
                        mrp_gathering
                    WHERE
                        mrp_gathering_no =  v_mrp_gathering_no--작업지시 필요 목록에서 선택된 일련번호.
                ),


                         -- 선택 제품의 BOM 전개 후 하위품목(원재료) 리스트.
                 item_list AS (
                    SELECT
                        bom.item_code,
                        level,
                        bom.net_amount
                    FROM
                        bom,
                        work_order_simul_item
                    START WITH
                        bom.parent_item_code = work_order_simul_item.item_code
                    CONNECT BY PRIOR bom.item_code = bom.parent_item_code
                               AND level = 1
--WHERE PARENT_ITEM_CODE = WORK_ORDER_SIMUL_ITEM.ITEM_CODE
                ),
               mrp_list as
               (select*from mrp
where mps_no in
(select
mps_no
from mrp
where
mrp_gathering_no= v_mrp_gathering_no)
order by mrp_no),
all_material as(
                select
                min(m.mrp_gathering_no) mrp_gathering_no,
                min(m.item_classification) item_classification,
                min(m.item_code) item_code,
                trim(min(m.item_name)) item_name,
                min(m.unit_of_mrp) unit_of_mrp,
                to_char(min(sa.input_amount)) input_amount, --투입예정재고량
case
when
m.item_code in (
SELECT
b.ITEM_CODE AS ITEM_CODE  -- 품목코드
FROM
(
            --주생산계획 수립된 물품의 코드를 받아서 해당 아이템의 하위아이템 정전개,
SELECT
LEVEL lvl,  --LEVEL
CONNECT_BY_ROOT ITEM_CODE || ' -' || TO_CHAR(ROWNUM, '000') AS BOM_NO,
            --임의의 BOM_NO 생성(DK-AP01-001, DK-AP01-002,...)
ITEM_CODE,      --품목코드
NET_AMOUNT      --정미수량: LOSS율을 감안하지 않는 수량이다
FROM BOM
START WITH ITEM_CODE=
(
select item_code
from mrp_gathering
where
mrp_gathering_no=v_mrp_gathering_no
and
item_code in (select item_code from item where item_classification='IT-SI')
) -- V_MPS_ITEM_CODE
CONNECT BY PRIOR item_code=parent_item_code
) b,
ITEM i
WHERE b.item_code=i.item_code)
then
to_char(max(v_required_amount*i.net_amount))
else
to_char(sum(m.required_amount))
end required_amount,

case
when
m.item_code in (
SELECT
b.ITEM_CODE AS ITEM_CODE  -- 품목코드
FROM
(
            --주생산계획 수립된 물품의 코드를 받아서 해당 아이템의 하위아이템 정전개,
SELECT
LEVEL lvl,  --LEVEL
CONNECT_BY_ROOT ITEM_CODE || ' -' || TO_CHAR(ROWNUM, '000') AS BOM_NO,
            --임의의 BOM_NO 생성(DK-AP01-001, DK-AP01-002,...)
ITEM_CODE,      --품목코드
NET_AMOUNT      --정미수량: LOSS율을 감안하지 않는 수량이다
FROM BOM
START WITH ITEM_CODE=
(
select item_code
from mrp_gathering
where
mrp_gathering_no=v_mrp_gathering_no
and
item_code in (select item_code from item where item_classification='IT-SI')
) -- V_MPS_ITEM_CODE
CONNECT BY PRIOR item_code=parent_item_code
) b,
ITEM i
WHERE b.item_code=i.item_code)
then
to_char(min(sa.input_amount)-max(v_required_amount*i.net_amount))
else
to_char(min(sa.input_amount)-sum(m.required_amount))
end stock_after_work,
                min(m.order_date) order_date,
                min(m.required_date) required_date
                from
                mrp_list m,
                item_list i,
                stock_amount sa
                where
                m.item_code=i.item_code
                and
                i.item_code=sa.item_code
                group by m.item_code

                    UNION ALL
                    SELECT
                        wot.mrp_gathering_no,
                        wot.ORDER_OR_PRODUCTION_STATUS,
                        wot.item_code,
                        TRIM(wot.item_name) item_name,
                        wot.UNIT_OF_MRP_GATHERING unit_of_mrp_gathering,
                        '0',
                        to_char(wot.OUTSOURC_AMOUNT) necessary_amount,
                        '0',
                        wot.CLAIM_DATE order_date,
                        wot.DUE_DATE required_date
                    FROM
                         OUTSOURC_INFO wot
                    WHERE
                        wot.mrp_gathering_no =  v_mrp_gathering_no),
temp_data as (
select
mrp_gathering_no,
item_classification,
item_code,
item_name,
unit_of_mrp,
input_amount,
required_amount,
decode(sign(stock_after_work),-1,'재고부족',stock_after_work) stock_after_work,
order_date,
required_date
from
all_material)----------------TEMP_DATA 선언끝
                SELECT
                    mrp_gathering_no,
                    item_classification,
                    item_code,
                    item_name,
                    unit_of_mrp,
                    input_amount,
                    required_amount,
                    stock_after_work,
                    order_date,
                    required_date,
                    v_id id,
                    v_seq seq
                FROM
                    temp_data
                ORDER BY
                    mrp_gathering_no
            );

-- 성공시 커밋

    COMMIT;
    error_code := '0';
    error_msg := 'SUCCESS';
    OPEN result FOR SELECT
                        *
                    FROM
                        RELEASE_SIMUL_TEMP
                        where
                        id = v_id
                        and
                        seq = v_seq;

-- 예외 발생시

EXCEPTION
    WHEN no_data_found THEN
        dbms_output.put_line('NO_DATA_FOUND');
        error_code := '-1';
        error_msg := '데이터를 찾을 수 없습니다!';
        return;
    WHEN dup_val_on_index THEN
        dbms_output.put_line('DUP_VAL_ON_INDEX');
        error_code := '-1';
        error_msg := '고유값이 중복됩니다!';
        return;
    WHEN OTHERS THEN
        dbms_output.put_line('오류가 발생했습니다');
        dbms_output.put_line('SQL ERROR CODE: ' || sqlcode);
        dbms_output.put_line('SQL ERROR MESSAGE: ' || sqlerrm);
        error_code := '-1';
        error_msg := 'SQL ERROR CODE: '
                     || sqlcode
                     || 'SQL ERROR MESSAGE: '
                     || sqlerrm;
        return;

-- PROCEDURE 끝
END;
/

