create PROCEDURE P_DAY_WORKER_SALARY --일급을 계산하는 프로시저 -21년 크리스마스 이브,,ys
(
       P_EMP_CODE      IN DAY_WORKER_SALARY.EMP_CODE%TYPE
      ,P_EMP_NAME      IN DAY_WORKER_SALARY.EMP_NAME%TYPE
      ,P_WORK_TIME     IN DAY_WORKER_SALARY.WORK_TIME%TYPE    --근무시간
       ,P_ERROR_CODE    OUT VARCHAR2 -- 출력매개변수, 호출한곳으로리턴되는값
      ,P_ERROR_MSG     OUT VARCHAR2
       ,RESULT          OUT SYS_REFCURSOR  --일급이 담긴다. //테이블에 일급을 담는다.
)
IS
    V_DAY_WORKER_SALARY NUMBER; --일급이 저장되는 변수
    V_EMP_CODE DAY_WORKER_SALARY.EMP_NAME%TYPE;
    V_EMP_NAME DAY_WORKER_SALARY.EMP_NAME%TYPE;
    V_EMP_CODE_NAME_SAME NUMBER; -- 직원코드랑 직원명이 같을 경우 조건을 위한 변수
    
BEGIN
--2021년 최저시급 8700원, 주 40시간 근무 => 181만 8천 300원
--2022년 최저시급 9160원, 주 40시간 근무 => 191만 4천 440원
--입사 날짜를 가져와서 그에 맞춰 최저시급으로 일급을 계산할까 --연말되면 시퀀스 값을 올려서 계산.
--아니면 사원등록할 때 입력받은 값을 테이블에서 가져와 계산할까 --> 쉬운 걸로 간다.
   
    SELECT COUNT(*)  --급여테이블에 입력된 사원코드와 사원명이 검색명과 같을 때
    INTO V_EMP_CODE_NAME_SAME
    FROM DAY_WORKER_SALARY
    WHERE EMP_CODE=P_EMP_CODE AND EMP_NAME=P_EMP_NAME;
   
   OPEN RESULT FOR
   
    SELECT( TIME_SALARY * P_WORK_TIME -(TIME_SALARY * P_WORK_TIME * (3.3/100))) --일급
   INTO V_DAY_WORKER_SALARY
   FROM NEW_DAY_WORKER
    WHERE EMP_CODE=P_EMP_CODE AND EMP_NAME=P_EMP_NAME;
   CLOSE RESULT;
   
   
   --해당 사원의 급여테이블에 데이터가 저장되야 함. 
   IF V_EMP_CODE_NAME_SAME = 1 then
    UPDATE DAY_WORKER_SALARY SET WORK_TIME =P_WORK_TIME, DAY_SALARY= V_DAY_WORKER_SALARY 
    WHERE EMP_CODE=P_EMP_CODE AND EMP_NAME=P_EMP_NAME;
    end if;      
    
   EXCEPTION
      WHEN NO_DATA_FOUND
        THEN
          P_ERROR_CODE := -1;
          P_ERROR_MSG := '조회할 데이터가 없습니다.';
      WHEN OTHERS
        THEN
          P_ERROR_CODE := -2;
          P_ERROR_MSG := SQLERRM;
END P_DAY_WORKER_SALARY;
/

