create PROCEDURE          NEW_TOTAL_TRIAL_BALANCE(
  V_FROM_DATE in slip.reporting_date%type,
  V_TO_DATE in slip.reporting_date%type,
  ERROR_CODE OUT NUMBER,
  ERROR_MSG OUT VARCHAR2,
  RESULT OUT SYS_REFCURSOR
)
is
BEGIN

open result for
--계층형 쿼리
--account 테이블이랑 계정 과목 번호로 조인 하기
--계정 과목 코드를 기준으로 계층 출력하기

  select
  decode(account_name,'계정',null,rownum) r_cnt,
  LEFT_BALANCE,
  SUM_LEFT_DEBTOR_PRICE,
  decode(level,2,'<<',3,decode(type,3,'[','<'),4,decode(type,3,'<'))||
  decode(ACCOUNT_NAME,'계정','합계',account_name)
  ||decode(level,2,'>>',3,decode(type,3,']','>'),4,decode(type,3,'>'))
  account_name,
  SUM_RIGHT_CREDITS_PRICE,
  RIGHT_BALANCE
  from
    (select
    decode(r_cnt,1,type,1) type,                              --합계의 type은 숫자 1로 통일
    decode(r_cnt,1,account_code,'0101-1000') account_code,    --복제된 테이블의 계정 과목을 '0101-1000'으로 통일
    sum(left_balance) left_balance,
    sum(SUM_LEFT_DEBTOR_PRICE) SUM_LEFT_DEBTOR_PRICE,
    sum(RIGHT_BALANCE) RIGHT_BALANCE,
    sum(SUM_RIGHT_CREDITS_PRICE) SUM_RIGHT_CREDITS_PRICE
    from
      (select
      type,
      account_code,

      --차변 잔액
      decode(sign(sum_left_debtor_price-sum_right_credits_price),1,sum_left_debtor_price-sum_right_credits_price,0) left_balance,
      sum_left_debtor_price,

      --대변 잔액
      decode(sign(sum_right_credits_price-sum_left_debtor_price),1,sum_right_credits_price-sum_left_debtor_price,0) right_balance,
      sum_right_credits_price
      from
          (select
          decode(a4.account_inner_code,'0101-1000',2,3) type,                 --상위 계정이 3단계인지 2단계인지 나타내는 칼럼
          decode(a1.account_inner_code,null,
          decode(a2.account_inner_code,null,
          decode(a3.account_inner_code,null,
          a4.account_inner_code,
          a3.account_inner_code),
          a2.account_inner_code),
          a1.account_inner_code) account_code,                                --단계별 계정 과목을 한 칼럼에 표현하기 위함 decode 함수
          sum(nvl(left_debtor_price,0)) sum_left_debtor_price,                --차변 null 값 0으로 변환
          sum(nvl(right_credits_price,0)) sum_right_credits_price             --대변 null 값 0으로 변환
          from journal j,slip s,account a1,account a2,account a3,account a4   --상위 계정 3단계까지 조인
          where
          j.slip_no=s.slip_no
          and s.slip_status='승인'
          and balance_division is not null
          and j.account_inner_code is not null
          and j.account_inner_code=a1.account_inner_code
          and a1.parent_account_inner_code=a2.account_inner_code(+)
          and a2.parent_account_inner_code=a3.account_inner_code(+)
          and a3.parent_account_inner_code=a4.account_inner_code(+)
          and to_date(reporting_date) between to_date(V_FROM_DATE) and to_date(V_TO_DATE)
          group by rollup(
          a4.account_inner_code,
          a3.account_inner_code,
          a2.account_inner_code,
          a1.account_inner_code))
      where account_code<>'0101-1000' and account_code is not null) a,      --account_code가 '0101-1000'이거나 null인 레코드 삭제
      (select rownum r_cnt from account where rownum<3) b                   --테이블 복제
    where
    r_cnt=1 or account_code not like '%-%'                                --r_cnt가 2가 아니면서 account_code가 '%-%'가 아닌 레코드들을 출력
    group by                                                              --type 칼럼과 account_code의 조합으로 grouping 하기
    decode(r_cnt,1,type,1),
    decode(r_cnt,1,account_code,'0101-1000')) a,
    account b                                                       --account 테이블과 조인하기
  where a.account_code=b.account_inner_code
  start with b.parent_account_inner_code is null                  --계정 과목 코드를 기준으로 계층 출력하기
  connect by prior a.account_code=b.parent_account_inner_code
  order by to_number(r_cnt) nulls last;

ERROR_CODE := 0;
  ERROR_MSG := '합계잔액시산표 성공';

EXCEPTION
  WHEN NO_DATA_FOUND
    THEN
      ERROR_CODE := -1;
      ERROR_MSG := '조회할 데이터가 없습니다.';
  WHEN OTHERS
    THEN
      ERROR_CODE := -2;
      ERROR_MSG := SQLERRM;
END NEW_TOTAL_TRIAL_BALANCE;
/

