create PROCEDURE         "P_WAREHOUSING" -- 프로시저명
        (
        V_ORDER_NO_LIST IN VARCHAR2 -- ORDER_DIALOG_OPEN 진행할 ORDER 넘버 발주일련번호
        , ERROR_CODE OUT NUMBER -- 에러코드
        , ERROR_MSG OUT VARCHAR2 -- 에러메세지
        )
-- 변수 상수 선언부 시작
IS

-- 커서선언시작
-- 커서에는 뷰단에서 넘어온 ORDER NO를 통해서 각각에 해당하는 모든 정보를 ORDER_INFO에서 받아온다
-- ORDER_NO, ORDER_DATE, ORDER_INFO_STATUS, ORDER_SORT, ITEM_CODE, ITEM_NAME, ORDER_AMOUNT 정보가 담겨 있다
CURSOR C_WAREHOUSING_LIST
IS
    WITH ORDER_NO_STR AS
    (
    SELECT
    V_ORDER_NO_LIST -- V_MRP_NO_LIST
    FROM
    DUAL
    ),
    ORDER_NO_LIST AS
    (
    SELECT
    TRIM( REGEXP_SUBSTR( (SELECT * FROM ORDER_NO_STR ) ,'[^,]+', 1, LEVEL ) ) ORDER_NO
    FROM
    DUAL
    CONNECT BY REGEXP_SUBSTR( (SELECT * FROM ORDER_NO_STR ) , '[^,]+', 1, LEVEL ) IS NOT NULL
    ),
    WAREHOUSING_LIST AS
    (
    SELECT *
    FROM ORDER_INFO
    WHERE ORDER_NO IN ( SELECT ORDER_NO FROM ORDER_NO_LIST )
    )
    SELECT * FROM WAREHOUSING_LIST;
    -- 커서끝
-- 변수 상수 선언부 끝

-- 실행부 시작
BEGIN

-- 커서 LOOP문 시작
FOR V_WAREHOUSING_ROW IN C_WAREHOUSING_LIST
LOOP

    -- IF문 으로 발주종류 구분하여 취합발주는 투입예정재고로 임의발주는 재고로 이동
    -- STOCK_LOG 테이블에 등록 (등록 되는값 발주종류에 따라 다름)
    -- 취합발주의 경우
    IF V_WAREHOUSING_ROW.ORDER_SORT = '취합발주' THEN
    UPDATE
    STOCK
    SET
    -- 재고테이블의 입고예정재고량에서 입고량만큼 제거
    STOCK.ORDER_AMOUNT = STOCK.ORDER_AMOUNT - V_WAREHOUSING_ROW.ORDER_AMOUNT,
    -- 소요량취합에 따른 발주로 입고되고나면 작업지시에 들어갈예정이므로 입고량만큼 재고테이블의 투입예정재고량에 추가
    STOCK.INPUT_AMOUNT = STOCK.INPUT_AMOUNT + V_WAREHOUSING_ROW.ORDER_AMOUNT
    WHERE
    -- 입고되는 품목과 STOCK 테이블의 품목 코드 이름 일치시키기
    V_WAREHOUSING_ROW.ITEM_CODE=STOCK.ITEM_CODE
    AND V_WAREHOUSING_ROW.ITEM_NAME=STOCK.ITEM_NAME;

    INSERT INTO STOCK_LOG VALUES
    ('입고재고투입예정','입고예정재고에서 투입예정재고로 이동',TO_CHAR(SYSDATE,'YYYY-MM-DD HH24:MI:SS'),
    V_WAREHOUSING_ROW.ITEM_CODE,V_WAREHOUSING_ROW.ITEM_NAME,V_WAREHOUSING_ROW.ORDER_AMOUNT,'취합발주 입고');

    -- 임의발주의 경우
    ELSIF V_WAREHOUSING_ROW.ORDER_SORT = '임의발주' THEN
    UPDATE STOCK
    SET
    -- 재고테이블의 입고예정재고량에서 입고량만큼 제거
    STOCK.ORDER_AMOUNT = STOCK.ORDER_AMOUNT - V_WAREHOUSING_ROW.ORDER_AMOUNT,
    -- 임의발주는 투입예정된 재고가 아니므로 입고량만큼 재고량에 추가
    STOCK.STOCK_AMOUNT = STOCK.STOCK_AMOUNT + V_WAREHOUSING_ROW.ORDER_AMOUNT
    WHERE
    -- 입고되는 품목과 STOCK 테이블의 품목 코드 이름 일치시키기
    V_WAREHOUSING_ROW.ITEM_CODE=STOCK.ITEM_CODE
    AND V_WAREHOUSING_ROW.ITEM_NAME=STOCK.ITEM_NAME;

    INSERT INTO STOCK_LOG VALUES
    ('임의발주입고','입고예정재고에서 재고로 이동',TO_CHAR(SYSDATE,'YYYY-MM-DD HH24:MI:SS'),
    V_WAREHOUSING_ROW.ITEM_CODE,V_WAREHOUSING_ROW.ITEM_NAME,V_WAREHOUSING_ROW.ORDER_AMOUNT,'임의발주 입고');

    END IF;

    -- ORDER_INFO_STATUS는 '입고완료' 로 변경
    UPDATE
    ORDER_INFO
    SET
    ORDER_INFO_STATUS = '입고완료'
    WHERE
    ORDER_NO = V_WAREHOUSING_ROW.ORDER_NO;

END LOOP;
-- 실행부 끝

       -- 성공시 커밋
       COMMIT;

       ERROR_CODE := '0';
       ERROR_MSG := '입고완료// 작업지시로 가시오';

   -- 예외 발생시
   EXCEPTION
   WHEN NO_DATA_FOUND THEN
       DBMS_OUTPUT.PUT_LINE('NO_DATA_FOUND');
       ERROR_CODE := '-1';

       ERROR_MSG := 'NO_DATA_FOUND';
       RETURN;
   WHEN DUP_VAL_ON_INDEX THEN
       DBMS_OUTPUT.PUT_LINE('DUP_VAL_ON_INDEX');
       ERROR_CODE := '-1';
       ERROR_MSG := 'DUP_VAL_ON_INDEX';
       RETURN;
   WHEN OTHERS THEN
       DBMS_OUTPUT.PUT_LINE('OTHERS');
       ERROR_CODE := '-1';
       ERROR_MSG := '관리자에게 문의 하세요 // 01077239513';
       RETURN;

   -- 프로시저끝
   END;
/

