create PROCEDURE          "P_COMPUTE_FINANCIAL_POSITION" --재무상태표 계산
(
    SEARCH_PERIOD_NO IN NUMBER,--4
    IS_EARLY_PERIOD IN NUMBER--3
)
IS
    V_NET_INCOME       NUMBER;
    LAST_PERIOD_NO       NUMBER;
BEGIN
    V_NET_INCOME := NVL(F_NET_INCOME(SEARCH_PERIOD_NO, IS_EARLY_PERIOD), 0) + NVL(F_NET_INCOME(SEARCH_PERIOD_NO - 1, IS_EARLY_PERIOD-1), 0);
    --F_NET_INCOME에서는 손익계산서의 10번  당기순이익을 가져온다.
    --V_NET_INCOME은 결국 당기와 전기의 순이익의 합친 금액이 나온다.
    SELECT MAX(p.ACCOUNT_PERIOD_NO) INTO LAST_PERIOD_NO FROM PERIOD p;
    --                                4                 4

      DELETE FROM FINANCIAL_POSITION A WHERE A.PERIOD_NO = SEARCH_PERIOD_NO;
      INSERT INTO FINANCIAL_POSITION(LEV, CATEGORY, ACCOUNT_NAME, BALANCE_DETAIL, BALANCE_DETAIL_SUMMARY, PERIOD_NO, ACCOUNT_CODE)

    WITH DETAIL AS (
          SELECT LEV,                 /*레벨링*/
                            CODE AS ACCOUNT_CODE,/*계정코드*/
                   MIN,                 /*코드그룹최소코드*/
                   MAX,                 /*코드그룹최대코드*/
                            CATEGORY,            /*계정과목최상위제목*/
                            ACCOUNT_NAME,        /*계정과목*/
                            CASE
                         WHEN LEAD(BALANCE_DETAIL) OVER (ORDER BY 1)!=0 THEN BALANCE  -- LEAD: 이후로우값 반환, OVER(ORDER BY 1): 순차적으로 GROUP BY
                                 ELSE BALANCE_DETAIL
                   END AS BALANCE_DETAIL, /*세부금액*/

                            CASE
                         WHEN LEAD(BALANCE_DETAIL) OVER (ORDER BY 1)!=0 THEN 0
                                 WHEN BALANCE IS NULL THEN LAG(BALANCE) OVER(ORDER BY 1) - BALANCE_DETAIL
                                 ELSE BALANCE
                           END AS BALANCE_SUMMARY /*합계금액*/
            FROM(SELECT LEV,  /*레벨링*/               -- detail3
                            CODE, /*계정코드*/
                            MIN,  /*코드그룹최소코드*/
                            MAX,  /*코드그룹최대코드*/
                            CASE
                                WHEN CODE < '0251' THEN '자산' -- CODE 0251 이하 자산
                                WHEN CODE < '0331' THEN '부채' -- CODE 0331 이하 부채
                                WHEN CODE < '0401' THEN '자본' -- CODE 0401 이하 자본
                            END AS CATEGORY, /*계정과목최상위제목*/
                                          ACCOUNT_NAME, /*계정과목*/
                             CASE
                                WHEN SIGN(SUM(BALANCE))=-1 THEN  ABS(SUM(BALANCE)) -- BALANCE 금액이 음수일 경우 합산 후 절대값으로 변경
                                ELSE 0
                            END AS BALANCE_DETAIL, /*세부금액*/
                                          CASE
                                  WHEN SIGN(SUM(BALANCE))=1 THEN SUM(BALANCE) -- BALANCE 금액이 양수인 경우 합산만 진행
                            END AS BALANCE       /*합계금액*/
                     FROM (
                               SELECT LEV,  /*레벨링*/
                                CODE, /*계정코드*/      -- ex. 0501, 0101-0145
                                SUBSTR(CODE, 1, 4) AS MIN, /*코드그룹최소코드*/
                                SUBSTR(CODE, 6, 4) AS MAX, /*코드그룹최대코드*/
                                ACCOUNT_NAME, /*계정과목*/
                                CASE
                                    WHEN CODE < '0251' THEN    -- 자산이라면 값을 온전히(+-까지) 가져온다
                                        NVL(DEBITS_SUM_BALANCE, 0) - NVL(CREDITS_SUM_BALANCE, 0)
                                    WHEN CODE NOT LIKE '%-%' OR CODE BETWEEN '0251' AND '0400' THEN
                                        CASE
                                            WHEN CREDITS_SUM_BALANCE!=0  --이중조건문   -- 대변잔액에 값이 있을 때(수익,자본,부채), +값을 온전히 가져옴
                                                THEN NVL(CREDITS_SUM_BALANCE, 0) + NVL(DEBITS_SUM_BALANCE, 0) -- 대변 + 차변
                                            WHEN CREDITS_SUM_BALANCE=0          -- 자본부채는 항상 값이 있으므로 비용일때, "-비용"으로 변환시킴
                                                THEN NVL(CREDITS_SUM_BALANCE, 0) - NVL(DEBITS_SUM_BALANCE, 0) -- 대변 - 차변
                                        END
                                END AS BALANCE
                              FROM (SELECT * FROM TOTAL_TRIAL_BALANCE1 A WHERE A.ACCOUNT_PERIOD_NO = SEARCH_PERIOD_NO)     -- detail1
                              WHERE (CODE < '0400')
                              UNION ALL
                              SELECT 1, -- 이익잉여금(당기순이익 + 전기순이익)
                                              ACCOUNT_INNER_CODE AS CODE,
                                              SUBSTR(ACCOUNT_INNER_CODE, 1, 4) AS MIN,
                                             SUBSTR(ACCOUNT_INNER_CODE, 6, 4) AS MAX,
                               ACCOUNT_NAME,
                               V_NET_INCOME AS BALANCE
                              FROM ACCOUNT
                              WHERE ACCOUNT_INNER_CODE = '0351-0380'
                              UNION ALL
                             SELECT 2, -- 미처분이익잉여금(당기순이익 + 전기순이익)
                              ACCOUNT_INNER_CODE AS CODE,
                              SUBSTR(ACCOUNT_INNER_CODE, 1, 4) AS MIN,
                              SUBSTR(ACCOUNT_INNER_CODE, 6, 4) AS MAX,
                              ACCOUNT_NAME,
                              V_NET_INCOME    AS       BALANCE
                    FROM ACCOUNT
                    WHERE ACCOUNT_INNER_CODE = '0377')
                        GROUP BY LEV, CODE, MIN, MAX, ACCOUNT_NAME
                        ORDER BY SUBSTR(CODE, 1, 4),SUBSTR(CODE, 6 ) DESC NULLS LAST
          )
    ),
      SUMMARY AS(
          SELECT 0 AS LEV ,
                   CASE CATEGORY
                                  WHEN '자산' THEN '0250'
                                 WHEN '부채' THEN '0330'
                                 WHEN '자본' THEN '0400'
                           END  AS MIN,
                           NULL AS MAX,
                           CASE
                        WHEN CATEGORY='자산' THEN '0250'
                              WHEN CATEGORY='부채' THEN '0330'
                              WHEN CATEGORY='자본' THEN '0400'
                           END AS ACCOUNT_CODE,
                           '총계' AS CATEGORY,
                           UNISTR(CATEGORY||'총계') AS ACCOUNT_NAME,
                           0 AS BALANCE_DETAIL,
                           SUM(BALANCE_SUMMARY) AS BALANCE_DETAIL_SUMMARY
            FROM DETAIL
            WHERE LEV=1
            GROUP BY CATEGORY)
      SELECT LEV,        /*레벨링*/
                      CATEGORY,     /*계정과목최상위제목*/
               ACCOUNT_NAME,     /*계정과목*/
               BALANCE_DETAIL,   /*세부금액*/
               BALANCE_SUMMARY,  /*합계금액*/
               SEARCH_PERIOD_NO, /*기수넘버*/
               ACCOUNT_CODE      /*계정코드*/
    FROM(SELECT * FROM DETAIL
             UNION ALL
             SELECT * FROM SUMMARY
             UNION ALL
             SELECT 0 AS LEV,               -- DETAIL테이블에 0계층(합계)의 정보를 추가. 실행문에서 UNION ALL하려고 칼럼갯수 맞춰줌
                                   '9999-9999'  AS ACCOUNT_CODE,
                                    '9999' AS MIN,
                                    NULL AS MAX,
                                    CATEGORY,
                                    UNISTR('부채 및 자본 총계') AS ACCOUNT_NAME,
                                    0 AS BALANCE_DETAIL,
                        SUM(BALANCE_DETAIL_SUMMARY) AS BALANCE_DETAIL_SUMMARY
             FROM SUMMARY
             WHERE MIN != '0250'
             GROUP BY CATEGORY);
COMMIT;
END P_COMPUTE_FINANCIAL_POSITION;
/

