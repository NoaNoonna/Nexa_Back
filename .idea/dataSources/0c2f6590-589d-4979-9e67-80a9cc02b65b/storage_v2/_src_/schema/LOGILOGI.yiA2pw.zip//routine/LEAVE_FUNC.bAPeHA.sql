create FUNCTION          "LEAVE_FUNC"
(
    F_OUT_CODE    IN DAY_ATTD.ATTD_TYPE_CODE%TYPE,
    F_IN_CODE     IN DAY_ATTD.ATTD_TYPE_NAME%TYPE,
    F_EMP_CODE    IN DAY_ATTD.EMP_CODE%TYPE,
    F_APPLY_DATE  IN DAY_ATTD.APPLY_DAY%TYPE
)
RETURN VARCHAR2
IS
    TOTAL_LEAVE_HOUR    VARCHAR2(100);
    V_LEAVE_HOUR        VARCHAR2(100);
    V_OUT_TIME          VARCHAR2(100);
    V_IN_TIME           VARCHAR2(100);
    V_RANK              NUMBER;             -- FOR문을 돌리면서 비교하기 위해 RANK 함수 선언
BEGIN
    BEGIN
        V_LEAVE_HOUR := 0;                  -- FOR문 안에서 한번의 외출에 대한 외출 시간
        TOTAL_LEAVE_HOUR := 0;              -- FOR문 돈 만큼의 총 외출시간의 합계
        V_IN_TIME := 0;                     -- 귀사시간 셋팅 값
                            -- 사외출/공외출 데이터 중 TIME변수로 RANK를 매겨서 RANK와 TIME을 동적으로 생성한 FOR_OUT_TIME커서에 담아 FOR문을 돈다.
        FOR FOR_OUT_TIME IN ( SELECT RANK() OVER(PARTITION BY ATTD_TYPE_CODE ORDER BY TIME ASC) AS RANK, TIME
                              FROM DAY_ATTD
                              WHERE ATTD_TYPE_CODE = F_OUT_CODE
                              AND EMP_CODE = F_EMP_CODE
                              AND APPLY_DAY = F_APPLY_DATE
                            ) LOOP
            V_OUT_TIME := FOR_OUT_TIME.TIME;
            V_RANK := FOR_OUT_TIME.RANK;
            BEGIN
                SELECT TIME
                INTO V_IN_TIME
                FROM (  SELECT RANK() OVER(PARTITION BY ATTD_TYPE_CODE ORDER BY TIME ASC) AS RANK, TIME
                        FROM DAY_ATTD
                        WHERE ATTD_TYPE_CODE = F_IN_CODE
                        AND EMP_CODE=F_EMP_CODE
                        AND APPLY_DAY= F_APPLY_DATE
                    )
                WHERE RANK = V_RANK;

                        BEGIN
                              SELECT LOGILOGI.LEAVE_HOUR_CAL_FUNC(V_OUT_TIME,V_IN_TIME)
                              INTO   V_LEAVE_HOUR
                              FROM   DUAL;

                        END;

                TOTAL_LEAVE_HOUR := LOGILOGI.TIME_PLUS_FUNC(TOTAL_LEAVE_HOUR, V_LEAVE_HOUR);

                EXCEPTION
                WHEN NO_DATA_FOUND THEN
                V_IN_TIME := 1800;
                    BEGIN
                              SELECT LOGILOGI.LEAVE_HOUR_CAL_FUNC(V_OUT_TIME,V_IN_TIME)
                              INTO   V_LEAVE_HOUR
                              FROM   DUAL;

                    END;
                TOTAL_LEAVE_HOUR := LOGILOGI.TIME_PLUS_FUNC(TOTAL_LEAVE_HOUR, V_LEAVE_HOUR);
            END;

       END LOOP;
  END;

  RETURN TOTAL_LEAVE_HOUR;
END LEAVE_FUNC;





--ㅡㅡㅡ;; 이런 거 왜 짜는 지.. 날림..
--create or replace FUNCTION        "LEAVE_FUNC"
--(
--    F_OUT_CODE    IN DAY_ATTD.ATTD_TYPE_CODE%TYPE,
--    F_IN_CODE     IN DAY_ATTD.ATTD_TYPE_NAME%TYPE,
--    F_EMP_CODE    IN DAY_ATTD.EMP_CODE%TYPE,
--    F_APPLY_DATE  IN DAY_ATTD.APPLY_DAY%TYPE
--)
--
--RETURN VARCHAR2
--IS TOTAL_LEAVE_HOUR    VARCHAR2(100);
--   V_LEAVE_HOUR        VARCHAR2(100);
--   V_OUT_TIME          VARCHAR2(100);
--   V_IN_TIME           VARCHAR2(100);
--BEGIN
--      BEGIN
--            V_LEAVE_HOUR := 0;
--            TOTAL_LEAVE_HOUR := 0;
--            V_IN_TIME := 0;
--            FOR FOR_OUT_TIME IN --외출
--            (
--              SELECT TIME
--              FROM DAY_ATTD
--              WHERE ATTD_TYPE_CODE = F_OUT_CODE
--              AND EMP_CODE = F_EMP_CODE
--              AND APPLY_DAY = F_APPLY_DATE
--              ORDER BY TIME
--            )
--           LOOP
--               V_OUT_TIME := FOR_OUT_TIME.TIME;
--               BEGIN
--               FOR FOR_IN_TIME IN -- 귀사
--               (
--                  SELECT TIME
--                  FROM DAY_ATTD
--                  WHERE ATTD_TYPE_CODE = F_IN_CODE
--                  AND EMP_CODE=F_EMP_CODE
--                  AND APPLY_DAY= F_APPLY_DATE
--                  ORDER BY TIME
--               )
--                  LOOP
--                      V_IN_TIME := FOR_IN_TIME.TIME;
--                  END LOOP;
--
--                IF V_IN_TIME>V_OUT_TIME THEN
--                        BEGIN
--                              SELECT ERP62.LEAVE_HOUR_CAL_FUNC(V_OUT_TIME,V_IN_TIME)
--                              INTO   V_LEAVE_HOUR
--                              FROM   DUAL;
--                          END;
--                ELSE -- 귀사가 없는 경우
--                      V_IN_TIME := 1800;
--                      BEGIN
--                             SELECT ERP62.LEAVE_HOUR_CAL_FUNC(V_OUT_TIME,V_IN_TIME)
--                             INTO   V_LEAVE_HOUR
--                             FROM   DUAL;
--                      END;
--                END IF;
--
--                TOTAL_LEAVE_HOUR := TOTAL_LEAVE_HOUR + V_LEAVE_HOUR;
--
--               END;
--
--       END LOOP;
--  END;
--
--  RETURN TOTAL_LEAVE_HOUR;
--END LEAVE_FUNC;
/

