create PROCEDURE          "P_WORK_ORDER_COMPLETION" --작업완료등록
(
    -- 매개변수 선언부

    -- 뷰단에서 넘어온 작업지시번호
    V_WORK_ORDER_NO IN VARCHAR2
    -- 뷰단에서 넘어온 실제작업완료수량
    ,V_ACTUAL_COMPLETION_AMOUNT IN VARCHAR2
    -- 에러코드
    ,ERROR_CODE OUT NUMBER
     -- 에러메세지
    ,ERROR_MSG OUT VARCHAR2
)

IS
-- 변수,상수 선언부시작

-- 뷰단에서 선택된 WORK_ORDER_INFO ROW의 정보를 담을 변수
V_WORK_ORDER_INFO_RECORD WORK_ORDER_INFO%ROWTYPE;

-- 수주 작업완료 STATUS 변경하기위한 변수
V_CONTRACT_DETAIL_NO CONTRACT_DETAIL.CONTRACT_DETAIL_NO%TYPE;

-- 실제 납품필요량 계산변수
V_PRODUCTION_REQUIREMENT contract_detail.production_requirement%TYPE;

-- 재공품의 경우 필요량 계산변수
V_INPUT_AMOUNT MRP.REQUIRED_AMOUNT%TYPE;

V_MRP_GATHERING_NO WORK_ORDER_INFO.MRP_GATHERING_NO%TYPE;

V_OUTSOURC_COMPLETION outsourc_info.completion_status%TYPE;

V_OUT_REQUIRED_AMOUNT NUMBER;

V_OUT_ITEM_CODE outsourc_info.item_code%TYPE;

V_LOSS_RATE NUMBER;


v_item_code mrp_gathering.item_code%type;


v_contract_amount number;

BEGIN

-- 실행부시작

-- WORK_ORDER_INFO 테이블에서
-- 뷰단에서 받아온 WORK_ORDER_NO와 일련번호가 일치하는
-- ROW를 V_WORK_ORDER_INFO_RECORD 레코드타입변수에 담음
SELECT *
INTO
V_WORK_ORDER_INFO_RECORD
FROM
WORK_ORDER_INFO
WHERE
WORK_ORDER_NO = V_WORK_ORDER_NO;

-- 선택된 ROW의 품목 분류가 반제품 OR 완제품 이라면
IF
V_WORK_ORDER_INFO_RECORD.ITEM_CLASSIFICATION = '반제품'
OR
V_WORK_ORDER_INFO_RECORD.ITEM_CLASSIFICATION = '완제품'
THEN

-- 수주 작업완료 STATUS 를 'Y' 로 변경 및
-- 초과생산됬을경우 실제납품필요량 제외하고는 납품예정재고량이 아닌 재고량에 담기위해서
-- WORK_ORDER_INFO 테이블에서 MPS번호만 뽑아내서
-- MPS테이블에서 해당 MPS번호와 매핑되는 수주상세번호 및 실제작수량 찾아서 변수에담기

SELECT
mrp_gathering_no
INTO
V_MRP_GATHERING_NO  --취합번호
FROM
work_order_info
WHERE
work_order_no = V_WORK_ORDER_INFO_RECORD.work_order_no;


-- 작업지시 수량 구하기 시작
IF V_WORK_ORDER_INFO_RECORD.ITEM_CLASSIFICATION = '반제품'

/* 작업지시의 품목이 반제품이면 수주상세의 반제품과 */
THEN

begin

V_PRODUCTION_REQUIREMENT := 0;


for
mgt
in(
select
*
from
mrp_gathering
where
mrp_gathering_seq=
(select
mrp_gathering_seq
from
mrp_gathering
where
mrp_gathering_no=
(select
mrp_gathering_no
from work_order_info
where
work_order_no = V_WORK_ORDER_NO))
and
ORDER_OR_PRODUCTION_STATUS = '생산')
LOOP

for
item_temp
in (
select
ITEM_CODE
from item
where
ITEM_CLASSIFICATION = 'IT-CI')
loop

if item_temp.item_code = mgt.item_code
then
DBMS_OUtPUT.put_line('완제품');

V_PRODUCTION_REQUIREMENT := V_PRODUCTION_REQUIREMENT + mgt.NECESSARY_AMOUNT;

end if;
end loop;





for
item_temp
in (
select
ITEM_CODE
from item
where
ITEM_CLASSIFICATION = 'IT-SI')
loop

begin
select
sum(PRODUCTION_REQUIREMENT)
into
v_contract_amount
from
contract_detail
where
item_code = item_temp.item_code
and
mrp_gathering_no = mgt.mrp_gathering_no
group by mrp_gathering_no;
DBMS_OUtPUT.put_line('반제품');
DBMS_OUtPUT.put_line(v_contract_amount);
V_PRODUCTION_REQUIREMENT := V_PRODUCTION_REQUIREMENT + v_contract_amount;

EXCEPTION
WHEN NO_DATA_FOUND THEN
null;
end;

end loop;


end loop;

DBMS_OUtPUT.put_line(V_PRODUCTION_REQUIREMENT);

end;

ELSIF V_WORK_ORDER_INFO_RECORD.ITEM_CLASSIFICATION = '완제품'
then

select
sum(production_requirement) amount
into
V_PRODUCTION_REQUIREMENT  --제작량=작업지시한 수량
from contract_detail
where
mrp_gathering_no=
(
select
MRP_GATHERING_NO
from work_order_info
WHERE
work_order_no=V_WORK_ORDER_NO);

END IF;
-- 작업지시 수량 구하기 끝


--완제품과 외주 발주 안한 반제품은 무조건 수주 상세 작업완료,
--외주 발주 등록한 반제품은 외주 실적 검사 했으면 작업완료 외주 실적 검사 안했으면 수주 상세 작업완료 안함
BEGIN


select
completion_Status
INTO
V_OUTSOURC_COMPLETION
from outsourc_info
where mrp_gathering_no=V_MRP_GATHERING_NO;

IF V_OUTSOURC_COMPLETION = 'Y' THEN
DBMS_OUTPUT.put_line('반제품 작업 완료 수정');

for contract_detail_to_rec in
(
select
*
from
contract_detail
where
MRP_GATHERING_NO = V_MRP_GATHERING_NO)
loop

UPDATE
CONTRACT_DETAIL
SET
OPERATION_COMPLETED_STATUS = 'Y'
WHERE
CONTRACT_DETAIL_NO = contract_detail_to_rec.CONTRACT_DETAIL_NO;
end loop;

ELSE
DBMS_OUTPUT.put_line('작업 완료 수정 안함');
END IF;

EXCEPTION
WHEN NO_DATA_FOUND THEN
       DBMS_OUTPUT.PUT_LINE('작업 완료 수정');
       --수주 상세 작업 완료 업데이트
for contract_detail_to_rec in
(
select
*
from
contract_detail
where
MRP_GATHERING_NO = V_MRP_GATHERING_NO)
loop

UPDATE
CONTRACT_DETAIL
SET
OPERATION_COMPLETED_STATUS = 'Y'
WHERE
CONTRACT_DETAIL_NO = contract_detail_to_rec.CONTRACT_DETAIL_NO;
end loop;

END;


--외주발주 제작량 반영 시작
BEGIN

SELECT
1+TO_NUMBER(LOSS_RATE)
INTO
V_LOSS_RATE
FROM
ITEM
WHERE
ITEM_CODE=V_WORK_ORDER_INFO_RECORD.ITEM_CODE;


SELECT
FLOOR((NECESSARY_AMOUNT-OUTSOURC_AMOUNT)/V_LOSS_RATE),
ITEM_CODE
INTO
V_OUT_REQUIRED_AMOUNT,
V_OUT_ITEM_CODE
FROM OUTSOURC_INFO
WHERE
MRP_GATHERING_NO=V_MRP_GATHERING_NO;


UPDATE
STOCK
SET
DELIVERY_AMOUNT = DELIVERY_AMOUNT + V_OUT_REQUIRED_AMOUNT
WHERE
ITEM_CODE = V_OUT_ITEM_CODE;


IF V_OUT_REQUIRED_AMOUNT < V_ACTUAL_COMPLETION_AMOUNT  THEN
UPDATE
STOCK
SET
STOCK_AMOUNT = STOCK_AMOUNT + V_ACTUAL_COMPLETION_AMOUNT - V_OUT_REQUIRED_AMOUNT
WHERE
ITEM_CODE = V_OUT_ITEM_CODE;
END IF;


EXCEPTION

WHEN NO_DATA_FOUND THEN
       DBMS_OUTPUT.PUT_LINE('완제품이거나 외주 없는 반제품');


    -- 실제 생산량이 제작예상량보다 많다면
    IF V_PRODUCTION_REQUIREMENT < V_ACTUAL_COMPLETION_AMOUNT THEN
    UPDATE
    STOCK
    SET
    -- 제작예상량만큼 납품예정량에 추가
    -- 남는재고는 재고량에 추가													V_PRODUCTION_REQUIREMENT(MPS계획수량=작업지시수량)
    STOCK.DELIVERY_AMOUNT = STOCK.DELIVERY_AMOUNT + V_PRODUCTION_REQUIREMENT,
    STOCK.STOCK_AMOUNT = STOCK.STOCK_AMOUNT + (V_ACTUAL_COMPLETION_AMOUNT - V_PRODUCTION_REQUIREMENT)
    WHERE																			--뷰단에서 넘어온 실제작업수량 - 작업지시수량(MPS계획수량)
    STOCK.ITEM_CODE = V_WORK_ORDER_INFO_RECORD.ITEM_CODE;

    -- 재고로그테이블에 정보 남기기
    -- 재고로그테이블 INSERT
    -- 실제 생산량에서 필요량만큼 납품예정재고에 추가
    INSERT INTO STOCK_LOG VALUES
    (
    V_WORK_ORDER_INFO_RECORD.ITEM_CLASSIFICATION||' 작업완료',
    '납품예정재고에 추가',
    TO_CHAR(SYSDATE,'YYYY-MM-DD HH24:MI:SS'),
    V_WORK_ORDER_INFO_RECORD.ITEM_CODE,
    V_WORK_ORDER_INFO_RECORD.ITEM_NAME,
    V_PRODUCTION_REQUIREMENT,
    '작업완료'
    );

    -- 실제 생산량에서 필요량을 빼서 남는 만큼은
    -- 재고량에 남겨서 다음에 사용
    INSERT INTO STOCK_LOG VALUES
    (
    V_WORK_ORDER_INFO_RECORD.ITEM_CLASSIFICATION||' 작업완료',
    V_WORK_ORDER_INFO_RECORD.ITEM_CLASSIFICATION||' 초과생산으로 재고에 추가',
    TO_CHAR(SYSDATE,'YYYY-MM-DD HH24:MI:SS'),
    V_WORK_ORDER_INFO_RECORD.ITEM_CODE,
    V_WORK_ORDER_INFO_RECORD.ITEM_NAME,
    (V_ACTUAL_COMPLETION_AMOUNT - V_PRODUCTION_REQUIREMENT),
    '작업완료'
    );

    -- 실제 생산량이 제작예상량보다 적거나 같다면
    ELSE
    UPDATE
    STOCK
    SET
    -- 입력된 수량만큼 납품예정재고량에 추가
    STOCK.DELIVERY_AMOUNT = STOCK.DELIVERY_AMOUNT + V_ACTUAL_COMPLETION_AMOUNT
    WHERE
    STOCK.ITEM_CODE = V_WORK_ORDER_INFO_RECORD.ITEM_CODE;


update
mrp_gathering
set
NECESSARY_AMOUNT=NECESSARY_AMOUNT
-
--완제품만 취합할 경우 반제품의 수주상세가 없음, 그래서 null 값을 0으로 치환
NVL(
(select
PRODUCTION_REQUIREMENT
from contract_detail
where
mrp_gathering_no = (
select
MRP_GATHERING_no
from work_order_info
where
mrp_gathering_no=V_WORK_ORDER_INFO_RECORD.mrp_gathering_no)
),0)
where
mrp_gathering_no=V_WORK_ORDER_INFO_RECORD.mrp_gathering_no;

    -- 재고로그테이블에 정보 남기기
    -- 재고로그테이블 INSERT
    INSERT INTO STOCK_LOG VALUES
    (
    V_WORK_ORDER_INFO_RECORD.ITEM_CLASSIFICATION||' 작업완료',
    '납품예정재고에 추가',
    TO_CHAR(SYSDATE,'YYYY-MM-DD HH24:MI:SS'),
    V_WORK_ORDER_INFO_RECORD.ITEM_CODE,
    V_WORK_ORDER_INFO_RECORD.ITEM_NAME,
    V_ACTUAL_COMPLETION_AMOUNT,
    '작업완료'
    );

    -- 실제생산량 / 제작예상량 비교 IF문 끝
    END IF;

    END;
    --외주발주 제작량 반영 끝

-- 선택된 ROW의 품목 분류가 재공품 이라면
ELSIF V_WORK_ORDER_INFO_RECORD.ITEM_CLASSIFICATION = '재공품'
THEN

    -- 이제품을 가지고 완제품 제작에 들어가서 완제품을 제작했을때 수주상세의 작업완료 STATUS 가 'Y' 로 변경되야 하므로
    -- 재공품 작업완료시 수주 STATUS를 'Y'로 변경하지않고, 제작된수량만큼 투입예정재고량을 추가한다.
    -- 입력된 수량만큼 투입예정재고량으로 이동
    -- 재고테이블 UPDATE

    -- 재공품 필요 계산
    /*
    SELECT
    REQUIRED_AMOUNT
    INTO
    V_INPUT_AMOUNT
    FROM
    MRP
    WHERE
    MPS_NO = V_WORK_ORDER_INFO_RECORD.MPS_NO
    AND ITEM_CLASSIFICATION = '완제품';
*/

    -- 재공품이 재공품필요갯수보다 많이 생산되었을경우
    -- 완제품 제작필요수량 보다 많이 생산되었을 경우
    IF V_INPUT_AMOUNT < V_ACTUAL_COMPLETION_AMOUNT THEN
    UPDATE
    STOCK
    SET
    -- 필요량만큼 투입예정재고량에 넣고, 남는재고는 재고량으로
    STOCK.INPUT_AMOUNT = STOCK.INPUT_AMOUNT + V_INPUT_AMOUNT,
    STOCK.STOCK_AMOUNT = STOCK.STOCK_AMOUNT + (V_ACTUAL_COMPLETION_AMOUNT - V_INPUT_AMOUNT)
    WHERE
    STOCK.ITEM_CODE = V_WORK_ORDER_INFO_RECORD.ITEM_CODE;

    -- 재고로그테이블에 정보 남기기
    -- 재고로그테이블 INSERT
    INSERT INTO STOCK_LOG VALUES
    (
    V_WORK_ORDER_INFO_RECORD.ITEM_CLASSIFICATION||' 작업완료',
    '투입예정재고에 추가',
    TO_CHAR(SYSDATE,'YYYY-MM-DD HH24:MI:SS'),
    V_WORK_ORDER_INFO_RECORD.ITEM_CODE,
    V_WORK_ORDER_INFO_RECORD.ITEM_NAME,
    V_INPUT_AMOUNT,
    '작업완료'
    );
    INSERT INTO STOCK_LOG VALUES
    (
    V_WORK_ORDER_INFO_RECORD.ITEM_CLASSIFICATION||' 작업완료',
    V_WORK_ORDER_INFO_RECORD.ITEM_CLASSIFICATION||' 초과생산으로 재고에 추가',
    TO_CHAR(SYSDATE,'YYYY-MM-DD HH24:MI:SS'),
    V_WORK_ORDER_INFO_RECORD.ITEM_CODE,
    V_WORK_ORDER_INFO_RECORD.ITEM_NAME,
    (V_ACTUAL_COMPLETION_AMOUNT - V_INPUT_AMOUNT),
    '작업완료'
    );

    -- 재공품이 재공품 필요갯수보다 적거나 같은수로 생산되었을 경우
    ELSE
    UPDATE
    STOCK
    SET
    -- 투입예정재고량에 추가
    STOCK.INPUT_AMOUNT = STOCK.INPUT_AMOUNT + V_ACTUAL_COMPLETION_AMOUNT
    WHERE
    STOCK.ITEM_CODE = V_WORK_ORDER_INFO_RECORD.ITEM_CODE;

    -- 재고로그테이블에 정보 남기기
    -- 재고로그테이블 INSERT
    INSERT INTO STOCK_LOG VALUES
    (
    V_WORK_ORDER_INFO_RECORD.ITEM_CLASSIFICATION||' 작업완료',
    '투입예정재고에 추가',
    TO_CHAR(SYSDATE,'YYYY-MM-DD HH24:MI:SS'),
    V_WORK_ORDER_INFO_RECORD.ITEM_CODE,
    V_WORK_ORDER_INFO_RECORD.ITEM_NAME,
    V_ACTUAL_COMPLETION_AMOUNT,
    '작업완료'
    );
    -- 재공품 생산 수량에 따른 IF문 끝
    END IF;

-- 품목분류에 따른 IF문 끝
END IF;



-- 생산실적에 등록
-- 생산실적테이블 INSERT
INSERT INTO PRODUCTION_PERFORMANCE VALUES
    (
    TO_CHAR(SYSDATE,'YYYY/MM/DD HH24:MI:SS'),
    V_WORK_ORDER_INFO_RECORD.WORK_ORDER_NO,
    V_CONTRACT_DETAIL_NO,
    V_WORK_ORDER_INFO_RECORD.ITEM_CLASSIFICATION,
    V_WORK_ORDER_INFO_RECORD.ITEM_CODE,
    V_WORK_ORDER_INFO_RECORD.ITEM_NAME,
    V_WORK_ORDER_INFO_RECORD.UNIT_OF_MRP,
    V_WORK_ORDER_INFO_RECORD.REQUIRED_AMOUNT,
    V_ACTUAL_COMPLETION_AMOUNT,
    ROUND((V_ACTUAL_COMPLETION_AMOUNT/V_WORK_ORDER_INFO_RECORD.REQUIRED_AMOUNT*100),2)
    );

-- STATUS 업데이트
UPDATE
WORK_ORDER_INFO
SET
OPERATION_COMPLETED = 'Y'  --작업완료상태? Y 로 변경
WHERE
WORK_ORDER_INFO.WORK_ORDER_NO = V_WORK_ORDER_NO;

-- 성공시 커밋
COMMIT;

ERROR_CODE := '0';
ERROR_MSG := '성공?!!!?!?!?';

-- 예외 발생시
EXCEPTION

WHEN NO_DATA_FOUND THEN
       DBMS_OUTPUT.PUT_LINE('NO_DATA_FOUND');
       ERROR_CODE := '-1';
       ERROR_MSG := 'NO_DATA_FOUND';
       RETURN;

WHEN DUP_VAL_ON_INDEX THEN
       DBMS_OUTPUT.PUT_LINE('DUP_VAL_ON_INDEX');
       ERROR_CODE := '-1';
       ERROR_MSG := 'DUP_VAL_ON_INDEX';
       RETURN;

WHEN OTHERS THEN
       DBMS_OUTPUT.PUT_LINE('OTHERS');
       ERROR_CODE := '-1';
       ERROR_MSG := '관리자에게 문의 하세요 // 01077239513';
       RETURN;

-- PROCEDURE 끝
END;
/

