create PROCEDURE          P_MONTH_INCOME_STATEMENT(

																	V_REPORT_YEAR IN VARCHAR2,
                                  ERROR_CODE OUT NUMBER,
                                  ERROR_MSG OUT VARCHAR2,
                                 RESULT OUT SYS_REFCURSOR
                                  ) IS

BEGIN

DELETE FROM  TMP_MONTH_INCOME_STATEMENT2;

 P_COMPUTE_MINCOME_STATEMENT(V_REPORT_YEAR);  -- 해당 월

OPEN RESULT FOR
    WITH
       MINCOME_STATEMENT AS (SELECT * FROM TMP_MONTH_INCOME_STATEMENT2 )
      SELECT *
      FROM MINCOME_STATEMENT;


  ERROR_CODE := 0;
  ERROR_MSG := '월별 손익계산서 성공';

EXCEPTION
  WHEN
    NO_DATA_FOUND
    THEN
      ERROR_CODE := -1;
      ERROR_MSG := '조회할 데이터가 없습니다.';
  WHEN
    OTHERS
    THEN
      ERROR_CODE := -2;
      ERROR_MSG := SQLERRM;

END P_MONTH_INCOME_STATEMENT;
/

