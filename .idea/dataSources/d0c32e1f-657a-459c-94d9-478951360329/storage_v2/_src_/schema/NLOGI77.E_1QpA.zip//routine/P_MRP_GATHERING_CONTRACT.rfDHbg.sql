create PROCEDURE      "P_MRP_GATHERING_CONTRACT" --  수주상세테이블에 소요량취합번호 입력
       (   V_MRP_GATHERING_NO_LIST IN VARCHAR2 -- 소요량취합번호리스트
         , ERROR_CODE OUT NUMBER -- 에러코드
         , ERROR_MSG OUT VARCHAR2 -- 에러메세지
       )
IS -- 변수 상수 선언부 시작


CURSOR C_MRP_GATHERING_CONTRACT -- 커서선언시작
IS
             WITH MRP_GATHERING_NO_STR AS
         ( SELECT V_MRP_GATHERING_NO_LIST FROM DUAL ) ,

         MRP_GATHERING_NO_LIST AS
         (
         SELECT TRIM( REGEXP_SUBSTR( (SELECT * FROM MRP_GATHERING_NO_STR ) ,'[^,]+', 1, LEVEL ) ) AS MRP_GATHERING_NO FROM DUAL
         CONNECT BY REGEXP_SUBSTR( (SELECT * FROM MRP_GATHERING_NO_STR ) , '[^,]+', 1, LEVEL ) IS NOT NULL
         ) ,
            mgp AS (  -- 소요량 취합 목록 중 생산 아이템 정보
            SELECT
            mg.mrp_gathering_no,
            mg.item_code
            FROM
            mrp_gathering mg,
            MRP_GATHERING_NO_LIST mgnl
            WHERE
            mg.mrp_gathering_no=mgnl.mrp_gathering_no
            AND
            mg.ORDER_OR_PRODUCTION_STATUS='생산'
            ),

            mps_gathering AS ( -- 취합한 생산아이템의 mpsNo
            SELECT
            DISTINCT  m.mps_no
            FROM
            mrp m,
            mgp
            WHERE
            m.mrp_gathering_no=mgp.mrp_gathering_no),

            cdnl AS (  -- 해당 mps의 수주상세번호
            SELECT
            contract_detail_no
            FROM
            mps_gathering mg, mps
            WHERE
            mps.mps_no=mg.mps_no),

            cdnicl AS ( -- 해당 수주상세번호의 아이템코드
            SELECT
            cd.contract_detail_no,
            cd.item_code
            FROM
            contract_detail cd,
            cdnl
            WHERE
            cd.contract_detail_no=cdnl.contract_detail_no
            )

            -- with 선언 끝
            -- 취합 목록 중 생산아이템의 수주상세 정보 구함

            SELECT
            c.contract_detail_no,
            c.item_code,
            m.mrp_gathering_no
            FROM
            cdnicl c,mgp m -- 수주상세, 취합 생산아이템
            WHERE
            c.item_code=m.item_code;
            --커서 선언 끝
            -- 커서에는  취합 생산아이템의 수주상세번호, 아이템 코드, 취합번호가 담겨있다

-- 변수 상수 선언부 끝

BEGIN -- 실행부 시작

FOR MRP_GATHERING_CONTRACT IN C_MRP_GATHERING_CONTRACT
LOOP

UPDATE contract_detail
SET mrp_gathering_no=MRP_GATHERING_CONTRACT.mrp_gathering_no
WHERE contract_detail_NO=MRP_GATHERING_CONTRACT.contract_detail_NO;

END LOOP;

COMMIT;
ERROR_CODE := '0';
ERROR_MSG := '재고처리및 취합발주 Dialog 프로시저 성공';

       -- 예외 발생시
   EXCEPTION


    WHEN NO_DATA_FOUND THEN
       DBMS_OUTPUT.PUT_LINE('NO_DATA_FOUND');
       ERROR_CODE := '-1';
       ERROR_MSG := '데이터를 찾을 수 없습니다!';
       RETURN;

    WHEN DUP_VAL_ON_INDEX THEN
       DBMS_OUTPUT.PUT_LINE('DUP_VAL_ON_INDEX');
       ERROR_CODE := '-1';
       ERROR_MSG := '고유값이 중복됩니다!';
       RETURN;

    WHEN OTHERS THEN
       DBMS_OUTPUT.PUT_LINE('오류가 발생했습니다');
       DBMS_OUTPUT.PUT_LINE('SQL ERROR CODE: ' || SQLCODE);
       DBMS_OUTPUT.PUT_LINE('SQL ERROR MESSAGE: ' || SQLERRM);
       ERROR_CODE := '-1';
       ERROR_MSG := 'SQL ERROR CODE: ' || SQLCODE || 'SQL ERROR MESSAGE: ' || SQLERRM;
       RETURN;

   END P_MRP_GATHERING_CONTRACT; -- 프로시저끝
/

