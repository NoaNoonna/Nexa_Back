create PROCEDURE      "P_WORK_ORDERABLE_MRP_LIST"  -- 작업지시필요목록조회
   (
    --매개변수선언부
    ERROR_CODE OUT NUMBER -- 에러코드
    ,ERROR_MSG OUT VARCHAR2 -- 에러메세지
    ,RESULT OUT SYS_REFCURSOR -- 결과 값 반환 커서
   )

IS
--변수,상수선언부 시작

--커서시작

CURSOR C_ORDERABLE_mrp_gathering_LIST IS

WITH mrp_gathering_LIST AS  -- 취합시퀀스 별 원재료들의 발주여부 정보 : 발주완료 1 완료X 2
(
--mrp_gathering_LIST에는 품목분류가 원재료인 mrp_gathering_NO, REQUEST_STATUS 정보들이 담겨 있다
--request_status : 발주 및 작업 요청 여부
-- request_status가 0이면 발주 및 작업 요청이 안되었다. 즉 디카나 카메라 본체를 만들기 위한 원재료의 발주가 안되었다
SELECT
    MRP_GATHERING.MRP_GATHERING_SEQ,
      (CASE WHEN request_status IS NULL THEN 0 ELSE 1 END) request_status --발주 및 작업 요청 여부
   FROM
      MRP_GATHERING
      WHERE ORDER_OR_PRODUCTION_STATUS = '구매'
      GROUP BY MRP_GATHERING.MRP_GATHERING_SEQ, request_status
),

CHECK_mrp_gathering AS -- 시퀀스별로 모든 원재료 발주여부 확인
(
-- mrp_gathering_seq를 기준으로 mrp_gathering_seq를 count 하고, request_status를 sum 한다
SELECT
MRP_GATHERING_SEQ, COUNT(*) count, SUM(request_status) sum
FROM
mrp_gathering_LIST
GROUP BY
MRP_GATHERING_SEQ
), -- select * from CHECK_mrp_gathering

ORDERABLE_mrp_gathering_LIST AS -- 작업지시가 가능한 취합시퀀스 리스트
(
-- 2 1은 발주가 된것도 있고 안된것도 있다
-- 1 0은 발주가 하나도 안되었다
-- 1 1은 모든 하위 품목이 발주가 되어 작업지시가 가능하다
SELECT MRP_GATHERING_SEQ
FROM CHECK_mrp_gathering
WHERE count = 1 AND sum = 1
)

SELECT  * FROM  ORDERABLE_mrp_gathering_LIST; -- 작업지시가 가능한 취합시퀀스 리스트
--커서 끝

--변수,상수 선언부 끝

BEGIN
-- 실행부 시작

-- 임시테이블에서 정보제거
DELETE FROM WORK_ORDERABLE_TEMP;

    FOR V_ORDERABLE_MRP_GATHERING IN C_ORDERABLE_mrp_gathering_LIST -- V_ORDERABLE_mrp_gathering : 작업지시 가능 시퀀스
    LOOP

    -- 임시테이블에 정보넣기
    INSERT INTO WORK_ORDERABLE_TEMP
    select MG.MRP_GATHERING_NO
			,M.ITEM_CLASSIFICATION
			,M.ITEM_CODE
			,TRIM(M.ITEM_NAME)
			,MG.unit_of_mrp_gathering
			,M.REQUIRED_AMOUNT AS necessary_amount
			,MG.claim_date
			,MG.due_date
			,MG.MRP_GATHERING_SEQ
			,M.MRP_NO --소요량전개번호
			from mrp M,(select *
								from mrp_gathering
								where mrp_gathering_seq=V_ORDERABLE_MRP_GATHERING.MRP_GATHERING_SEQ) MG
			where M.mrp_gathering_no =MG.MRP_GATHERING_NO --V_ORDERABLE_MRP_GATHERING.MRP_GATHERING_SEQ
			AND M.REQUEST_STATUS IS NULL
			AND M.ITEM_CLASSIFICATION LIKE '%품'
			AND M.REQUIRED_AMOUNT != 0;

END LOOP;

    COMMIT;
        ERROR_CODE := 0;
        ERROR_MSG := '성공_ 모의작업지시로 넘어가시오';
        OPEN RESULT FOR SELECT * FROM WORK_ORDERABLE_TEMP; --뷰단으로 WORK_ORDERABLE_TEMP에 담긴 값을 넘김

   EXCEPTION
   WHEN NO_DATA_FOUND THEN
       DBMS_OUTPUT.PUT_LINE('NO_DATA_FOUND');
       ERROR_CODE := '-1';

       ERROR_MSG := 'NO_DATA_FOUND';
       RETURN;
   WHEN DUP_VAL_ON_INDEX THEN
       DBMS_OUTPUT.PUT_LINE('DUP_VAL_ON_INDEX');
       ERROR_CODE := '-1';
       ERROR_MSG := 'DUP_VAL_ON_INDEX';
       RETURN;
   WHEN OTHERS THEN
       DBMS_OUTPUT.PUT_LINE('OTHERS');
       ERROR_CODE := '-1';
       ERROR_MSG := '관리자에게 문의 하세요 // 01077239513';
       RETURN;

END;
/

