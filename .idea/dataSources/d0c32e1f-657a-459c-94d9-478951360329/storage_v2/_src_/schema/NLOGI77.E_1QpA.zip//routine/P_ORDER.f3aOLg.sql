create PROCEDURE      "P_ORDER" --현재 전개된 결과 발주 및 재고처리
(
    V_MRP_GATHERING_NO_LIST IN VARCHAR2,-- 매개변수 선언부, 발주처리할 소요량취합번호리스트
    ERROR_CODE OUT NUMBER -- 에러코드
    ,ERROR_MSG OUT VARCHAR2 -- 에러메세지
)

IS

-- 변수,상수 선언부시작
V_ORDER_NO ORDER_INFO.order_no%TYPE;  -- 발주번호
V_OUTSOURCING_NO OUTSOURCING.OUTSOURCING_NO%TYPE;
-- 커서선언 시작
 CURSOR C_ORDER_DIALOG_TEMP  -- 취합 발주 정보
IS
SELECT *
FROM ORDER_DIALOG_TEMP;   -- 모의재고처리 및 취합발주 시 insert.

CURSOR C_OUTSOURCING
IS
SELECT C.CUSTOMER_CODE
         ,I.ITEM_CODE
         ,I.ITEM_NAME
         ,ODT.CALCULATED_REQUIRED_AMOUNT AS INSTRUCTION_AMOUNT
         ,TO_CHAR(TO_DATE(MG.CLAIM_DATE),'YY-MM-DD') AS INSTRUCT_DATE
         ,TO_CHAR(TO_DATE(MG.DUE_DATE),'YY-MM-DD') AS COMPLETE_DATE
         ,I.STANDARD_UNIT_PRICE AS UNIT_PRICE
         ,ODT.SUM_PRICE AS TOTAL_PRICE
         ,TO_CHAR(SYSDATE,'YYYY-MM-DD') AS OUTSOURCING_DATE
FROM CUSTOMER C,ITEM I,MRP_GATHERING MG,ORDER_DIALOG_TEMP ODT
WHERE I.ITEM_GROUP_CODE = C.PRODUCED_PRODUCT
AND   MG.ITEM_CODE=I.ITEM_CODE
AND		ODT.ITEM_CODE=I.ITEM_CODE
AND   ODT.CALCULATED_REQUIRED_AMOUNT!=0;

-- 커서선언 끝

BEGIN
-- 실행부시작

-- 커서 LOOP 문 시작
FOR R_ODT IN C_ORDER_DIALOG_TEMP  --  R_ODT : 각각의 발주 아이템
LOOP
    -- 필요량이 재고량보다 많은경우 ( 발주하는경우 )
    -- STOCK 테이블의 정보 업데이트
    -- IF문 시작
    IF R_ODT.CALCULATED_REQUIRED_AMOUNT > 0 THEN --실제발주필요량; 즉, 실제발주필요량이 존재하는경우
    UPDATE STOCK
    SET                                    -- R_ODT.STOCK_AMOUNT = 사용가능한재고량
    STOCK.input_amount = STOCK.input_amount + R_ODT.STOCK_AMOUNT, --투입예정재고량 = 투입예정재고량+사용가능한재고량
    STOCK.STOCK_AMOUNT = STOCK.STOCK_AMOUNT - R_ODT.STOCK_AMOUNT, --재고량-사용가능한재고량
    STOCK.ORDER_AMOUNT = STOCK.ORDER_AMOUNT + R_ODT.CALCULATED_REQUIRED_AMOUNT  --입고예정재고량+실제발주필요량
    WHERE
    STOCK.item_code = R_ODT.ITEM_CODE;
    -- STOCK테이블 업데이트 끝

    -- 발주번호생성
    CASE
        WHEN  LENGTH(ORDER_SEQUENCE.NEXTVAL)<3
        THEN V_ORDER_NO := 'ORDG'||TO_CHAR(SYSDATE,'yyyymmdd')||'-'||lpad(ORDER_SEQUENCE.CURRVAL,3,0);
        ELSE V_ORDER_NO := 'ORDG'||TO_CHAR(SYSDATE,'yyyymmdd')||'-'||to_char(ORDER_SEQUENCE.CURRVAL);
        END CASE ;

    -- ORDER_INFO에 발주정보등록
    INSERT INTO ORDER_INFO VALUES
    (V_ORDER_NO,TO_CHAR(SYSDATE,'YYYY-MM-DD'),'운송중','취합발주',R_ODT.ITEM_CODE,R_ODT.ITEM_NAME,R_ODT.CALCULATED_REQUIRED_AMOUNT,NULL);

-----------------------------------------------------------------------------------
    -- 스톡로그정보만들어서 STOCK_LOG 테이블에 찍기
    -- 재고량에서 투입예정재고량으로 이동했다고 남기는 로그
    -- 현재고량이 0일때는 재고를 투입예정재고로 이동할 수 없으므로 0이상일때만 이동하도록 IF문 추가.
    IF R_ODT.STOCK_AMOUNT > 0 THEN -- 재고를 사용하는 경우
    INSERT INTO STOCK_LOG VALUES ('남은재고투입예정','재고에서 투입예정재고로 이동',TO_CHAR(SYSDATE,'YYYY-MM-DD HH24:MI:SS'),
    R_ODT.ITEM_CODE,R_ODT.ITEM_NAME,R_ODT.STOCK_AMOUNT,'발주 및 재고처리');
    END IF;
-----------------------------------------------------------------------------------

    -- 발주량만큼 입고예정재고량에 추가됬다고 남기는 로그
    INSERT INTO STOCK_LOG VALUES
    ('부족재고발주','입고예정재고 증가',TO_CHAR(SYSDATE,'YYYY-MM-DD HH24:MI:SS'),
    R_ODT.ITEM_CODE,R_ODT.ITEM_NAME,R_ODT.CALCULATED_REQUIRED_AMOUNT,'발주 및 재고처리');



    -- 재고량이 필요량보다 많은경우 ( 발주 안함 )
    -- STOCK 테이블의 정보 업데이트
    ELSIF R_ODT.CALCULATED_REQUIRED_AMOUNT = 0 THEN
    UPDATE
    STOCK
    SET
    STOCK.INPUT_AMOUNT = STOCK.INPUT_AMOUNT + R_ODT.REQUIRED_AMOUNT,   --투입예정재고량
    STOCK.STOCK_AMOUNT = STOCK.STOCK_AMOUNT - R_ODT.REQUIRED_AMOUNT    --재고량
    WHERE
    stock.item_code = R_ODT.ITEM_CODE;
    --  STOCK 테이블 정보 업데이트 끝

    -- 스톡로그정보만들어서 STOCK_LOG에 찍기
    -- 재고량에서 투입예정재고량으로 이동한 로그
    INSERT INTO STOCK_LOG VALUES
    ('남은재고투입예정','재고에서 투입예정재고로 이동',TO_CHAR(SYSDATE,'YYYY-MM-DD HH24:MI:SS'),
    R_ODT.ITEM_CODE,R_ODT.ITEM_NAME,R_ODT.REQUIRED_AMOUNT,'발주 및 재고처리');

    -- IF문 끝
    END IF;

    -- order_dialog 띄울때 사용하는 프로시저에서 생성되는
    -- MRP REQUEST_STATUS = 'Y' 로 암묵적 커서방식를 이용해서 업데이트해줌
    FOR V_MRP_GATHERING_NO IN  -- 발주처리할 소요량취합번호리스트, 즉 V_MRP_GATHERING_NO는 각각의 취합발주번호
    (SELECT TRIM( REGEXP_SUBSTR( V_MRP_GATHERING_NO_LIST ,'[^,]+', 1, LEVEL ) ) MRP_GATHERING_NO
    FROM DUAL
    CONNECT BY REGEXP_SUBSTR( V_MRP_GATHERING_NO_LIST , '[^,]+', 1, LEVEL ) IS NOT NULL)
    LOOP
         UPDATE MRP
         SET MRP.request_status = 'Y'  -- 발주 및 작업요청 여부
         WHERE MRP.MRP_GATHERING_NO = V_MRP_GATHERING_NO.MRP_GATHERING_NO;

         UPDATE MRP_GATHERING
         SET MRP_GATHERING.request_status = 'Y'  -- 발주 및 작업요청 여부
         WHERE MRP_GATHERING.MRP_GATHERING_NO = V_MRP_GATHERING_NO.MRP_GATHERING_NO;
    END LOOP;
    -- MRP 테이블 REQUEST_STATUS UPDATE 완료

-- 커서 LOOP문 끝
END LOOP;
FOR R_OS IN C_OUTSOURCING
LOOP
	V_OUTSOURCING_NO := 'OSC'||TO_CHAR(SYSDATE,'yyyymmdd')||'-'||lpad(OUTSOURCING_SEQ.NEXTVAL,4,0);
	INSERT INTO OUTSOURCING
	VALUES(V_OUTSOURCING_NO
				,'출고중'
				,R_OS.CUSTOMER_CODE
				,R_OS.INSTRUCT_DATE
				,R_OS.COMPLETE_DATE
				,R_OS.ITEM_CODE
				,R_OS.INSTRUCTION_AMOUNT
				,'미확정'
				,'미검사'
				,R_OS.UNIT_PRICE
				,R_OS.TOTAL_PRICE
				,R_OS.OUTSOURCING_DATE
				);

  -- 매입테이블 데이터 삽입
	INSERT INTO PURCHASE VALUES(
	'PU'||TO_CHAR(SYSDATE,'yyyymmdd')||'-'||lpad(PURCHASE_SEQ.NEXTVAL,4,0), -- 매입일련번호
  V_OUTSOURCING_NO, -- 발주번호
	R_OS.CUSTOMER_CODE, -- 거래처코드
  R_OS.ITEM_CODE, -- 품목코드
  R_OS.OUTSOURCING_DATE, -- 매입일자
  R_OS.INSTRUCTION_AMOUNT, -- 매입수량
  R_OS.UNIT_PRICE, -- 매입금액,
	R_OS.TOTAL_PRICE,	-- 매입합계
  NULL
	);

  -- 매입_매출 테이블 데이터 삽입
    INSERT INTO PURCHASE_SALE VALUES(
	  'PS'||TO_CHAR(SYSDATE,'yyyymmdd')||'-'||lpad(PURCHASE_SALE_SEQ.NEXTVAL,4,0), -- 매입_매출일련번호
    NULL, -- 납품일련번호
    'PU'||TO_CHAR(SYSDATE,'yyyymmdd')||'-'||lpad(PURCHASE_SEQ.CURRVAL,4,0), -- 매입일련번호
    R_OS.CUSTOMER_CODE, -- 거래처코드
    R_OS.OUTSOURCING_DATE, -- 거래일
    R_OS.TOTAL_PRICE, -- 매입금액합계
    NULL, -- 매출금액합계
    R_OS.OUTSOURCING_DATE, -- 결제약속일
    NULL -- 비고
    );

    -- 거래내역 테이블 데이터 삽입
    INSERT INTO DEAL VALUES(
		'DS'||TO_CHAR(SYSDATE,'yyyymmdd')||'-'||lpad(DEAL_SEQ.NEXTVAL,4,0), -- 거래내역번호
  	NULL, -- 납품일련번호
  	'PU'||TO_CHAR(SYSDATE,'yyyymmdd')||'-'||lpad(PURCHASE_SEQ.CURRVAL,4,0), -- 매입일련번호
  	R_OS.CUSTOMER_CODE, -- 거래처코드
  	R_OS.ITEM_CODE, -- 품목코드
  	R_OS.OUTSOURCING_DATE, -- 거래일
  	'매입', -- 구분
    NULL, -- 수금금액
  	R_OS.TOTAL_PRICE, -- 지불금액
  	NULL -- 비고
		);

    -- 거래상세 테이블 데이터 삽입
    INSERT INTO DEAL_DETAIL VALUES(
		'DS-D'||TO_CHAR(SYSDATE,'yyyymmdd')||'-'||lpad(DEAL_DETAIL_SEQ.NEXTVAL,4,0), -- 거래상세코드
  	'DS'||TO_CHAR(SYSDATE,'yyyymmdd')||'-'||lpad(DEAL_SEQ.CURRVAL,4,0), -- 거래내역코드
  	R_OS.ITEM_CODE, -- 품목코드
  	R_OS.INSTRUCTION_AMOUNT, -- 수량
  	'EA', -- 단위
  	R_OS.UNIT_PRICE, -- 단가
  	R_OS.TOTAL_PRICE, -- 합계
    R_OS.ITEM_NAME,
  	'미납' -- 비고
		);
END LOOP;

-- 성공시 커밋
COMMIT;

ERROR_CODE := '0';
ERROR_MSG := '발주 성공//프로시저에서 날라온 값임';

-- 예외 발생시
EXCEPTION

WHEN NO_DATA_FOUND THEN
       DBMS_OUTPUT.PUT_LINE('NO_DATA_FOUND');
       ERROR_CODE := '-1';
       ERROR_MSG := 'NO_DATA_FOUND';
       RETURN;

WHEN DUP_VAL_ON_INDEX THEN
       DBMS_OUTPUT.PUT_LINE('DUP_VAL_ON_INDEX');
       ERROR_CODE := '-1';
       ERROR_MSG := 'DUP_VAL_ON_INDEX';
       RETURN;
WHEN OTHERS THEN
       DBMS_OUTPUT.PUT_LINE('OTHERS');
       DBMS_OUTPUT.PUT_LINE(V_OUTSOURCING_NO);
       ERROR_CODE := '-1';
       ERROR_MSG := '관리자에게 문의 하세요 // 01077239513';
       RETURN;


-- PROCEDURE 끝
END;
/

