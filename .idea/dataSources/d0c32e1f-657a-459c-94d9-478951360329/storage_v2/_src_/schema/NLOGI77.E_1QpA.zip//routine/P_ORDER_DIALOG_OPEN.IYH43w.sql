create PROCEDURE    "P_ORDER_DIALOG_OPEN" -- 프로시저명
                                             (
                                                     V_MRP_GATHERING_NO_LIST IN VARCHAR2 --소요량취합번호리스트
                                                     ,
                                                     ERROR_CODE OUT NUMBER -- 에러코드
                                                     ,
                                                     ERROR_MSG OUT VARCHAR2 -- 에러메세지
                                                     ,
                                                     RESULT OUT SYS_REFCURSOR -- 결과 값 반환 커서
                                             )
IS                                     -- 변수 상수 선언부 시작
        CURSOR C_MRP_GATHERING_NO_LIST -- 커서선언시작
        IS
                WITH MRP_GATHERING_NO_LIST AS
                ( SELECT
                        --'MG20200506-001 , MG20200506-002,MG20200506-003 '이 넘어 오면 ,을 없애고 3개의 행으로 만듬
                        --하나의 행으로 여러행 나누는 방법: 정규 표현식
                        TRIM( REGEXP_SUBSTR( V_MRP_GATHERING_NO_LIST ,'[^,]+', 1, LEVEL ) ) MRP_GATHERING_NO
                FROM    DUAL
                        CONNECT BY REGEXP_SUBSTR( V_MRP_GATHERING_NO_LIST , '[^,]+', 1, LEVEL ) IS NOT NULL
                )
                --WITH 선언끝
                SELECT *
                FROM   MRP_GATHERING_NO_LIST; -- 커서끝
         -- 변수 상수 선언부 끝
 BEGIN -- 실행부 시작
         -- *****************************************************************************
         -- 임시테이블 리셋
         -- *****************************************************************************
         DELETE
         FROM   ORDER_DIALOG_TEMP;
         
         -- *****************************************************************************
         -- 임시테이블에 정보 INSERT
         -- *****************************************************************************
         INSERT
         INTO   ORDER_DIALOG_TEMP WITH MRP_GATHERING_NO_LIST AS                              -- 소요량취합번호리스트
                ( SELECT TRIM( REGEXP_SUBSTR( V_MRP_GATHERING_NO_LIST ,'[^,]+', 1, LEVEL ) ) --소요량취합번호리스트를 ' , ' 기준으로 잘라서 하나의 행으로 만듬
                FROM    DUAL
                        CONNECT BY REGEXP_SUBSTR( V_MRP_GATHERING_NO_LIST , '[^,]+', 1, LEVEL ) IS NOT NULL
                )
                ,
                O AS --
                ( SELECT  ITEM_CODE,
                         ITEM_NAME,
                         UNIT_OF_MRP,
                         SUM(REQUIRED_AMOUNT) required_amount
                FROM     order_required_temp --P_ORDERLIST_OPEN에서 insert한다 발주 필요목록 조회를 하면 정보가 저장됨
                WHERE    MRP_GATHERING_NO IN
                         ( SELECT          *
                         FROM    MRP_GATHERING_NO_LIST
                         )
                GROUP BY ITEM_CODE,
                         ITEM_NAME,
                         UNIT_OF_MRP
                )
                ,
                S AS
                ( SELECT ITEM_CODE,
                        UNIT_OF_STOCK,
                        (STOCK_AMOUNT - SAFETY_ALLOWANCE_AMOUNT) STOCK_AMOUNT
                FROM    STOCK
                )
                ,
                temp AS
                ( SELECT o.item_code,
                        o.item_name,
                        o.unit_of_mrp,
                        o.required_amount required_amount,
                        s.stock_amount,
                        --CASE에서 발주 필요량과 재고를 비교해서 실제 발주 필요량을 산출함
                        (
                        CASE --발주필요량 - 재고 의 결과가 0보다 작으면, 즉 재고가 충분하면 실제 발주필요량이 0
                                WHEN o.required_amount - s.stock_amount < 0
                                THEN 0
                                ELSE (o.required_amount - s.stock_amount)
                        END) calculated_required_amount, --실제발주필요량
                        i.standard_unit_price,           -- 단가
                        --CASE에서 발주 필요량과 재고를 비교해서 합계 산출
                        (
                        CASE --발주필요량 - 재고 의 결과가 0보다 크면, 실제발주필요량*단가
                                WHEN o.required_amount - s.stock_amount < 0
                                THEN 0
                                ELSE ((o.required_amount - s.stock_amount ) * i.standard_unit_price)
                        END) sum_price --합계금액
                FROM    O,
                        S,
                        ITEM i --order_required_temp, Stock, Item 테이블에서 조인해서 나옴
                WHERE   O.item_code = i.item_code
                AND     O.item_code = s.item_code
                ) -- O,S(with 테이블), ITEM 테이블 조인
        SELECT   item_code,
                 MAX(item_name),
                 MAX(unit_of_mrp),
                 SUM(required_amount),
                 MIN(stock_amount),
                 SUM(calculated_required_amount),
                 MAX(standard_unit_price),
                 SUM(sum_price)
        FROM     temp
        GROUP BY item_code
        ORDER BY SUM(CALCULATED_REQUIRED_AMOUNT) DESC NULLS LAST;
        
        -- 실행부 끝
        COMMIT;
        ERROR_CODE := '0';
        ERROR_MSG  := '재고처리및 취합발주 Dialog 프로시저 성공';
        OPEN RESULT FOR
        SELECT *
        FROM   ORDER_DIALOG_TEMP;
        
        -- 예외 발생시
EXCEPTION
WHEN NO_DATA_FOUND THEN
        DBMS_OUTPUT.PUT_LINE('NO_DATA_FOUND');
        ERROR_CODE := '-1';
        ERROR_MSG  := '데이터를 찾을 수 없습니다!';
        RETURN;
WHEN DUP_VAL_ON_INDEX THEN
        DBMS_OUTPUT.PUT_LINE('DUP_VAL_ON_INDEX');
        ERROR_CODE := '-1';
        ERROR_MSG  := '고유값이 중복됩니다!';
        RETURN;
WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('오류가 발생했습니다');
        DBMS_OUTPUT.PUT_LINE('SQL ERROR CODE: '
        || SQLCODE);
        DBMS_OUTPUT.PUT_LINE('SQL ERROR MESSAGE: '
        || SQLERRM);
        ERROR_CODE := '-1';
        ERROR_MSG  := 'SQL ERROR CODE: '
        || SQLCODE
        || 'SQL ERROR MESSAGE: '
        || SQLERRM;
        RETURN;
END P_ORDER_DIALOG_OPEN; -- 프로시저끝
/

