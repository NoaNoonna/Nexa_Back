create PROCEDURE      "P_SEQUENCE_INIT"
                                                               (
                                                                        SEQ_NAME IN VARCHAR2
                                                               )
IS
    L_VAL NUMBER;
BEGIN
    EXECUTE IMMEDIATE 'select ' || SEQ_NAME || '.nextval from dual' INTO L_VAL;

    EXECUTE IMMEDIATE 'alter sequence ' || SEQ_NAME || ' increment by -' || L_VAL || ' minvalue 0';

    EXECUTE IMMEDIATE 'select ' || SEQ_NAME || '.nextval from dual' INTO L_VAL;

    EXECUTE IMMEDIATE 'alter sequence ' || SEQ_NAME || ' increment by 1 minvalue 0';
END;
/

