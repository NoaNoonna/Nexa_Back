create PROCEDURE      "P_WORK_ORDER_SIMULATION" ( --모의작업지시 (BY MRP)
    -- 매개변수 선언부
    P_mrp_gathering_no     IN           VARCHAR2 -- 작업지시할 취합번호 (반제품 or 완제품)
    ,P_MRP_NO			IN					 VARCHAR2
    ,error_code   OUT          NUMBER -- 에러코드
    ,error_msg    OUT          VARCHAR2 -- 에러메세지
    ,result       OUT          SYS_REFCURSOR -- 결과 값 반환 커서
) IS

CURSOR C_mrp_list
		is
		SELECT
    TRIM( REGEXP_SUBSTR(P_mrp_gathering_no ,'[^,]+', 1, LEVEL ) ) MRP_GATHERING_NO
    ,TRIM( REGEXP_SUBSTR(P_MRP_NO ,'[^,]+', 1, LEVEL ) ) mrp_no
    FROM
    DUAL
    CONNECT BY REGEXP_SUBSTR(P_mrp_gathering_no , '[^,]+', 1, LEVEL ) IS NOT NULL
    and REGEXP_SUBSTR(P_MRP_NO , '[^,]+', 1, LEVEL ) IS NOT NULL;

Work_No VARCHAR(50);

BEGIN
		--ex)
		--v_mrp_gathering_no =MG20211102-027,MG20211102-024,...
		--P_MRP_NO					 =RP20211102-019,RP20211102-020,...
		DELETE FROM WORK_ORDER_SIMUL_TEMP;
		COMMIT;
		FOR v_mrpno_row IN C_mrp_list
		LOOP


		CASE
         WHEN LENGTH(WORK_IDENTICAL_ORDER_SEQ.NEXTVAL)<3 THEN
                 Work_No           := 'WN'
                 ||'-'
                 ||lpad(WORK_IDENTICAL_ORDER_SEQ.currval,2,0);
         ELSE
         					P_SEQUENCE_INIT('WORK_IDENTICAL_ORDER_SEQ');
                 Work_No := 'WN'
                 ||'-'
                 ||TO_CHAR(WORK_IDENTICAL_ORDER_SEQ.currval);
         END CASE;


    INSERT INTO WORK_ORDER_SIMUL_TEMP
    --동작: with절을 포함한 select절을 TEMP에 담아 뷰단에 뿌린다
    SELECT DISTINCT
			 MRP_GATHERING_NO
			,ITEM_CLASSIFICATION
			,M.ITEM_CODE
			,TRIM(M.ITEM_NAME) AS ITEM_NAME
			,UNIT_OF_MRP
			,DECODE(M.ITEM_CODE,CONNECT_BY_ROOT B.ITEM_CODE,'0',input_amount) AS INPUT_AMOUNT  --
			,REQUIRED_AMOUNT
			,DECODE(M.ITEM_CODE,CONNECT_BY_ROOT B.ITEM_CODE,'0',input_amount-REQUIRED_AMOUNT) AS STOCK_AFTER_WORK  --
			,ORDER_DATE
			,REQUIRED_DATE
			,M.MRP_NO
			,Work_No
		FROM MRP M,(SELECT item_code,TO_CHAR(input_amount+DELIVERY_AMOUNT) input_amount FROM STOCK) ST,BOM B
		WHERE MPS_NO = (	SELECT MPS_NO
											FROM MRP
											WHERE MRP_GATHERING_NO = v_mrpno_row.MRP_GATHERING_NO
											AND MRP_NO=v_mrpno_row.MRP_NO  )
		AND M.ITEM_CODE = ST.ITEM_CODE
		AND M.ITEM_CODE = B.ITEM_CODE
		START WITH B.ITEM_CODE=(SELECT ITEM_CODE
														FROM MRP
														WHERE MRP_NO=v_mrpno_row.MRP_NO)
		CONNECT BY PRIOR B.ITEM_CODE=B.PARENT_ITEM_CODE
		AND LEVEL<3
		ORDER BY ORDER_DATE DESC;
	END loop


    COMMIT;
    error_code := '0';
    error_msg := 'SUCCESS';
    OPEN result FOR SELECT  * FROM WORK_ORDER_SIMUL_TEMP ;

-- 예외 발생시

EXCEPTION
    WHEN no_data_found THEN
        dbms_output.put_line('NO_DATA_FOUND');
        error_code := '-1';
        error_msg := '데이터를 찾을 수 없습니다!';
        return;
    WHEN dup_val_on_index THEN
        dbms_output.put_line('DUP_VAL_ON_INDEX');
        error_code := '-1';
        error_msg := '고유값이 중복됩니다!';
        return;
    WHEN OTHERS THEN
        dbms_output.put_line('오류가 발생했습니다');
        dbms_output.put_line('SQL ERROR CODE: ' || sqlcode);
        dbms_output.put_line('SQL ERROR MESSAGE: ' || sqlerrm);
        error_code := '-1';
        error_msg := 'SQL ERROR CODE: '
                     || sqlcode
                     || 'SQL ERROR MESSAGE: '
                     || sqlerrm;
        return;

-- PROCEDURE 끝
END;
/

