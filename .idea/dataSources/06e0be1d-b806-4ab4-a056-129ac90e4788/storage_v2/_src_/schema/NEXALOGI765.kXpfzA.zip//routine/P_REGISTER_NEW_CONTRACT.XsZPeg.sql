create PROCEDURE      P_REGISTER_NEW_CONTRACT
																												(
                                                          V_ESTIMATE_NO IN  VARCHAR2, -- 견적번호
                                                          V_CONTRACT_TYPE IN VARCHAR2, --수주타입
                                                          V_CONTRACT_REQUESTER IN VARCHAR2, -- 수주요청자
                                                          V_PERSON_CODE_IN_CHARGE IN VARCHAR2, -- 견적담당자 코드
                                                          V_DISCRIPTION IN VARCHAR2, -- 비고
                                                          V_CONTRACT_NO IN VARCHAR2,  --java에서 수정하고 가져온  수주번호
                                                          V_CUSTOMER_CODE IN VARCHAR2, --고객 번호
                                                          ERROR_CODE OUT NUMBER,   -- 에러코드
                                                          ERROR_MSG OUT VARCHAR2,   -- 에러메세지
                                                          RESULT OUT SYS_REFCURSOR  -- 결과 값 반환 커서
																													)
 IS

 CURSOR C_CONTRACT
 IS
 SELECT *
 FROM  CONTRACT_TEMP;


/*
P_INSERT_NEW_CONTRACT_DETAIL 프로시저에 있던 내용
*/

 V_STATUS VARCHAR2(50);
 -- 시퀀스로 생성한 수주상세일련번호를 담아둘 변수
 -- V_CONTRACT_DETAIL_NO 에 CONTRACT_DETAIL 테이블에있는 CONTRACT_DETAIL_NO 컬럼의 타입을 따라 가겠다.
 V_CONTRACT_DETAIL_NO CONTRACT_DETAIL.CONTRACT_DETAIL_NO%TYPE;
 V_CONTRACT_DETAIL_NO_2 CONTRACT_DETAIL.CONTRACT_DETAIL_NO%TYPE;
 V_PRODUCTION_REQUIREMENT VARCHAR2(50); -- 제작필요수량
 V_STOCK_AMOUNT_USE       VARCHAR2(50); -- 재고사용량
 V_SAFETY_ALLOWANCE_AMOUNT VARCHAR2(50); --안전재고량
 V_SEQ_NO                 NUMBER;




BEGIN
--TEMP 테이블 데이터 리셋 해주고
	DELETE CONTRACT_TEMP;
	DELETE CONTRACT_DETAIL_TEMP;
  COMMIT;

		INSERT INTO CONTRACT_TEMP
		SELECT DISTINCT CO.CONTRACT_NO AS CONTRACT_NO
                    ,E.ESTIMATE_NO AS ESTIMATE_NO
					,T.CONTRACT_TYPE AS CONTRACT_TYPE
					,ES.CUSTOMER_CODE AS CUSTOMER_CODE
					,TD.TODAY AS CONTRACT_DATE
					,R.CONTRACT_REQUESTER AS CONTRACT_REQUESTER
					,P.PERSON_CODE_IN_CHARGE AS PERSON_CODE_IN_CHARGE
					,D.DESCRIPTION AS DESCRIPTION
					,NULL AS DELIVERY_COMPLETION_STATUS
		FROM	(SELECT TRIM( REGEXP_SUBSTR( V_CONTRACT_NO ,'[^,]+', 1, LEVEL ) ) CONTRACT_NO , ROWNUM num
					FROM    DUAL
					CONNECT BY REGEXP_SUBSTR( V_CONTRACT_NO, '[^,]+', 1, LEVEL ) IS NOT NULL
					)CO,
					(SELECT TRIM( REGEXP_SUBSTR( V_ESTIMATE_NO,'[^,]+', 1, LEVEL ) ) ESTIMATE_NO,ROWNUM num
					FROM    DUAL
					CONNECT BY REGEXP_SUBSTR( V_ESTIMATE_NO, '[^,]+', 1, LEVEL ) IS NOT NULL
					)E,
					(SELECT TRIM( REGEXP_SUBSTR( V_CONTRACT_TYPE ,'[^,]+', 1, LEVEL ) ) CONTRACT_TYPE,ROWNUM num
		            FROM    DUAL
		            CONNECT BY REGEXP_SUBSTR( V_CONTRACT_TYPE  , '[^,]+', 1, LEVEL ) IS NOT NULL
					)T,
					(SELECT TRIM( REGEXP_SUBSTR(V_DISCRIPTION ,'[^,]+', 1, LEVEL ) ) DESCRIPTION,ROWNUM num
		            FROM    DUAL
		            CONNECT BY REGEXP_SUBSTR( V_DISCRIPTION , '[^,]+', 1, LEVEL ) IS NOT NULL
					)D,
			  	(SELECT TRIM( REGEXP_SUBSTR(  V_PERSON_CODE_IN_CHARGE ,'[^,]+', 1, LEVEL ) ) PERSON_CODE_IN_CHARGE,ROWNUM num
		            FROM    DUAL
		            CONNECT BY REGEXP_SUBSTR( V_PERSON_CODE_IN_CHARGE ,'[^,]+', 1, LEVEL ) IS NOT NULL
			  	)P,
			  	(SELECT TRIM( REGEXP_SUBSTR(  V_CONTRACT_REQUESTER  ,'[^,]+', 1, LEVEL ) ) CONTRACT_REQUESTER,ROWNUM num
		            FROM    DUAL
		            CONNECT BY REGEXP_SUBSTR( V_CONTRACT_REQUESTER , '[^,]+', 1, LEVEL ) IS NOT NULL
			  	)R,
			  	(SELECT TRIM( REGEXP_SUBSTR(V_CUSTOMER_CODE ,'[^,]+', 1,LEVEL ) ) CUSTOMER_CODE ,ROWNUM num
		            FROM    DUAL
		            CONNECT BY REGEXP_SUBSTR( V_CUSTOMER_CODE, '[^,]+', 1,LEVEL ) IS NOT NULL
		      )ES,
			  	(SELECT TO_CHAR(SYSDATE,'YYYY-MM-DD') AS TODAY FROM DUAL
			  	)TD
		WHERE CO.num=E.num
		AND E.num=T.num
		AND T.num=ES.num
		AND ES.num = R.num
		AND R.num = P.num
		AND ES.num = P.num
		;

  FOR V_CONTRACT IN C_CONTRACT
  LOOP

  --견적 스테이터스 Y로 변환.
  UPDATE ESTIMATE SET CONTRACT_STATUS = 'Y'
  WHERE ESTIMATE_NO = V_CONTRACT.ESTIMATE_NO;

  /*
  	P_INSERT_NEW_CONTRACT_DETAIL 프로시저에 있던 내용
  */
	V_STATUS := NULL;

	--커서를 begin안에 선언 하지 않으면 loof가 돌지 않음. V_CONTRACT.ESTIMATE_NO를 써야 하기 때문.. 그래서 DECLARE로 선언하고 다시 BEGIN 실행한것,
	DECLARE CURSOR C_ESTIMATE_DETAIL
	IS
   -- contract_detail에 넣을 정보들
   SELECT   ES.ESTIMATE_DETAIL_NO,     -- 견적상세번호
            ES.ITEM_CODE,              -- 아이템 코드
            ES.ITEM_NAME,              -- 아이템 이름
            ES.DUE_DATE_OF_ESTIMATE,   -- 납기일
            ES.UNIT_OF_ESTIMATE,       -- 단위
            ES.ESTIMATE_AMOUNT,        --  견적수량
            ES.UNIT_PRICE_OF_ESTIMATE, --제품단가
            ES.SUM_PRICE_OF_ESTIMATE,  --합계액
            ES.DESCRIPTION             --비고
   FROM     ESTIMATE_DETAIL ES
   WHERE    ES.ESTIMATE_NO = V_CONTRACT.ESTIMATE_NO
   ORDER BY es.estimate_detail_no;
BEGIN
	FOR V_ESTIMATE_DETAIL IN C_ESTIMATE_DETAIL
        LOOP

               -- 발주번호생성
               CASE
               WHEN LENGTH(CON_DETAIL_SEQ.NEXTVAL)<3 THEN
                       V_CONTRACT_DETAIL_NO      := V_CONTRACT.CONTRACT_NO
                       ||'-'
                       ||lpad(CON_DETAIL_SEQ.currval,3,0);
               ELSE
                       V_CONTRACT_DETAIL_NO := V_CONTRACT.CONTRACT_NO
                       ||'-'
                       ||TO_CHAR(CON_DETAIL_SEQ.currval);
               END CASE;
               -- 재고가 부족하여 제작필요량이 있는경우, 즉 제작필요량이 0보다 큰경우
               -- IF문 시작
               -- 제작필요수량이 0보다 클경우 즉 제작할 수량이 있을경우 실행
               -- 안전재고제외한 재고량만 가지고있는 재고테이블의 item_code,item_name,stock_amount
               --재고 테이블 아이템코드,아이템이름,(재고량-안전재고량) 일반수주를 할 경우 사용할수 있는 양
               WITH W_STOCK AS
               ( SELECT ITEM_CODE,
                       ITEM_NAME,
                       DECODE(V_CONTRACT.CONTRACT_TYPE,'CT-01',STOCK_AMOUNT - safety_allowance_amount,STOCK_AMOUNT) STOCK_AMOUNT, --CT-01은 일반수주
                       SAFETY_ALLOWANCE_AMOUNT
               FROM    STOCK
               )
               -- contract_detail에 넣을 정보들
               SELECT DISTINCT stock_amount_use,
                               production_requirement,
                               SAFETY_ALLOWANCE_AMOUNT
               INTO            V_STOCK_AMOUNT_USE,      -- 재고사용량
                               V_PRODUCTION_REQUIREMENT, -- 제작필요수량
                               V_SAFETY_ALLOWANCE_AMOUNT
               FROM            ( SELECT  ES.ITEM_CODE,  -- 아이템 코드
                                        (
                                        CASE
                                                          -- 견적수량이 재고량보다 많으면 재고량을 모두소모하므로 재고사용량은 재고량 전부
                                                          --(재고량 - 안전재고량) - 견적수량 < 0
                                                          -- 즉 우리가 가지고 있는 완제품이나 반제품이 견적수량 보다 작을경우
                                                 WHEN TO_CHAR(ST.STOCK_AMOUNT-ES.ESTIMATE_AMOUNT) < 0
                                                 THEN TO_CHAR(ST.STOCK_AMOUNT)
                                                          -- 견적수량이 재고량보다 적으면 재고량을 견적량만큼 사용하므로 재고사용량은 견적량 전부
                                                          -- (재고량 - 안전재고량) - 견적수량 >= 0
                                                          --즉 우리가 가지고있는 재고량이 견적수량 보다 많은경우 재고사용량을 견적수량으로 한다.
                                                 WHEN TO_CHAR(ST.STOCK_AMOUNT-ES.ESTIMATE_AMOUNT) >= 0
                                                 THEN TO_CHAR(ES.ESTIMATE_AMOUNT)
                                        END ) STOCK_AMOUNT_USE, -- 재고사용량
                                        (
                                        CASE
                                                          --견적량(ES.ESTIMATE_AMOUNT)50 재고량(ST.STOCK_AMOUNT)100 ==> 50-100=-50 < 0 ==> 제작사용량을 0으로 만든다
                                                          --재고량이 충분하니깐 안만든다는 뜻
                                                          --견적수량 - (재고량 - 안전재고량)
                                                          -- 즉 견적 수량이 사용가능한 재고량 보다 적을경우 제작필요수량이 0
                                                 WHEN ES.ESTIMATE_AMOUNT - ST.STOCK_AMOUNT < 0
                                                 THEN 0
                                                 ELSE ES.ESTIMATE_AMOUNT - ST.STOCK_AMOUNT
                                        END ) PRODUCTION_REQUIREMENT, -- 제작필요수량
                                        (
                                        CASE
                                        			WHEN V_CONTRACT_TYPE='CT-02' --긴급수주
                                        					THEN
                                        						CASE
                                                                    --재고량에서 견적수량을 뺀 값이 안전재고량보다 많으면 안전재고량 손실 없음
                                                       WHEN ST.STOCK_AMOUNT-ES.ESTIMATE_AMOUNT BETWEEN 1 AND (ST.SAFETY_ALLOWANCE_AMOUNT-1)
                                                         THEN TO_CHAR(ST.STOCK_AMOUNT-ES.ESTIMATE_AMOUNT)
                                                       WHEN ES.ESTIMATE_AMOUNT - ST.STOCK_AMOUNT < 0
                                                       --WHEN ST.STOCK_AMOUNT - ES.ESTIMATE_AMOUNT > ST.SAFETY_ALLOWANCE_AMOUNT
                                                         THEN ST.SAFETY_ALLOWANCE_AMOUNT
                                                       ELSE '0'
                                        						END
                                        			ELSE SAFETY_ALLOWANCE_AMOUNT--안전재고량의 재고
                                        END ) SAFETY_ALLOWANCE_AMOUNT
                               FROM     ESTIMATE_DETAIL ES,
                                        W_STOCK ST
                               WHERE    ES.ESTIMATE_NO = V_CONTRACT.ESTIMATE_NO
                               AND      ES.ITEM_CODE   = ST.ITEM_CODE
                               AND      ES.ITEM_NAME   = ST.ITEM_NAME
                               AND      es.item_code   =V_ESTIMATE_DETAIL.item_code
                               ORDER BY es.estimate_detail_no
                               );

               IF v_production_requirement   > 0 THEN -- 제작필요수량이 있다면
                       V_STATUS             := NULL;
                       IF V_STOCK_AMOUNT_USE > 0 THEN--재고 사용량
                               UPDATE STOCK
                               SET
                                      -- 납품예정재고량에 수주에서 사용할 재고량만큼 추가
                                      STOCK.DELIVERY_AMOUNT = STOCK.DELIVERY_AMOUNT + V_STOCK_AMOUNT_USE,
                                      -- 납품예정재고량으로 이동한 재고수만큼 제거
                                      STOCK.STOCK_AMOUNT = STOCK.STOCK_AMOUNT - V_STOCK_AMOUNT_USE,
                                      STOCK.SAFETY_ALLOWANCE_AMOUNT = V_SAFETY_ALLOWANCE_AMOUNT
                               WHERE  STOCK.ITEM_CODE    = V_ESTIMATE_DETAIL.ITEM_CODE
                               AND    STOCK.ITEM_NAME    = V_ESTIMATE_DETAIL.ITEM_NAME;

                               -- STOCK테이블 UPDATE 끝
                               -- 스톡로그정보만들어서 STOCK_LOG 테이블에 찍기
                               -- 재고량에서 납품예정고량으로 이동했다고 남기는 로그
                               -- STOCK_LOG INSERT 시작
                               INSERT
                               INTO   STOCK_LOG VALUES--로그 남기기 용.
                                      (
                                             '남은재고납품예정',
                                             '재고에서 납품예정재고로 이동',
                                             TO_CHAR(SYSDATE,'YYYY-MM-DD HH24:MI:SS'),
                                             V_ESTIMATE_DETAIL.ITEM_CODE,
                                             V_ESTIMATE_DETAIL.ITEM_NAME,
                                             V_STOCK_AMOUNT_USE,
                                             '수주등록'
                                      );

                       END IF;
                       --만약 긴급수주로 넣었는데 안전재고량까지 합치면 괜찮을 때 기존 재고량을 다 쓰고 안전재고량을
               ELSIF v_production_requirement = 0 THEN -- 제작필요수량이 없으면
                       V_STATUS              := 'Y';   --수주상세에서 수주완료 여부를 y로 바꿈
                       -- 제작이 필요하지않다. 납품바로가능
                       -- STOCK 테이블의 정보 업데이트
                       UPDATE STOCK
                       SET
                              -- STOCK 테이블의 납품예정재고량에 제작안하고 바로 수주받은만큼 납품하기위하여 사용할 재고량만큼 추가
                              STOCK.DELIVERY_AMOUNT = STOCK.DELIVERY_AMOUNT + V_STOCK_AMOUNT_USE,
                              -- STOCK 테이블의 재고량에서 수주받은만큼 바로 납품하기위하여 사용한 재고량만큼 제거
                              STOCK.STOCK_AMOUNT = STOCK.STOCK_AMOUNT - V_STOCK_AMOUNT_USE,
                              STOCK.SAFETY_ALLOWANCE_AMOUNT = V_SAFETY_ALLOWANCE_AMOUNT
                       WHERE  stock.item_code    = V_ESTIMATE_DETAIL.ITEM_CODE
                       AND    STOCK.ITEM_NAME    = V_ESTIMATE_DETAIL.ITEM_NAME;

                       --  STOCK 테이블 정보 업데이트 끝
                       -- 스톡로그정보만들어서 STOCK_LOG에 찍기
                       -- 재고량에서 납품예정재고량으로 이동한 로그
                       -- 견적수량이 500개 재고량이 200개 이면 200개는 남은재고 납품예정으로 들어감
                       INSERT
                       INTO   STOCK_LOG VALUES
                              (
                                     '남은재고납품예정',
                                     '재고에서 납품예정재고로 이동',
                                     TO_CHAR(SYSDATE,'YYYY-MM-DD HH24:MI:SS'),
                                     V_ESTIMATE_DETAIL.ITEM_CODE,
                                     V_ESTIMATE_DETAIL.ITEM_NAME,
                                     V_STOCK_AMOUNT_USE,
                                     '수주등록'
                              );

                       -- 수주등록시 재고가 충분하면 바로 표시를위해 OUT매개변수 값할당
                       ERROR_MSG :='바로 납품 가능한 품목이 있습니다.<br>';
                       -- 재고가 충분하여 제작필요량이 0인 경우의 ( MPS,MRP,발주,작업지시 모두 안하는 경우 )
                       -- ELSIF문 끝
                       -- IF문 끝
               END IF;
               -- CONTRACT_DETAIL INSERT 시작
               INSERT
               INTO   CONTRACT_DETAIL VALUES
                      (
                             V_CONTRACT_DETAIL_NO,                     --수주상세일련번호 X
                             V_CONTRACT.CONTRACT_NO,                   --수주일련번호 O
                             V_ESTIMATE_DETAIL.ITEM_CODE,              --품목코드 X
                             V_ESTIMATE_DETAIL.ITEM_NAME,              --품목명 X
                             V_ESTIMATE_DETAIL.UNIT_OF_ESTIMATE,       --단위 X
                             V_ESTIMATE_DETAIL.DUE_DATE_OF_ESTIMATE,   --납기일 X
                             V_ESTIMATE_DETAIL.ESTIMATE_AMOUNT,        --견적수량 X
                             V_STOCK_AMOUNT_USE,                       --재고사용량 X
                             V_PRODUCTION_REQUIREMENT,                 --제작필요수량 X
                             V_ESTIMATE_DETAIL.UNIT_PRICE_OF_ESTIMATE, --단가 X
                             V_ESTIMATE_DETAIL.SUM_PRICE_OF_ESTIMATE,  --합계액 X
                             V_STATUS,                                 --처리상태/mps 처리여부 X
                             V_STATUS,                                 --작업완료여부 X
                             NULL,                                     --납품완료여부 X
                             V_ESTIMATE_DETAIL.DESCRIPTION,            --비고 X
                             NULL                                      --취합발주번호 X
                      );


							INSERT
               INTO   CONTRACT_DETAIL_TEMP VALUES
                      (
                             V_CONTRACT_DETAIL_NO,                     --수주상세일련번호
                             V_CONTRACT.CONTRACT_NO,                   --수주일련번호
                             V_ESTIMATE_DETAIL.ITEM_CODE,              --품목코드
                             V_ESTIMATE_DETAIL.ITEM_NAME,              --품목명
                             V_ESTIMATE_DETAIL.UNIT_OF_ESTIMATE,       --단위
                             V_ESTIMATE_DETAIL.DUE_DATE_OF_ESTIMATE,   --납기일
                             V_ESTIMATE_DETAIL.ESTIMATE_AMOUNT,        --견적수량
                             V_STOCK_AMOUNT_USE,                       --재고사용량
                             V_PRODUCTION_REQUIREMENT,                 --제작필요수량
                             V_ESTIMATE_DETAIL.UNIT_PRICE_OF_ESTIMATE, --단가
                             V_ESTIMATE_DETAIL.SUM_PRICE_OF_ESTIMATE,  --합계액
                             V_STATUS,                                 --처리상태/mps 처리여부
                             V_STATUS,                                 --작업완료여부
                             NULL,                                     --납품완료여부
                             V_ESTIMATE_DETAIL.DESCRIPTION,            --비고
                             NULL                                      --취합발주번호
                      );

        END LOOP;
        END;
        -- 수주별로 시퀀스 초기화
        P_SEQUENCE_INIT('CON_DETAIL_SEQ');

        COMMIT;


  END LOOP;

  INSERT INTO CONTRACT
  	SELECT * FROM CONTRACT_TEMP;

  OPEN RESULT FOR SELECT *  FROM CONTRACT_DETAIL_TEMP ;

  COMMIT;

  ERROR_CODE := '0';
  ERROR_MSG  := ERROR_MSG
  || '수주번호 : <b>'
  ||V_CONTRACT_NO||'</b>';

EXCEPTION
WHEN NO_DATA_FOUND THEN
        DBMS_OUTPUT.PUT_LINE('NO_DATA_FOUND');
        ERROR_CODE := '-1';
        ERROR_MSG  := 'NO_DATA_FOUND';
        RETURN;
WHEN DUP_VAL_ON_INDEX THEN
        DBMS_OUTPUT.PUT_LINE('DUP_VAL_ON_INDEX');
        ERROR_CODE :=  '-1';
        ERROR_MSG  := 'DUP_VAL_ON_INDEX';
        RETURN;
WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('오류가 발생했습니다');
        DBMS_OUTPUT.PUT_LINE('SQL ERROR CODE: '
        || SQLCODE);
        DBMS_OUTPUT.PUT_LINE('SQL ERROR MESSAGE: '
        || SQLERRM);
        ERROR_CODE := '-1';
        ERROR_MSG  := 'SQL ERROR CODE: '
        || SQLCODE
        || 'SQL ERROR MESSAGE: '
        || SQLERRM;
        RETURN;
        -- PROCEDURE 끝

END P_REGISTER_NEW_CONTRACT;
/

