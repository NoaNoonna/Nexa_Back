create PROCEDURE         "P_ORDERLIST_OPEN" --재고처리 / 발주필요 목록 조회 : 발주필요목록 데이터를 가져옴
	(
    V_START_DATE IN VARCHAR2 -- 시작날짜
    ,V_END_DATE IN VARCHAR2 -- 종료날짜
    ,ERROR_CODE OUT NUMBER -- 에러코드
    ,ERROR_MSG OUT VARCHAR2 -- 에러메세지
    ,RESULT OUT SYS_REFCURSOR -- 결과 값 반환 커서
	)
IS

BEGIN

    DELETE FROM ORDER_required_TEMP
    COMMIT;

    INSERT INTO ORDER_REQUIRED_TEMP
        SELECT
          M.MRP_GATHERING_NO, --소요량취합번호
         M.item_code item_code, --품목코드
         TRIM(M.item_name) ITEM_NAME, --품목명(정전개 되어있는 값을 TRIM으로 공백제거)
          m.unit_of_mrp_gathering unit_of_mrp, -- 단위(EA)
          m.necessary_amount required_amount, --필요수량
           (S.STOCK_AMOUNT-S.SAFETY_ALLOWANCE_AMOUNT) STOCK_AMOUNT, -- (재고량-안전재고) 재고량
           m.claim_date order_date, --발주기한
           m.due_date required_date-- 소요일자->입고기한
FROM MRP_GATHERING M, STOCK S
WHERE
    	S.ITEM_CODE = M.ITEM_CODE
AND S.ITEM_NAME = TRIM(M.ITEM_NAME)
AND M.REQUEST_STATUS IS NULL --발주 및 작업요청여부
AND M.MRP_GATHERING_NO IS NOT NULL --소요량취합번호
AND m.order_or_production_status = '구매'
AND TO_DATE(M.claim_DATE,'RRRR-MM-DD') BETWEEN TO_DATE(V_START_DATE,'RRRR-MM-DD') AND TO_DATE(V_END_DATE,'RRRR-MM-DD')
	-- 발주기한이 지정한 날짜 안에 있는 것
ORDER BY m.MRP_GATHERING_NO;

COMMIT;
        ERROR_CODE := '0';
        ERROR_MSG := '재고처리 및 발주필요목록 결과 입니다. 모의재고처리 및 취합발주로 진행하세요';
        OPEN RESULT FOR SELECT * FROM ORDER_required_TEMP;

   EXCEPTION
   WHEN NO_DATA_FOUND THEN
       DBMS_OUTPUT.PUT_LINE('NO_DATA_FOUND');
       ERROR_CODE := '-1';

       ERROR_MSG := 'NO_DATA_FOUND';
       RETURN;
   WHEN DUP_VAL_ON_INDEX THEN
       DBMS_OUTPUT.PUT_LINE('DUP_VAL_ON_INDEX');
       ERROR_CODE := '-1';
       ERROR_MSG := 'DUP_VAL_ON_INDEX';
       RETURN;
   WHEN OTHERS THEN
       DBMS_OUTPUT.PUT_LINE('OTHERS');
       ERROR_CODE := '-1';
       ERROR_MSG := '관리자에게 문의 하세요 // 01077239513';
       RETURN;
END;
/

