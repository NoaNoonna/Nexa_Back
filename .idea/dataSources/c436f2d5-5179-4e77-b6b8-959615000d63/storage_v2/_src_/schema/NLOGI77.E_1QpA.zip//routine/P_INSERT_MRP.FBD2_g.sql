create PROCEDURE    "P_INSERT_MRP"
																					(
																								MRP_REGISTER_DATE IN VARCHAR2
																							 ,ERROR_CODE OUT NUMBER
																							 ,ERROR_MSG OUT VARCHAR2
																							 ,RESULT OUT SYS_REFCURSOR
																					)
IS
CURSOR C_MRP
IS
SELECT
			  MPS_NO
			 ,NULL AS MRP_GATHERING_NO
			 ,ITEM_CLASSIFICATION
			 ,ITEM_CODE
			 ,ITEM_NAME
			 ,UNIT_OF_MRP
			 ,CEIL(CACULATED_AMOUNT) AS REQUIRED_AMOUNT
			 ,ORDER_DATE
			 ,REQUIRED_DATE
			 ,NULL AS MRP_GATHERING_STATUS
			 ,NULL AS REQUEST_STATUS
			 ,NULL AS PLAN_AMOUNT
FROM MRP_OPEN_TEMP;
V_MRP_NO VARCHAR2(50);
V_MRP_COUNT NUMBER;
V_FIRST_MRP_NO VARCHAR2(50);
V_LAST_MRP_NO VARCHAR2(50);
V_DIVISION_COUNT NUMBER;
V_SEQ_NO VARCHAR2(50);
BEGIN
			V_DIVISION_COUNT:=1;

			SELECT COUNT(*)
			INTO V_MRP_COUNT
			FROM MRP
			WHERE INSTR(MRP_NO, REPLACE( MRP_REGISTER_DATE , '-' , '' ) ) > 0;

			IF V_MRP_COUNT = 0
					THEN P_SEQUENCE_INIT('MRP_SEQ');
			END IF;
			
			FOR R_MRP IN C_MRP
			LOOP
							CASE
                WHEN LENGTH(MRP_SEQ.NEXTVAL)<3 THEN
                        V_MRP_NO:='RP'||TO_CHAR(SYSDATE,'YYYYMMDD')||'-'||lpad(MRP_SEQ.CURRVAL,3,0);
                ELSE
                        V_MRP_NO:='RP'||TO_CHAR(SYSDATE,'YYYYMMDD')||'-'||TO_CHAR(MRP_SEQ.CURRVAL);
              END CASE;
              
              INSERT INTO MRP
              VALUES(
              				V_MRP_NO
              			 ,R_MRP.MPS_NO
              			 ,R_MRP.MRP_GATHERING_NO
              			 ,R_MRP.ITEM_CLASSIFICATION
              			 ,R_MRP.ITEM_CODE
              			 ,R_MRP.ITEM_NAME
              			 ,R_MRP.UNIT_OF_MRP
              			 ,R_MRP.REQUIRED_AMOUNT
              			 ,R_MRP.ORDER_DATE
              			 ,R_MRP.REQUIRED_DATE
              			 ,R_MRP.MRP_GATHERING_STATUS
              			 ,R_MRP.REQUEST_STATUS
              			 ,R_MRP.PLAN_AMOUNT
              );
              IF V_DIVISION_COUNT=1
              		THEN V_FIRST_MRP_NO:=V_MRP_NO;
              ELSIF V_DIVISION_COUNT=C_MRP%ROWCOUNT
              		THEN V_LAST_MRP_NO:=V_MRP_NO;
              END IF;
							V_DIVISION_COUNT:=V_DIVISION_COUNT+1;
			END LOOP;
			COMMIT;
			OPEN RESULT FOR SELECT V_FIRST_MRP_NO AS FIRST_NO
														,V_LAST_MRP_NO AS LAST_NO
														,V_DIVISION_COUNT AS LENG
											FROM DUAL;
			EXCEPTION
			WHEN NO_DATA_FOUND THEN
			       ERROR_CODE := '-1';
			       ERROR_MSG := '데이터를 찾을 수 없습니다!';
			       RETURN;

			WHEN DUP_VAL_ON_INDEX THEN
			       ERROR_CODE := '-1';
			       ERROR_MSG := '고유값이 중복됩니다!';
			       RETURN;

			WHEN OTHERS THEN
			       ERROR_CODE := '-1';
			       ERROR_MSG := 'SQL ERROR CODE: ' || SQLCODE || 'SQL ERROR MESSAGE: ' || SQLERRM;
			       RETURN;
END;
/

