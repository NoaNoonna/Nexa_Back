create PROCEDURE      P_ORDER_SAFETYALLOWANCE_CHANGE
(
    -- 매개변수 선언부
    v_item_Code  IN VARCHAR2, -- 아이템코드
    v_item_Name  IN VARCHAR2, -- 아이템명
    v_safetyAllowance IN NUMBER, -- 변경할 안전재고량
    error_code OUT NUMBER, -- 에러코드
    error_msg OUT VARCHAR2 -- 에러메세지
)
IS
--변수 선언
v_stock_amount stock.stock_amount%TYPE;
BEGIN
-- 실행부시작

SELECT
    STOCK_AMOUNT
INTO v_stock_amount
    FROM STOCK
    WHERE item_name = v_item_Name
AND ITEM_code = v_item_Code;
--400 500
--바꿀 안전재고량보다 남아있는 재고량이 적을때
IF v_stock_amount < v_safetyAllowance THEN
error_code := '1';
error_msg := '변경할 안전재고량이 재고량보다 많습니다 재고량을 생산해주세요';
ELSIF v_stock_amount >= v_safetyAllowance THEN
    UPDATE
    STOCK
    SET
    safety_allowance_amount=v_safetyAllowance
    WHERE
    STOCK.ITEM_CODE = v_item_Code
    AND STOCK.ITEM_NAME = v_item_Name;
    -- STOCK테이블 UPDATE 끝

    -- 스톡로그정보만들어서 STOCK_LOG 테이블에 찍기
    -- 재고량에서 납품예정고량으로 이동했다고 남기는 로그

    -- STOCK_LOG INSERT 시작
    INSERT INTO STOCK_LOG VALUES
    (
    '안전재고량변경',
    '재고에서 안전재고량으로 이동',
    TO_CHAR(SYSDATE,'YYYY-MM-DD HH24:MI:SS'),
    v_item_Code,
    v_item_Name,
    v_stock_amount,
    '수주등록'
    );
error_code := '0';
error_msg := '변경이 완료 되었습니다.';
end if;
commit;


-- 예외 발생시
EXCEPTION

WHEN no_data_found THEN
       dbms_output.put_line('NO_DATA_FOUND');
       error_code := '-1';
       error_msg := '데이터를 찾을 수 없습니다!';
       RETURN;

WHEN dup_val_on_index THEN
       dbms_output.put_line('DUP_VAL_ON_INDEX');
       error_code := '-1';
       error_msg := '고유값이 중복됩니다!';
       RETURN;

WHEN OTHERS THEN
       dbms_output.put_line('오류가 발생했습니다');
       dbms_output.put_line('SQL ERROR CODE: ' || SQLCODE);
       dbms_output.put_line('SQL ERROR MESSAGE: ' || sqlerrm);
       error_code := '-1';
       error_msg := 'SQL ERROR CODE: ' || SQLCODE || 'SQL ERROR MESSAGE: ' || sqlerrm;
       RETURN;

-- PROCEDURE 끝
END;
/

