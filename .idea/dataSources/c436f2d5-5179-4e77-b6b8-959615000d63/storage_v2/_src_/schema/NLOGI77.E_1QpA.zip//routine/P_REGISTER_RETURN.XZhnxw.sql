create PROCEDURE      "P_REGISTER_RETURN"
                                      (
                                              V_DELIVERY_NO IN VARCHAR2
                                            , -- 납품일련번호
                                              V_ITEM_CODE IN VARCHAR2
                                            , --아이템코드
                                              V_REVERSE_AMOUNT IN VARCHAR2
                                            , -- 역물류량
                                              ERROR_CODE OUT NUMBER
                                            ,                        -- 에러코드
                                              ERROR_MSG OUT VARCHAR2 -- 에러메세지
                                      )
IS
        V_STOCK_AMOUNT            VARCHAR2 ( 50 ) ; --STOCK
        V_TOTAL_STOCK_AMOUNT      VARCHAR2 ( 50 ) ; --STOCK
        V_SAFETY_ALLOWANCE_AMOUNT VARCHAR2 ( 50 ) ; --STOCK
        V_CONTRACT_TYPE           VARCHAR2 ( 50 ) ; --CONTRACT
        V_DELIVERY_AMOUNT         VARCHAR2 ( 50 ) ; --DELIVERY
        V_UNIT_PRICE              VARCHAR2 ( 50 ) ; --DELIVERY
        V_SUM_PRICE               VARCHAR2 ( 50 ) ; --DELIVERY
        V_DELIVERY_DATE           VARCHAR2 ( 50 ) ; --DELIVERY
BEGIN
        --수주 테이블에서 수주유형 가져오기
        SELECT DISTINCT CONTRACT_TYPE
        INTO            V_CONTRACT_TYPE
        FROM            CONTRACT
        WHERE           CONTRACT.CONTRACT_NO = (
                        SELECT DELIVERY_INFO.CONTRACT_NO
                        FROM   DELIVERY_INFO
                        WHERE  DELIVERY_NO = V_DELIVERY_NO
                        ) ;

        --재고 테이블
        SELECT DISTINCT STOCK_AMOUNT
                      , TOTAL_STOCK_AMOUNT
                      , SAFETY_ALLOWANCE_AMOUNT
        INTO            V_STOCK_AMOUNT
                      , V_TOTAL_STOCK_AMOUNT
                      , V_SAFETY_ALLOWANCE_AMOUNT
        FROM            STOCK
        WHERE           STOCK.ITEM_CODE = V_ITEM_CODE;

        --납품 테이블
        SELECT DISTINCT DELIVERY_AMOUNT
                      , UNIT_PRICE
                      , SUM_PRICE
                      , DELIVERY_DATE
        INTO            V_DELIVERY_AMOUNT
                      , V_UNIT_PRICE
                      , V_SUM_PRICE
                      , V_DELIVERY_DATE
        FROM            DELIVERY_INFO
        WHERE           DELIVERY_NO = V_DELIVERY_NO;

        IF V_CONTRACT_TYPE                                                                   = 'CT-02' THEN
                IF TO_NUMBER ( V_SAFETY_ALLOWANCE_AMOUNT ) + TO_NUMBER ( V_REVERSE_AMOUNT ) <= 100 THEN
                        UPDATE STOCK
                        SET    STOCK.SAFETY_ALLOWANCE_AMOUNT = TO_NUMBER ( STOCK.SAFETY_ALLOWANCE_AMOUNT ) + TO_NUMBER ( V_REVERSE_AMOUNT )
                        WHERE  STOCK.ITEM_CODE               = V_ITEM_CODE;

                ELSE
                        UPDATE STOCK
                        SET    STOCK.SAFETY_ALLOWANCE_AMOUNT = '100'
                             , STOCK.STOCK_AMOUNT            = TO_NUMBER ( STOCK.STOCK_AMOUNT )       + ( TO_NUMBER ( V_SAFETY_ALLOWANCE_AMOUNT ) + TO_NUMBER ( V_REVERSE_AMOUNT ) - 100 )
                             , STOCK.TOTAL_STOCK_AMOUNT      = TO_NUMBER ( STOCK.TOTAL_STOCK_AMOUNT ) + ( TO_NUMBER ( V_SAFETY_ALLOWANCE_AMOUNT ) + TO_NUMBER ( V_REVERSE_AMOUNT ) - 100 )
                        WHERE  STOCK.ITEM_CODE               = V_ITEM_CODE;

                END IF;
                IF TO_NUMBER ( V_REVERSE_AMOUNT ) - TO_NUMBER ( V_DELIVERY_AMOUNT ) = 0 THEN
                        UPDATE DELIVERY_INFO
                        SET    DELIVERY_INFO.SUM_PRICE     = 0
                             , DELIVERY_INFO.DELIVERY_DATE = TO_CHAR ( SYSDATE, 'YYYY-MM-DD HH24:MI:SS' )
                             , DELIVERY_INFO.RETURN_PRICE  = DELIVERY_INFO.UNIT_PRICE * TO_NUMBER ( V_REVERSE_AMOUNT )
                        WHERE  DELIVERY_INFO.DELIVERY_NO   = V_DELIVERY_NO;

                ELSE
                        UPDATE DELIVERY_INFO
                        SET -- 일부만 반품하면 반품량과 반품금액만큼 납품에서 빼주기
                               DELIVERY_INFO.SUM_PRICE       = TO_NUMBER ( DELIVERY_INFO.DELIVERY_AMOUNT ) * TO_NUMBER ( DELIVERY_INFO.UNIT_PRICE ) - TO_NUMBER ( V_REVERSE_AMOUNT ) * TO_NUMBER ( DELIVERY_INFO.UNIT_PRICE )
                             , DELIVERY_INFO.DELIVERY_AMOUNT = V_REVERSE_AMOUNT
                             , DELIVERY_INFO.DELIVERY_DATE   = TO_CHAR ( SYSDATE, 'YYYY-MM-DD HH24:MI:SS' )
                             , DELIVERY_INFO.RETURN_PRICE    = TO_NUMBER ( DELIVERY_INFO.UNIT_PRICE ) * TO_NUMBER ( V_REVERSE_AMOUNT )
                        WHERE  DELIVERY_NO                   = V_DELIVERY_NO;

                END IF;
        ELSE
                --일반수주한 제품을 반품했을 때
                UPDATE STOCK
                SET    STOCK.STOCK_AMOUNT       = TO_NUMBER ( STOCK.STOCK_AMOUNT )       + TO_NUMBER ( V_REVERSE_AMOUNT )
                     , STOCK.TOTAL_STOCK_AMOUNT = TO_NUMBER ( STOCK.TOTAL_STOCK_AMOUNT ) + TO_NUMBER ( V_REVERSE_AMOUNT )
                WHERE  STOCK.ITEM_CODE          = V_ITEM_CODE;

                IF TO_NUMBER ( V_REVERSE_AMOUNT ) - TO_NUMBER ( V_DELIVERY_AMOUNT ) = 0 THEN
                        UPDATE DELIVERY_INFO
                        SET    DELIVERY_INFO.SUM_PRICE     = 0
                             , DELIVERY_INFO.DELIVERY_DATE = TO_CHAR ( SYSDATE, 'YYYY-MM-DD HH24:MI:SS' )
                             , DELIVERY_INFO.RETURN_PRICE  = DELIVERY_INFO.UNIT_PRICE * TO_NUMBER ( V_REVERSE_AMOUNT )
                        WHERE  DELIVERY_INFO.DELIVERY_NO   = V_DELIVERY_NO;

                ELSE
                        UPDATE DELIVERY_INFO
                        SET -- 일부만 반품하면 반품량과 반품금액만큼 납품에서 빼주기
                               DELIVERY_INFO.SUM_PRICE       = TO_NUMBER ( DELIVERY_INFO.DELIVERY_AMOUNT ) * TO_NUMBER ( DELIVERY_INFO.UNIT_PRICE ) - TO_NUMBER ( V_REVERSE_AMOUNT ) * TO_NUMBER ( DELIVERY_INFO.UNIT_PRICE )
                             , DELIVERY_INFO.DELIVERY_AMOUNT = V_REVERSE_AMOUNT
                             , DELIVERY_INFO.DELIVERY_DATE   = TO_CHAR ( SYSDATE, 'YYYY-MM-DD HH24:MI:SS' )
                             , DELIVERY_INFO.RETURN_PRICE    = TO_NUMBER ( DELIVERY_INFO.UNIT_PRICE ) * TO_NUMBER ( V_REVERSE_AMOUNT )
                        WHERE  DELIVERY_NO                   = V_DELIVERY_NO;

                END IF;
        END IF;
        --이미 반품한 제품은 다시 반품할 수 없도록 STATUS를 Y로 변경
        UPDATE DELIVERY_INFO
        SET    RETURN_STATUS = 'Y'
        WHERE  DELIVERY_NO   = V_DELIVERY_NO;

        INSERT
        INTO   STOCK_LOG VALUES--로그 남기기 용.
               (
                      '반품예정'
                    , '반품량만큼 재고량에 추가'
                    , TO_CHAR ( SYSDATE, 'YYYY-MM-DD HH24:MI:SS' )
                    , V_ITEM_CODE
                    , V_DELIVERY_NO
                    , V_REVERSE_AMOUNT
                    , '반품완료'
               ) ;

        COMMIT;
EXCEPTION
WHEN NO_DATA_FOUND THEN
        DBMS_OUTPUT.PUT_LINE ( 'NO_DATA_FOUND' ) ;
        ERROR_CODE := '-1';
        ERROR_MSG  := 'NO_DATA_FOUND';
        RETURN;
WHEN DUP_VAL_ON_INDEX THEN
        DBMS_OUTPUT.PUT_LINE ( 'DUP_VAL_ON_INDEX' ) ;
        ERROR_CODE := '-1';
        ERROR_MSG  := 'DUP_VAL_ON_INDEX';
        RETURN;
WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE ( '오류가 발생했습니다' ) ;
        DBMS_OUTPUT.PUT_LINE ( 'SQL ERROR CODE: '
        || SQLCODE ) ;
        DBMS_OUTPUT.PUT_LINE ( 'SQL ERROR MESSAGE: '
        || SQLERRM ) ;
        ERROR_CODE := '-1';
        ERROR_MSG  := 'SQL ERROR CODE: '
        || SQLCODE
        || 'SQL ERROR MESSAGE: '
        || SQLERRM;
        RETURN;
        -- PROCEDURE 끝
        COMMIT ;
END;
/

